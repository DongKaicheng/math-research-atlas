# Edit and draw logical proof diagrams

Use a diagram to reveal the structure of a supplied argument: joint assumptions, intermediate constructions, shared lemmas, alternative sufficient proofs and unresolved steps. Preserve the mathematical content with the same care as theorem prose. Use prose or a short list when a diagram would show only a simple chain without helping the reader.

## Recover the argument before shortening labels

Read the relevant statements and proofs, including ambient conventions and the clauses actually applied. Identify each node's exact objects, hypothesis set, conclusion, source status and stable destination. Identify the actual inference or contribution represented by each connection. A citation, similar title or proposed work order does not establish a deduction.

Keep all premises of an argument together: if A and H yield B, retain both A and H at the **AND** gate. Retain additional conditions attached to that gate. Use **OR** only for separate sufficient routes to the same scoped conclusion; each route keeps its own AND premises. A proof input contributes to an argument but may not alone imply its conclusion. Keep a proposed inference visibly open and describe the missing step. A failed shortcut does not by itself refute the downstream objective.

Preserve shared dependencies and cross-links. A single-parent reading hierarchy is not a substitute for the support graph. A diagram's source status should match the manuscript: do not promote a conditional result, widen the test class, turn uniqueness in a subclass into unrestricted uniqueness, or suppress a degree restriction to fit a label. Equally, do not demote a supplied theorem merely because this editorial pass did not independently reprove it.

## Draw at the useful scale

For a long argument, separate a principal proof strategy from its detailed subarguments. State what the principal view omits and link to it. Use conventional mathematical names for node titles; put the full statement, all conditions and the exact proof reference at the linked destination. Keep displayed qualifiers where their omission would mislead even before a click.

Load the installed `math-project-maintainer` and read its `references/logic-diagrams.md` for the canonical `math-logic-map/v1` records and reusable `scripts/logic_map.py` tools. Resolve the actual loaded path and inspect its command help. Reuse an existing manuscript or project diagram generator when compatible. Do not maintain a separately edited picture whose logic can drift from the records.

Prefer a compact top-down vector diagram, native LaTeX diagram or supported Mermaid flowchart for a small explanation. Follow the output medium's actual constraints. Do not use generated raster artwork for an exact proof graph. Split a large figure before reducing type to an unreadable size. Use labels or line styles as well as colour; retain all joint inputs across a split through named continuation links. Use semantic theorem/proof labels rather than hard-coded numbers.

For an interactive website, hand integration to `math-research-publisher`, retaining the same records, hyperlinks and statuses. For a paper, deliver the diagram in the requested document with a concise caption explaining the relations. Do not start a website project merely because a manuscript contains a proof diagram.

## Check mathematics and rendering separately

Compare the diagram with the source argument after drawing: every claimed deduction has its complete premises, every alternative is genuinely alternative, and every unresolved inference retains its status. Inspect rendered relation directions and labels, not only the input file. A cycle of unproved prerequisites is not a proof; use the maintainer's selected-support analysis when that issue arises. Do not reject a genuine equivalence or a grounded alternative proof merely because the union graph has a cycle.

Compile and inspect the diagram at its actual reading size. Check line crossings, text clipping, mathematical symbols, numbered references, link destinations and grayscale legibility. In a digital paper verify that statement and proof links reach the intended sections; in a web view verify the corresponding disclosure and narrow-screen reading flow. Keep any full-condition text beside the figure or at an explicit accessible destination. Report source comparison and visual checks accurately, without treating either as formal proof verification.
