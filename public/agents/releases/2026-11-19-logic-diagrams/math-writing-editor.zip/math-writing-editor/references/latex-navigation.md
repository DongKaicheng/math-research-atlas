# Mathematical cross-references and color

For digital papers, make theorem, definition, lemma, equation, section, and citation references easy to recognize and follow. Respect the user's or journal's required style. Preserve an existing compatible setup instead of loading packages twice.

## Default

- Theorem/proposition/lemma/definition links: dark blue `1F4E79`; section/subsection links: dark teal `00656D`; equations: muted purple `643F7A`; citations: dark green `2F6B3C`; URLs: dark brown-red `843C39`.
- Color links, not theorem statements or whole paragraphs. Do not assign a different color to every kind of theorem.
- Keep visible names and numbers; color must not be the only indication of meaning. A grayscale printout must still make sense.
- Prefer an entire named reference as the target, e.g. `\Cref{thm:main}` with `nameinlink`. Use semantic labels rather than hard-coded numbers. Keep the established parenthesized-number convention for equations.
- For theorem proofs cited in the Introduction, use the proof subsection label, e.g. `\Cref{sec:proof-main}`, rather than `p.~\pageref{...}`. Check that the rendered subsection number and destination identify the intended proof. Page locators may still be appropriate in an index or a precise external citation; do not globally remove them.
- If a journal requires black text, use its setting or `\hypersetup{hidelinks}`. Do not override it with the digital default.

## Implementation

The optional [preamble fragment](../assets/latex-links.tex) is for documents without an existing setup. Load `xcolor` before `hyperref` and `cleveref` after `hyperref` and the theorem packages, subject to class-specific requirements. For a class that already loads these packages, merge the color settings and use its supported named-reference commands. Do not blindly paste the fragment into an existing preamble.

Preserve labels, destinations, bibliography keys, PDF title/author, and restatement anchors by default. For an explicitly unsigned document, omit its byline and clear its PDF author field, including automatically generated metadata; preserve the PDF title, bibliography author names and source attribution. Check both rendered title pages and document properties. Configure custom theorem names if necessary. With shared theorem counters, check that a definition is identified as “Definition”, not “Theorem”; use the document's `cleveref` typing or theorem setup. Avoid nested `\hyperref`/`\Cref` links. Do not turn a large paragraph into a single link.

If a shared-counter definition or lemma has inherited the theorem reference type, `cleveref` supports an explicit type such as `\label[definition]{def:orderzero}` or `\label[lemma]{lem:bound}`, retaining the label key. Apply this only when compatible with the document's existing setup; its theorem package or `aliascnt` may already handle the type. Renaming `\crefname{definition}` alone does not repair a label stored as type theorem.

`hyperref` normally gives internal links a single `linkcolor`; defining five colors does not automatically classify references. The fragment therefore leaves theorem-like `\Cref` links blue and provides opt-in `\MathSecref{sec:proof}` and `\MathEqref{eq:bound}`. Each locally changes `linkcolor` while calling the existing named-reference or equation command, retaining its destination. Use these only for the matching label types; keep mixed-type lists as separate references. Do not patch private hyperlink internals or globally redefine reference commands. Check for command-name conflicts before integrating.

An existing compatible document may retain fewer color categories if adding wrappers would disrupt its class or reference package. Explain that implementation choice in editorial notes. Color contents links locally around `\tableofcontents` if desired. Keep `hidelinks` usable; test that the wrappers do not re-enable color links in a print version.

## Check the compiled result

Compile enough passes to resolve references. Check undefined/multiply defined labels and duplicate PDF destinations. Inspect representative links to a theorem, definition, equation, section, citation, and URL where present. Confirm readable text, correct destination and type, and the intended visible colors. A colored number without a working destination does not pass.

PDF link annotations can verify destinations; inspect rendered pages for actual text color and wrapping. Check that long names do not create overfull lines or crowded punctuation. Report compilation, destination checks, and visual checks separately from mathematical-content review.
