# Evaluating writing improvement

Compare against a serious baseline: the same model editing the same source with the user's existing v2.2 writing requirements. Use the same source context, output format, tool access, and comparable generation budget. Record actual settings; do not claim matched computation if the platform does not expose it.

Start with held-out real excerpts of several kinds: definition/theorem presentation, a proof with a difficult transition, and an Introduction with its body supplied. Include already well-written passages. Select whole arguments, not isolated sentences whose context determines their meaning. Keep these passages out of the example collection. Use synthetic examples for engineering checks, clearly labelled as such.

## Four distinct review passes

Review after drafting, returning to the source rather than relying on the editor's explanation of its own changes.

| Pass | Required evidence |
|---|---|
| A. Mathematical fidelity and statement logic | Compare all changed assertions, including prose and deletions. Check what is given and what must exist, uniqueness/choice independence, hypotheses, quantifiers, domains, types, convergence/tests/support, signs, normalization, and dependencies. |
| B. Redundancy and defensive prose | Read the entire edited scope for redundant scope warnings, Remarks, repeated explanations, metanarrative headings, and stock transitions. Try deletion first; retain negative conditions and useful counterexamples. Record the reason for keep/delete/merge/move/rewrite. |
| C. Mathematical readability | Ask the reader to state the theorem, explain the purpose of auxiliary objects and the decisive inference, connect main results, and identify the supported mathematical contribution. |
| D. Technical verification | Record compilation, reference resolution, PDF inspection, link destinations, reference types, and rendered colors separately. Use not-applicable for a plain-text excerpt; unavailable checks are uncertain, not passes. |

These are separate judgments. Successful compilation cannot compensate for a logical defect, and shorter prose is not automatically better. A second pass in one conversation is a local self-review, not an independent reviewer. Preserve the user's instruction to use only this editor.

## Commands

Use the existing Codex session to produce edits; this helper makes no model/API calls.

```bash
python3 <skill-dir>/scripts/editor_lab.py examples --task proof --limit 2
python3 <skill-dir>/scripts/editor_lab.py blind \
  --source source.tex --candidate baseline.tex --candidate edited.tex \
  --out-dir trial-01
```

Give a reviewer **only** `trial-01/public/review.md` and `trial-01/public/ratings.template.json`. Keep `trial-01/private-key.json` hidden from them until the review is complete. Candidate names and file paths are not included in the public packet. The text itself can still contain stylistic cues; do not promise perfect blindness. Do not label files or candidate prose with the generator identity. The command refuses an existing output directory.

Ask the reviewer to compare the source and candidates, cite concrete text in their reasons, and allow ties. Do not tell the reviewer which candidate should win. When a fresh agent is used, report the result as a model review. Do not imply that a mathematician conducted the evaluation.

Fill the template with `reviewer_kind` (`human`, `model`, or `mixed`), `reviewer`, and every candidate's ratings. Use `math_fidelity` = `pass`, `fail`, or `uncertain`; an unexplained scope change fails, and an unresolved equivalence is uncertain. Give 1–5 for each of:

- `mainline`: can a reader identify the purpose and organization?
- `mechanism`: are the decisive construction and inference explained?
- `detail`: is explanation allocated to genuine difficulties without losing needed steps?
- `prose`: is the text natural, precise research writing without boilerplate?

Include evidence for the fidelity judgment and each dimension. Do not reward brevity, elegance, word variation, or headings in isolation. Readability scores never compensate for changed mathematics.

New comparison packets also require evidence-backed `statement_logic`, `redundancy`, and `technical` audits. A statement-logic failure or uncertainty blocks the editorial mean even if source wording was preserved. Technical checks may be `not_applicable` for text-only candidates. Legacy schema-1 reports remain readable, but do not acquire these audits retroactively.

For an Introduction, support those dimensions with concrete answers: can the reader explain the full main result; are only its necessary prerequisites introduced early; does the comparison identify what the closest prior result actually supplies; and can the reader follow the proof's stages from inputs to outputs? Verify cited comparisons rather than rewarding their apparent sophistication. Check that Steps carry an actual mechanism and do not just partition boilerplate.

Also ask the reader to explain the result's mathematical use and the connection between successive main theorems. Cite the exact sentences supporting these answers. Do not reward a transition that merely announces the next theorem, or significance claimed only through adjectives. Check that the table of contents precedes the Introduction when one is included. These are distinct checks: layout compliance does not establish better exposition.

For structural revisions, verify that Introduction proof references name real subsections, that main proof stages are accessible in the body, and that each retained appendix has a specific supplementary role. Reducing the appendix count by relabelling sections alone is not evidence of better organization. Check the new dependency order and preserve all necessary statements and arguments.

For each substantial addition, check nearby text for duplication and ask whether moving, merging, deleting, or leaving unchanged would work better. Audit new prose assertions even when formal statements are unchanged. Check colored cross-reference text and destinations separately; navigation improvements are not evidence of better mathematical explanation.

```bash
python3 <skill-dir>/scripts/editor_lab.py report \
  --trial-dir trial-01 --ratings ratings.json
```

The report checks packet hashes and rating completeness, reports each candidate, and computes mean editorial ratings **only for candidates with a fidelity pass**. These are reviewer judgments, not a correctness proof or a statistically established quality metric. A tied mean remains a tie. Inspect dimension-specific differences and reviewer comments.

## Interpretation and improvement

### Feedback regressions

Use the contextual cases in `references/regression-cases.json`:

```bash
python3 <skill-dir>/scripts/editor_lab.py regressions --out-dir regression-01
# Edit from inputs.json; record action, revised text, and separate editorial notes.
# Review afterward against rubric.json; fill every criterion with evidence.
# Record the SHA-256 of the exact responses file in review.responses_sha256.
python3 <skill-dir>/scripts/editor_lab.py regression-report \
  --trial-dir regression-01 --responses responses.json --review review.json
```

The initial feedback cases cover existence of a continuous-coefficient product, the deterministic-argument heading, a citation-only Remark, and the two rejected defensive sentences. The product lemma fixture explicitly supplies its test-space and order-zero estimate; it is a reconstruction of the reported defect, not the full original CLD lemma. Reverse tests retain necessary nonvanishing, a useful counterexample Remark, and an already good proof. Additional guards check unsupported well-definedness, constant dependencies, citation allocation, and a nontrivial limit interface.

Programme regressions cover conventional result headings, precise quotient-descent problems, conditional implications, corollary placement, missing formal proofs, full titles, and scoped unsigned publication. Their reverse cases retain a genuine programme gap and preserve authorship in another manuscript. A separate test distinguishes positivity from finiteness on a rational vector space. These are assistant-authored reconstructions of the failure patterns, not new claims about the user's research or author-approved model outputs. For article delivery, also inspect actual HTML/PDF bylines and metadata when those artifacts exist; text-only fixtures do not establish export correctness.

Generate a revision before consulting the expected actions and review criteria. Known feedback remains regression material even when presented without a rubric; it is not held out. Permit multiple valid rewrites and a no-change decision; do not compare against one canonical string, except where an explicit keep action must literally preserve the source. Empty text is valid for complete deletion.

The helper verifies packet hashes, exact case coverage, decisions, and review completeness. Semantic judgments still require reading; the script does not edit prose, detect correctness, or certify general improvement. Record `same_session` or `fresh_reviewer` explicitly. Keep regression outputs and validation PDFs outside the installed skill; update the reusable rule only for a demonstrated failure.

Record failures in terms of the editorial decision: missing construction purpose, damaged quantifier, unnecessary exposition, wrong paragraph order, or unhelpful stock sentence. Improve the relevant decision rule or example, then use a new held-out passage. Do not tune repeatedly on a test case and keep calling it held-out.

A single-session check on the manuscript that motivated an update is a regression/smoke test, not an independent evaluation. Report which failure was addressed and any remaining limitations. If the user asks to use only this editor, do not introduce another agent to generate or review the revision. Do not describe this constraint as preventing useful local checks.

For a first trial, report observed improvements and regressions without declaring the editor generally superior. Before making that claim, collect multiple papers, a meaningful human blind comparison, and document-level results. Suggested pilot: twelve passages across at least three papers, followed by one complete chapter and one complete Introduction. Treat this as a proposed evaluation design, not a guaranteed statistical sample size.

If examples and reader-oriented revision fail to improve writing, compare the underlying models or consider preference training using genuine accepted/rejected edits. Additional agents alone are not evidence of better writing. Preserve a no-change option for strong source passages.
