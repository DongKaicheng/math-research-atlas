# Research programmes and formal articles

Treat a programme as mathematical writing about a precisely defined target and the deductions that could establish it. A list of milestones is a work plan, not the mathematical programme itself. Preserve supplied claims and their status; use `math-project-maintainer` for new proof development or verification of an unsupported implication.

## Separate the two reading levels

Write a website overview for orientation: the mathematical motivation, the central question in plain terms, the main known cases, and a prominent link to the formal article. Keep that overview short without weakening the statement it summarizes. Use ordinary established mathematical terms. Expand abbreviations in the main title when requested; do not rename a conjecture beyond what the source establishes.

Write the linked article as a standalone document, with a title, abstract, necessary definitions and conventions, numbered statements, the available proofs or precise proof references, a substantive programme, and references. Its mathematical content must remain intelligible without the homepage, cards, tooltips, or another chat. State exact quantifiers in the article even when the overview is informal. Keep a completed argument complete: a proof sketch or a list of lemma names cannot replace a requested proof.

Preserve one source of mathematical truth across the HTML article and standalone PDF. Hand the publisher the article's stable route, source/version, and export requirements; the publisher verifies the live links and download. Do not claim that a PDF exists, is current, or has been inspected unless that check was actually performed. A whole-site printout is not an independent mathematical paper.

## Build the programme from the mathematics

Read the exact source statements and dependency records before writing the plan. Use the following working questions outside the article; express their answers as ordinary mathematical prose, not a row of repetitive administrative boxes.

1. **Target.** What object should exist, on which domain and ground field, with which hypotheses, choices, quantifiers, identities and normalizations? Separate construction from its desired additional properties.
2. **Established inputs.** Which statements and deductions are available, with which proofs and conditions? Include relevant partially established cases with their exact residual questions. A summary naming a theorem is not a recovered proof.
3. **Intermediate assertions.** Formulate each needed step as a precise Problem, Question, Conjecture, or conditional Proposition. Use the source's certainty level: a possible approach need not be promoted to a conjecture.
4. **Mechanism.** Explain the proposed construction, reduction, estimate, comparison map, or obstruction class. Identify what mathematical output it supplies to the next step. If no mechanism is known, say which problem remains to be found or solved; do not invent one.
5. **Implication.** Give a proof or an exact checked reference for an asserted reduction. Preserve all additional assumptions in both the statement and the accompanying explanation. Write \((A\text{ and }H)\Rightarrow B\), not \(A\Rightarrow B\), when \(H\) is also needed. Distinguish an established conditional deduction from a proposed implication whose proof is itself open.
6. **Obstacle.** Locate the first presently unsupported inference and explain which target it blocks. State what would resolve it in mathematical terms. Keep alternative approaches distinct instead of presenting them as successive necessary steps.

Preserve an intended objective when an advertised implication fails: move it to a separate problem rather than silently dropping it. If a counterexample disproves the target as stated, identify that mathematical defect and label any repaired formulation as a proposal; do not leave a false assertion labelled merely “open”.

Organize related statements by implication and application. A genuine corollary belongs with its parent theorem or conjecture, retaining its statement, short deduction and permanent label. When it requires multiple premises, name them all and keep the other incoming references. A navigation tree must not falsely turn a dependency graph into a single-premise chain. A special case may be nested as a specialization; an analogy or historically related result is not a corollary. Do not force unrelated results into a hierarchy for visual symmetry.

For height programmes, distinguish local Green-form existence, global descent to cycle classes, independence of choices, comparison and functoriality, positivity, and finiteness whenever the source treats these as separate obligations. Establishing one does not silently provide the others. In particular, do not infer a global pairing from local existence alone or a finiteness theorem from positivity on a rational vector space alone. Preserve exact original tests, support complements and field descent requirements where the source imposes them.

## Use mathematical headings and retain genuine gaps

Choose headings that name the actual objects and property: for example, “Height pairings on algebraically trivial cycles”, “Descent to rational equivalence”, or “Finite extension of the ground field”, but only when those subjects match the section. Avoid inventing an impressive-sounding name for a standard construction, using an internal round code as the heading, or replacing a precise heading by an empty one such as “The next stage”. An already good title needs no change.

Distinguish three kinds of limitations. An essential hypothesis belongs in its statement. A genuine unsolved mathematical step belongs in the programme or progress account, with its reason and downstream effect. An editorial uncertainty about missing files or an unverified transcription belongs in the editorial record; report it to the reader if it changes the advertised completeness. Delete redundant disclaimers, not these mathematical distinctions. Do not describe a conditional geometric deduction as an unconditional theorem merely because its remaining analytic input has a separate name.

Keep exhaustive bookkeeping in the maintainer's coverage record rather than in the article's introduction. Within the requested scope, retain every recovered case, full available proof, partial argument and material gap somewhere in the linked formal account. A cleaner page may move details; it must not silently discard them.

## Respect authorship and delivery choices

Preserve manuscript authorship by default. When the user requests unsigned programme papers, apply that policy only to those papers and all their deliverables: LaTeX author commands, HTML bylines and author metadata, and PDF author metadata. Check the rendered title and document properties, including metadata produced automatically by the class. Preserve bibliography author names, quoted attribution, copyright or license notices, and contributions in source records. Do not replace the removed byline with the assistant's or agent's name.

Before delivery, compare the overview, formal statements, proofs, programme implications and PDF against the same source version. Check that every claimed consequence has its actual premises, that partial results remain partial, that each proof locator reaches the right argument, and that the article can be read independently. Record mathematical fidelity, editorial quality, and technical export checks separately.
