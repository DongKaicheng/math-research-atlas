# Editing decisions

Use the smallest intervention that resolves a concrete reading difficulty. Diagnose the mathematical job of a passage before editing its sentences.

| Reader difficulty | Intervention | Evidence to look for | Avoid |
|---|---|---|---|
| A construction arrives without a purpose | State the constraint it must satisfy, then construct it | The next inference actually uses that constraint | An empty sentence announcing a powerful construction |
| A proof lists lemmas without explaining their roles | Connect each lemma's output to the next lemma's input | Objects and hypotheses match in the source | Replacing the proof by a list of names |
| A choice of constants seems arbitrary | State the inequalities the choice must meet | Each dependency is allowed by the quantifier order | Making a constant uniform in an extra parameter |
| A paragraph is locally clear but its place is unclear | State the reduction it completes, or move it near its use | Dependency map and actual later use | A motivational sentence at every paragraph |
| Principal theorems read like a catalogue | Connect the previous result's output with the next result's task | A genuine dependency, remaining difficulty, or application | A generic announcement between every two environments |
| The statement is precise but its value is unclear | Explain what its conclusion enables on the stated class | A construction, deduction, equivalence, or obstacle addressed in the manuscript | Praise, invented applications, or an unsupported priority claim |
| Notation appears before the reader can parse it | Give the sufficient definition first; postpone construction details | Type, domain, and conditions are explicit | Putting every background definition before the main result |
| A proof hides its key step behind “standard” or “clearly” | Write the decisive estimate or name the precise standard result | Supplied argument or an independently checked reference | Inventing a plausible bridge |
| Routine calculation buries the point | Retain the key identity and explain its consequence | Omitted steps are routine for the intended reader | Removing a nontrivial limiting or uniformity argument |
| The argument is already economical and checkable | Leave it unchanged or make a local correction | No identifiable reader difficulty | Rewriting merely to demonstrate activity |

## Research prose

Prefer “The bound is independent of j, so …” to “This crucial estimate plays a pivotal role.” Name what follows from the bound. Prefer “We descend the map through the quotient” followed by the reason it is well-defined to “We establish a robust descent framework.”

Do not equate naturalness with conversational informality. Keep ordinary research conventions such as “Let”, “It remains to prove”, “By Lemma …”, and “We now show” when they carry real transitions. Do not ban “Moreover” or “Note that” regardless of context. Repetition of a mathematical term is often more precise than synonym variation.

Treat examples, analogies, slogans, headings, and proof sketches as tools with a cost. Use them only when they reduce a specific difficulty. In a paper, one sentence explaining why a construction is chosen is often more useful than a pedagogical digression.

## Delete defensive commentary

Read a candidate sentence in context, then try removing it. If the reader loses no understanding of the theorem, proof mechanism, or relationship between results, delete it. In particular, do not restate formal hypotheses as a list of extensions that the paper does not prove. A sentence beginning “We do not claim”, “No representation is required”, or “This should not be confused with” is a prompt for judgment, not an automatic deletion rule. A positive paraphrase of a redundant disclaimer is still redundant.

The user's sentences “No representation of h as a piecewise-linear or logarithmic function is required” and “Theorem 1.2 concerns continuous potentials; it does not assert a monotone convergence theorem for bounded discontinuous ones” are deletion cases in the supplied context. Their deletion does not authorize broadening a theorem's data or convergence class.

Put an essential condition in the theorem or definition, and explain its role at the inference that uses it. Preserve useful counterexamples, obstructions, and contrasts that resolve a real ambiguity. In a requested progress account or research programme, retain an actual outstanding inference, the reason it is needed, and the conclusion it blocks; these are part of the mathematical content. Keep administrative uncertainty and reviewer cautions in editorial notes; do not convert them into defensive prose in the paper.

## Decide whether a Remark earns its place

For every existing or proposed Remark, choose keep, merge, move into ordinary prose, or delete. Keep one only for independent mathematics: a useful consequence, a subtle hypothesis, a nontrivial link between theories, an equivalent formulation, or a counterexample demonstrating a real boundary. Verify the deduction or comparison.

Delete a Remark that repeats a theorem, narrates a citation already visible in the proof, or merely lists unrelated unproved extensions. Retain a precise open case when it is part of the requested programme, placing it with its mathematical role rather than attaching a warning to every result. Move a short necessary explanation to the relevant inference. Merge overlapping observations when their combined mathematical point is clearer. Do not attach a Remark to every citation, known-result combination, or technical step; a nontrivial combination earns one only if there is a separate mathematical observation to communicate.

## Paragraph and section organization

Give each paragraph a mathematical function: state an object, isolate an obstacle, perform a construction, establish an estimate, pass to a limit, or apply a result. Combine paragraphs that repeat the same function without progress. Split a paragraph if it contains two substantial transitions that need different assumptions.

Distinguish dependency order from reading order. A technical lemma may be proved later if its statement is available and the later proof does not depend on the result currently being proved. A main theorem may appear early, with its terminology defined sufficiently and its proof deferred. Check all moved references.

Maintain a section map only for long tasks. A useful entry is “§5: prove restriction positivity, needed to construct the ambient metric in §6”; an unhelpful entry is “§5: present technical results.” Preserve an existing good architecture rather than manufacture new section titles.

Name the mathematical content, not the editorial process. For a section constructing deterministic complete intersections, prefer “Deterministic complete-intersection approximation” to “Inputs and scope of the deterministic argument”. Inspect headings such as “Preparation”, “Technical ingredients”, “General framework”, and “Key observations” in context; retain one if it is genuinely the clearest description, otherwise replace it with the actual construction or estimate or remove an unnecessary subdivision. Do not create parallel headings merely for symmetry.

## Main text and appendices

Do not use appendices as the default destination for difficult mathematics. For each existing or proposed appendix, identify its mathematical role, where its statements are used, and why separating it helps the reader. Core constructions, key estimates, and arguments needed to understand the main mechanism normally belong in the body near their use. Merge closely related material into substantive subsections rather than multiplying top-level sections.

An appendix can be justified for a long self-contained auxiliary proof whose statement and role are clear in the body, an optional alternative proof, detailed background, or supplementary computations. A proof's length alone is not a reason to move it out of the main argument. There is no required appendix count; a paper may need none. Do not shorten the paper by discarding mathematical dependencies or sending required arguments to an unspecified external supplement.

Before moving material, check its definitions, hypotheses, and dependencies. Retain enough statement-level information for an explicitly deferred lemma. Move an application after its prerequisites when this improves the reading order. Preserve labels and proof content; update the Introduction, contents, section descriptions, references to “above/below”, and any appendix return links. Recompile to resolve the new numbering and check the actual destinations. Describe the editorial relocation separately from mathematical verification.

## Proof editing

Write a proof's opening around its actual task. If one implication is immediate and the other requires a construction, separate them. Before introducing an auxiliary object, identify the property it must provide. At the central estimate, specify which assumption controls each term when that allocation is not obvious.

Distinguish exposition repair from mathematical repair. Expanding a telescoping identity or applying an already stated lemma can be editorial. Supplying a missing compactness hypothesis, restricting a theorem's domain, or proving a new continuity result is a substantive change. Preserve the original assertion and flag the issue outside the article unless the user authorizes a correction.

When using a standard theorem, give its name or precise citation and verify the needed hypotheses from the source. Do not insert “by dominated convergence” if no integrable dominating function is available. Do not use “by compactness” to hide which space is compact or which finite subcover/subsequence is chosen.

## Allocate proofs and citations

Assume the target researcher knows the field's standard background. Classify each proposed shortening:

| Source relationship | Editorial treatment |
|---|---|
| Exact theorem already proved in a checked source | Cite its precise locator, matching hypotheses and conclusion; keep local notation conventions needed to apply it. |
| Immediate consequence | Cite the input and give the short deduction or specialization. |
| Nontrivial combination of known results | Explain what each gives and check the interfaces: domains, regularity, topology, uniformity, and constants. Retain the nontrivial bridge. |
| New argument in this manuscript | Keep the complete reasoning needed for its substantive steps. |

Existing bibliography keys do not establish coverage. If the source cannot be checked, preserve the necessary proof and record the unverified attribution separately. Never replace a nontrivial argument by “standard”, or imply novelty because the same mathematics has different terminology. A citation normally belongs in the proof sentence; it does not require a Remark.

## Advanced geometric writing

Respect distinctions which fluent paraphrase can erase: metric versus weight, function versus current, a form versus its associated current, actual test forms versus a smaller family, ordinary opens versus analytic domains, pullback along an arbitrary map versus a permitted map, a prescribed support complement versus a smaller one, and positivity versus membership in an approximation class.

Explain these distinctions at their point of use when they drive the argument. Do not turn them into a repetitive disclaimer in every section. A comparison with another theory must specify the hypotheses and construction being compared. Do not invent novelty from different terminology.

## Learning from preferences

Record feedback as an edit with a reason, not as “make it more human.” Useful feedback distinguishes a needless roadmap from a missing proof mechanism. Keep task type and source context with accepted/rejected edits. Use accepted edits as later examples only with the user's approval; keep held-out evaluation passages separate.
