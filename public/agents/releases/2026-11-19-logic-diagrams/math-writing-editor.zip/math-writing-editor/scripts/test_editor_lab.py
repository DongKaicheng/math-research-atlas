"""Integrity tests for evaluation tooling; these do not test writing quality."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import editor_lab as lab


def run(func, **kwargs):
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream):
        func(SimpleNamespace(**kwargs))
    return json.loads(stream.getvalue())


class EvaluationIntegrity(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def regression(self):
        trial = self.root / "regression"
        run(lab.regressions, out_dir=str(trial))
        inputs = json.loads((trial / "inputs.json").read_text())
        rubric = json.loads((trial / "rubric.json").read_text())
        responses = json.loads((trial / "responses.template.json").read_text())
        review = json.loads((trial / "review.template.json").read_text())
        source = {c["id"]: c["source"] for c in inputs["cases"]}
        for cid, item in responses["cases"].items():
            action = rubric[cid]["expected_actions"][0]
            item.update(action=action, text="" if action == "delete" else source[cid],
                        notes="Engineering fixture; not a semantic evaluation.")
            for judgment in review["cases"][cid].values():
                judgment.update(status="pass", evidence="Engineering fixture only.")
        response_path, review_path = self.root / "responses.json", self.root / "review.json"
        response_path.write_text(lab.json_text(responses))
        review.update(responses_sha256=lab.digest(response_path.read_bytes()),
                      reviewer_kind="model", reviewer="Integrity test fixture",
                      independence="same_session")
        review_path.write_text(lab.json_text(review))
        return trial, responses, review, response_path, review_path

    def report(self, fixture, rehash=False):
        trial, responses, review, rp, vp = fixture
        rp.write_text(lab.json_text(responses))
        if rehash:
            review["responses_sha256"] = lab.digest(rp.read_bytes())
        vp.write_text(lab.json_text(review))
        return run(lab.regression_report, trial_dir=str(trial), responses=str(rp), review=str(vp))

    def test_valid_deletions_and_explicit_review_origin(self):
        result = self.report(self.regression())
        self.assertEqual(result["counts"], {"pass": len(result["cases"]), "fail": 0, "uncertain": 0})
        self.assertEqual(result["independence"], "same_session")

    def test_missing_case_rejected(self):
        f = self.regression()
        f[1]["cases"].pop("continuous-coefficients")
        with self.assertRaisesRegex(ValueError, "every regression"):
            self.report(f, rehash=True)

    def test_stale_review_rejected(self):
        f = self.regression()
        f[1]["cases"]["mathematical-heading"]["text"] = "Changed after review"
        with self.assertRaisesRegex(ValueError, "different responses"):
            self.report(f)

    def test_keep_is_literal(self):
        f = self.regression()
        f[1]["cases"]["no-change-proof"]["text"] += " A new paragraph."
        with self.assertRaisesRegex(ValueError, "keep must preserve"):
            self.report(f, rehash=True)

    def test_missing_evidence_rejected(self):
        f = self.regression()
        f[2]["cases"]["representation-disclaimer"]["delete"]["evidence"] = ""
        with self.assertRaisesRegex(ValueError, "missing judgment"):
            self.report(f)

    def test_packet_tampering_rejected(self):
        f = self.regression()
        (f[0] / "inputs.json").write_text("{}")
        with self.assertRaisesRegex(ValueError, "packet changed"):
            self.report(f)

    def test_review_failure_and_uncertainty_remain_visible(self):
        f = self.regression()
        f[2]["cases"]["continuous-coefficients"]["support"]["status"] = "uncertain"
        f[2]["cases"]["citation-only-remark"]["remark"]["status"] = "fail"
        result = self.report(f)
        self.assertEqual(result["counts"], {"pass": len(result["cases"]) - 2, "fail": 1, "uncertain": 1})

    def comparison(self):
        for name in ("source", "first", "second"):
            (self.root / name).write_text("A short source-grounded proof.")
        trial = self.root / "blind"
        run(lab.blind, source=str(self.root / "source"),
            candidate=[str(self.root / "first"), str(self.root / "second")], out_dir=str(trial))
        ratings = json.loads((trial / "public/ratings.template.json").read_text())
        ratings.update(reviewer_kind="model", reviewer="Engineering fixture")
        for item in ratings["candidates"].values():
            item.update(math_fidelity="pass", fidelity_evidence="Fixture")
            item["scores"] = dict.fromkeys(lab.DIMENSIONS, 4)
            item["evidence"] = dict.fromkeys(lab.DIMENSIONS, "Fixture")
            for audit in item["audits"].values():
                audit.update(status="pass", evidence="Fixture")
        return trial, ratings

    def test_logic_gate_and_technical_separation(self):
        trial, ratings = self.comparison()
        ratings["candidates"]["A"]["audits"]["statement_logic"]["status"] = "uncertain"
        ratings["candidates"]["B"]["audits"]["technical"]["status"] = "fail"
        path = self.root / "ratings.json"
        path.write_text(lab.json_text(ratings))
        result = run(lab.report, trial_dir=str(trial), ratings=str(path))
        self.assertIsNone(result["candidates"][0]["eligible_editorial_mean"])
        self.assertEqual(result["candidates"][1]["audits"]["technical"]["status"], "fail")
        self.assertEqual(result["candidates"][1]["eligible_editorial_mean"], 4)

    def test_legacy_reports_explicitly_lack_new_audits(self):
        trial, ratings = self.comparison()
        key_path = trial / "private-key.json"
        key = json.loads(key_path.read_text())
        key["schema_version"] = ratings["schema_version"] = 1
        for item in ratings["candidates"].values():
            item.pop("audits")
        key_path.write_text(lab.json_text(key))
        path = self.root / "ratings.json"
        path.write_text(lab.json_text(ratings))
        result = run(lab.report, trial_dir=str(trial), ratings=str(path))
        self.assertIn("legacy", result["candidates"][0]["audits"])

    def test_existing_example_selection(self):
        result = run(lab.examples, task="proof", limit=1, query="neumann")
        self.assertEqual(result[0]["id"], "neumann-mechanism")

    def test_programme_example_selection(self):
        self.assertIn("programme", lab.TASKS)
        result = run(lab.examples, task="programme", limit=1, query="quotient descent")
        self.assertEqual(result[0]["id"], "quotient-pairing-programme")
        self.assertIn("not human approved", result[0]["provenance"])

    def test_programme_regressions_are_included_without_rubric_leakage(self):
        f = self.regression()
        inputs = json.loads((f[0] / "inputs.json").read_text())
        expected = {
            "progress-heading-pairing", "programme-conditional-descent",
            "retain-programme-gap", "consequence-hierarchy", "summary-is-not-proof",
            "unsigned-programme", "preserve-default-authorship", "positivity-and-finiteness",
        }
        self.assertTrue(expected.issubset({c["id"] for c in inputs["cases"]}))
        for case in inputs["cases"]:
            self.assertEqual(set(case), {"id", "provenance", "context", "source"})

    def test_programme_keep_action_still_requires_exact_source(self):
        f = self.regression()
        f[1]["cases"]["retain-programme-gap"]["text"] = "The quotient construction is complete."
        with self.assertRaisesRegex(ValueError, "keep must preserve"):
            self.report(f, rehash=True)


if __name__ == "__main__":
    unittest.main()
