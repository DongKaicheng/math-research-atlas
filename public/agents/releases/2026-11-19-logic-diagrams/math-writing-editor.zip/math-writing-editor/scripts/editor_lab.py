#!/usr/bin/env python3
"""Select editing examples and prepare auditable blind comparisons. No API calls."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import secrets
import sys

DIMENSIONS = ("mainline", "mechanism", "detail", "prose")
TASKS = ("proof", "definition", "introduction", "structure", "programme", "lecture")
AUDITS = ("statement_logic", "redundancy", "technical")
ACTIONS = ("keep", "delete", "merge", "move", "rewrite", "flag")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_text(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def read_text(path):
    text = Path(path).read_text(encoding="utf-8")
    if not text.strip():
        raise ValueError(f"Empty text file: {path}")
    return text


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fence(text):
    runs = re.findall(r"`+", text)
    delimiter = "`" * max(3, 1 + max(map(len, runs), default=0))
    return f"{delimiter}text\n{text.rstrip()}\n{delimiter}\n"


def examples(args):
    require(1 <= args.limit <= 3, "Choose one to three examples.")
    path = Path(__file__).resolve().parents[1] / "references/editorial-cases.json"
    cases = json.loads(path.read_text(encoding="utf-8"))
    eligible = [item for item in cases if args.task in item["tasks"]]
    terms = set(re.findall(r"\w+", args.query.lower()))
    eligible.sort(key=lambda item: -len(terms & set(re.findall(
        r"\w+", json.dumps(item, ensure_ascii=False).lower()))))
    print(json_text(eligible[:args.limit]), end="")


def blind(args):
    require(2 <= len(args.candidate) <= 10, "Supply two to ten candidates.")
    paths = [Path(p).resolve() for p in args.candidate]
    require(len(set(paths)) == len(paths), "Candidate paths must be distinct.")
    source = read_text(args.source)
    candidates = [(p, read_text(p)) for p in paths]
    secrets.SystemRandom().shuffle(candidates)
    out = Path(args.out_dir).resolve()
    # Read and validate all inputs before creating an output directory.
    require(not out.exists(), "Output directory already exists; choose a new trial name.")
    sections = ["# Mathematical writing comparison\n",
                "Compare the candidates with the source. Judge fidelity separately from "
                "exposition. Cite concrete passages, permit ties, and do not infer generator "
                "identity. The source may itself contain a gap; distinguish preservation "
                "from independent mathematical verification.\n",
                "## Source\n", fence(source)]
    key = {"schema_version": 2, "source_path": str(Path(args.source).resolve()),
           "source_sha256": digest(source.encode()), "candidates": {}}
    ratings = {"schema_version": 2, "reviewer_kind": None, "reviewer": None,
               "candidates": {}}
    for index, (path, content) in enumerate(candidates):
        label = chr(ord("A") + index)
        sections.extend([f"## Candidate {label}\n", fence(content)])
        key["candidates"][label] = {
            "path": str(path), "sha256": digest(content.encode())}
        ratings["candidates"][label] = {
            "math_fidelity": None, "fidelity_evidence": "",
            "audits": {name: {"status": None, "evidence": ""} for name in AUDITS},
            "scores": {dimension: None for dimension in DIMENSIONS},
            "evidence": {dimension: "" for dimension in DIMENSIONS}}
    packet = "\n".join(sections)
    packet_hash = digest(packet.encode())
    key["packet_sha256"] = ratings["packet_sha256"] = packet_hash
    out.mkdir(parents=True, exist_ok=False)
    public = out / "public"
    public.mkdir()
    (public / "review.md").write_text(packet, encoding="utf-8")
    (public / "ratings.template.json").write_text(json_text(ratings), encoding="utf-8")
    private_path = out / "private-key.json"
    with private_path.open("x", encoding="utf-8") as stream:
        stream.write(json_text(key))
    private_path.chmod(0o600)
    print(json_text({"review_packet": str(public / "review.md"),
                     "ratings_template": str(public / "ratings.template.json"),
                     "private_key": str(private_path),
                     "instruction": "Give the reviewer only the two public files."}), end="")


def report(args):
    trial = Path(args.trial_dir)
    key = json.loads((trial / "private-key.json").read_text(encoding="utf-8"))
    ratings = json.loads(Path(args.ratings).read_text(encoding="utf-8"))
    version = key.get("schema_version")
    require(version in (1, 2) and ratings.get("schema_version") == version,
            "Unsupported schema version.")
    packet_hash = digest((trial / "public/review.md").read_bytes())
    require(packet_hash == key.get("packet_sha256") == ratings.get("packet_sha256"),
            "Packet hash mismatch: review the exact original packet.")
    require(ratings.get("reviewer_kind") in ("human", "model", "mixed"),
            "Declare reviewer_kind as human, model, or mixed.")
    require(isinstance(ratings.get("reviewer"), str) and ratings["reviewer"].strip(),
            "Record the reviewer identity or description.")
    require(isinstance(ratings.get("candidates"), dict) and
            set(ratings["candidates"]) == set(key["candidates"]),
            "Rate every candidate exactly once; labels must match the packet.")
    rows = []
    for label, candidate in key["candidates"].items():
        item = ratings["candidates"][label]
        require(isinstance(item, dict), f"{label}: expected an object.")
        fidelity = item.get("math_fidelity")
        require(fidelity in ("pass", "fail", "uncertain"),
                f"{label}: invalid fidelity judgment.")
        require(isinstance(item.get("fidelity_evidence"), str) and
                item["fidelity_evidence"].strip(), f"{label}: missing fidelity evidence.")
        scores, evidence = item.get("scores"), item.get("evidence")
        require(isinstance(scores, dict) and set(scores) == set(DIMENSIONS),
                f"{label}: supply all four editorial scores.")
        require(isinstance(evidence, dict) and set(evidence) == set(DIMENSIONS),
                f"{label}: supply evidence for all four dimensions.")
        for dimension in DIMENSIONS:
            require(type(scores[dimension]) is int and 1 <= scores[dimension] <= 5,
                    f"{label}/{dimension}: score must be an integer from 1 to 5.")
            require(isinstance(evidence[dimension], str) and evidence[dimension].strip(),
                    f"{label}/{dimension}: missing evidence.")
        audits = item.get("audits", {})
        if version == 2:
            require(isinstance(audits, dict) and set(audits) == set(AUDITS),
                    f"{label}: supply statement-logic, redundancy, and technical audits.")
            for name, audit in audits.items():
                allowed = ("pass", "fail", "uncertain", "not_applicable") if name == "technical" else ("pass", "fail", "uncertain")
                require(isinstance(audit, dict) and audit.get("status") in allowed
                        and isinstance(audit.get("evidence"), str) and audit["evidence"].strip(),
                        f"{label}/{name}: missing status or evidence.")
        eligible = fidelity == "pass" and (version == 1 or audits["statement_logic"]["status"] == "pass")
        average = sum(scores.values()) / len(DIMENSIONS) if eligible else None
        rows.append({"label": label, "candidate_path": candidate["path"],
                     "math_fidelity": fidelity, "scores": scores,
                     "eligible_editorial_mean": average,
                     "fidelity_evidence": item["fidelity_evidence"], "evidence": evidence,
                     "audits": audits or {"legacy": "Not collected in schema 1"}})
    eligible = [row for row in rows if row["eligible_editorial_mean"] is not None]
    best = max((row["eligible_editorial_mean"] for row in eligible), default=None)
    leaders = [row["label"] for row in eligible if row["eligible_editorial_mean"] == best]
    result = {"schema_version": version, "declared_reviewer_kind": ratings["reviewer_kind"],
              "reviewer": ratings["reviewer"], "packet_sha256": packet_hash,
              "candidates": rows, "highest_rated_eligible_labels": leaders,
              "interpretation": "Single-review judgments. Fidelity is a reviewer gate, "
              "not a proof certificate. Means do not establish general superiority."}
    print(json_text(result), end="")


def regressions(args):
    path = Path(__file__).resolve().parents[1] / "references/regression-cases.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    require(data.get("schema_version") == 1, "Unsupported regression schema.")
    cases = data["cases"]
    ids = [case["id"] for case in cases]
    require(len(ids) == len(set(ids)) and ids, "Regression IDs must be unique.")
    out = Path(args.out_dir)
    require(not out.exists(), "Output directory already exists; choose a new trial.")
    inputs = {"schema_version": 1, "instruction":
              "Use math-writing-editor to edit each passage in its supplied context. "
              "Return the revised text and separate any unresolved mathematical issue. "
              "Choose keep, delete, merge, move, rewrite, or flag.",
              "cases": [{k: c[k] for k in ("id", "provenance", "context", "source")} for c in cases]}
    raw = json_text(inputs)
    source_hash = digest(raw.encode())
    rubric = {c["id"]: {"expected_actions": c["expected_actions"],
                       "criteria": c["criteria"]} for c in cases}
    template = {"schema_version": 1, "inputs_sha256": source_hash,
                "cases": {cid: {"action": None, "text": "", "notes": ""} for cid in ids}}
    review = {"schema_version": 1, "inputs_sha256": source_hash,
              "responses_sha256": None, "reviewer_kind": None, "reviewer": "",
              "independence": None,
              "cases": {c["id"]: {item["id"]: {"status": None, "evidence": ""}
                                  for item in c["criteria"]} for c in cases}}
    out.mkdir(parents=True)
    (out / "inputs.json").write_text(raw, encoding="utf-8")
    (out / "responses.template.json").write_text(json_text(template), encoding="utf-8")
    (out / "review.template.json").write_text(json_text(review), encoding="utf-8")
    (out / "rubric.json").write_text(json_text(rubric), encoding="utf-8")
    (out / "manifest.json").write_text(json_text({
        "inputs_sha256": source_hash, "rubric_sha256": digest(json_text(rubric).encode())}), encoding="utf-8")
    print(json_text({"trial_dir": str(out.resolve()), "cases": len(ids),
                     "instruction": "Generate from inputs.json first; review against rubric.json afterward. "
                     "These are known regression cases, not a blind or held-out benchmark."}), end="")


def regression_report(args):
    trial = Path(args.trial_dir)
    raw_inputs = (trial / "inputs.json").read_bytes()
    raw_rubric = (trial / "rubric.json").read_bytes()
    manifest = json.loads((trial / "manifest.json").read_text())
    require(digest(raw_inputs) == manifest["inputs_sha256"]
            and digest(raw_rubric) == manifest["rubric_sha256"], "Regression packet changed.")
    inputs, rubric = json.loads(raw_inputs), json.loads(raw_rubric)
    raw_responses = Path(args.responses).read_bytes()
    responses = json.loads(raw_responses)
    review = json.loads(Path(args.review).read_text(encoding="utf-8"))
    require(responses.get("schema_version") == review.get("schema_version") == 1,
            "Unsupported response/review schema.")
    require(responses.get("inputs_sha256") == review.get("inputs_sha256") == digest(raw_inputs),
            "Input hash mismatch.")
    require(review.get("responses_sha256") == digest(raw_responses), "Review refers to different responses.")
    require(review.get("reviewer_kind") in ("human", "model", "mixed")
            and isinstance(review.get("reviewer"), str) and review["reviewer"].strip(),
            "Declare reviewer kind and identity.")
    require(review.get("independence") in ("same_session", "fresh_reviewer"),
            "Declare same_session or fresh_reviewer; no implied independent review.")
    source = {c["id"]: c["source"] for c in inputs["cases"]}
    require(isinstance(responses.get("cases"), dict) and isinstance(review.get("cases"), dict)
            and set(responses["cases"]) == set(review["cases"]) == set(rubric),
            "Supply every regression case exactly once.")
    rows = []
    for cid, expected in rubric.items():
        response, judgments = responses["cases"][cid], review["cases"][cid]
        require(isinstance(response, dict) and response.get("action") in ACTIONS
                and isinstance(response.get("text"), str) and isinstance(response.get("notes"), str),
                f"{cid}: invalid response.")
        action, text = response["action"], response["text"]
        require(text.strip() or action == "delete", f"{cid}: only deletion can have empty text.")
        require(action != "keep" or text == source[cid], f"{cid}: keep must preserve the source.")
        require(action != "flag" or response["notes"].strip(), f"{cid}: flag needs an editorial note.")
        criteria = {item["id"] for item in expected["criteria"]}
        require(isinstance(judgments, dict) and set(judgments) == criteria,
                f"{cid}: review every criterion exactly once.")
        statuses = []
        for criterion, judgment in judgments.items():
            require(isinstance(judgment, dict) and judgment.get("status") in ("pass", "fail", "uncertain")
                    and isinstance(judgment.get("evidence"), str) and judgment["evidence"].strip(),
                    f"{cid}/{criterion}: missing judgment or evidence.")
            statuses.append(judgment["status"])
        action_matches = action in expected["expected_actions"]
        status = ("fail" if not action_matches or "fail" in statuses
                  else "uncertain" if "uncertain" in statuses else "pass")
        rows.append({"id": cid, "action": action, "status": status, "criteria": judgments})
    print(json_text({"schema_version": 1, "reviewer_kind": review["reviewer_kind"],
                     "reviewer": review["reviewer"], "independence": review["independence"],
                     "counts": {s: sum(row["status"] == s for row in rows)
                                for s in ("pass", "fail", "uncertain")},
                     "cases": rows, "interpretation":
                     "Packet integrity and completeness are checked automatically. "
                     "Semantic outcomes are the named reviewer's judgments, not automated proof "
                     "verification or evidence of general superiority."}), end="")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    example_parser = subparsers.add_parser("examples", help="Select task-matched editing cases")
    example_parser.add_argument("--task", choices=TASKS, required=True)
    example_parser.add_argument("--limit", type=int, default=2)
    example_parser.add_argument("--query", default="", help="Optional words describing the difficulty")
    example_parser.set_defaults(run=examples)
    blind_parser = subparsers.add_parser("blind", help="Randomize and anonymize candidate file identities")
    blind_parser.add_argument("--source", required=True)
    blind_parser.add_argument("--candidate", action="append", required=True)
    blind_parser.add_argument("--out-dir", required=True)
    blind_parser.set_defaults(run=blind)
    report_parser = subparsers.add_parser("report", help="Validate ratings and reveal the comparison")
    report_parser.add_argument("--trial-dir", required=True)
    report_parser.add_argument("--ratings", required=True)
    report_parser.set_defaults(run=report)
    regression_parser = subparsers.add_parser("regressions", help="Prepare contextual feedback cases")
    regression_parser.add_argument("--out-dir", required=True)
    regression_parser.set_defaults(run=regressions)
    regression_report_parser = subparsers.add_parser("regression-report", help="Validate regression responses and review evidence")
    regression_report_parser.add_argument("--trial-dir", required=True)
    regression_report_parser.add_argument("--responses", required=True)
    regression_report_parser.add_argument("--review", required=True)
    regression_report_parser.set_defaults(run=regression_report)
    args = parser.parse_args()
    try:
        args.run(args)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
