# Site selection for public distribution

This distributable intentionally contains no owner's private Site IDs,
authentication details, or workspace paths. Follow the user's explicit site
URL and the actual repository's publication instructions. Inspect the host's
current tools, preserve audience, and check before updating. Do not assume
that an unrelated site is the user's target or that deployment is automatic.
