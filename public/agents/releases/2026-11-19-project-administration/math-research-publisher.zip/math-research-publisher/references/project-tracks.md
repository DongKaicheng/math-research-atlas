# Two distinct mathematical publication tracks

Choose `project.category` explicitly at first import: `foundations` or `research`. The category is a publication and workflow designation, not a mathematical truth status. Preserve it on later revisions unless the owner requests reclassification.

| | Foundational theory integration | New theory and conjectures |
| --- | --- | --- |
| Primary mathematical agent | `math-project-maintainer` (Stacks-style corpus workflow) | `math-research-publisher`, with `math-project-maintainer` for exact records and review |
| Core objects | Definitions, conventions, lemmas, theorems, exact proofs, dependencies, chapters | Conjectures, questions, partial results, proof attempts, obstacles, research programme |
| Ingest | Existing foundational LaTeX corpus and maintainer's `mathproject.json`, immutable snapshots and IDs | Specific user-approved research files, result registers, exact proofs and research handoff files |
| Organization | Dependency-sensitive chapters and theorem/definition navigation, stable tag-like URLs | Motivation, conjectures, available results and proofs, alternative routes, long-term goals |
| Update | Source impact analysis on hypotheses, contexts, applications and downstream theorems before publication | Compare changed claims, proof status and dependencies; retain open questions and programme history |
| Review | Distinguish proved, reviewed, admitted external theorem, and formalized/Lean-checked with precise evidence | Distinguish open, draft, conditional, proved, reviewed, withdrawn; never promote exploratory work automatically |
| Reader contribution | Corrections to definitions/theorems, reference repairs, new complete proofs, formalization | Questions, counterexamples, proof submissions, refinements, new routes and Lean contributions |

## Foundation workflow

1. Recover the maintainer's real project root, `mathproject.json`, source entrypoints, and latest snapshot/checkpoint. Do not invent a new parallel theorem database.
2. Ask the maintainer to identify exact source IDs, contexts, theorem statements and proofs, selected logical support, named external inputs and review evidence. Preserve stable IDs and chapter hierarchy in the website export.
3. Expose definitions/theorems and their dependencies with stable links. Never reclassify all theorems as conjectures or attach a generic "proof programme" to a complete foundational chapter.
4. On corrections, trace downstream impact, update the actual source, re-review affected claims and then release a new public version. Keep old version URLs valid.

## Original research workflow

1. Import only explicitly selected conjectures and research programmes from the current authoritative materials. Keep author-proposed speculation, conditional lemmas and reviewed results distinct.
2. Publish exact conjecture hypotheses, motivation, what is proved (with complete proof if available), current obstruction and concrete milestones. Cite source snapshots.
3. Accept questions, corrections, references, potential proofs and formalization via the moderated feedback mechanism. Treat them as leads requiring review, never as automatically approved mathematical text.
4. Use the writer for concise mathematical exposition once claims are stable. Revise programme and mathematical records separately; the website may describe an active route without asserting a theorem.

For the research presentation, follow [research publication](research-publication.md): complete the recovered-case inventory, organize supported implications and consequences, separate summaries from complete unsigned or signed papers according to the project instruction, and give each paper a working standalone PDF. Put precise programme problems and conditional deductions in the paper rather than substituting a task list for mathematics.

## Site and contribution requirements

- On an umbrella site containing both tracks, expose `Foundations` and `Conjectures & New Theory` separately and retain the category selector in its editor. On a dedicated single-project site, show only that project's useful navigation; do not add empty tracks, other projects, or a compulsory dashboard. A foundations page foregrounds definitions, statements, full proofs and dependencies; a research page foregrounds the mathematical motivation, conjectures and progress, with formal details on linked paper pages.
- Preserve anonymous public reading and stable routes for every published ID. Use SEO titles, canonical URLs and sitemap entries appropriate to the category. Do not create unrequested subject placeholder projects; unpublished drafts may exist privately.
- Preserve the site's approved feedback visibility and moderation policy. Do not make historical private submissions public. Store the exact referenced entry/revision, category, original text, permitted attribution and resolution, and link any resulting correction to a new immutable revision.
- When general feedback is part of the site, route it separately from theorem feedback; do not invent a mathematical project or fake revision to collect it. Preserve an existing manifesto/general-feedback route rather than injecting a manifesto into every dedicated research site. Project/entry-level mathematical feedback is bound to exact theorem and publication versions.
- Invite Lean formalization work without marking entries machine-checked until actual source, formal theorem statement, checker version and outcome have been inspected and recorded.
