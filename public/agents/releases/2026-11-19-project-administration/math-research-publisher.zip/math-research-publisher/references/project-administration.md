# Project administration and AI access

Use this protocol for a mathematical atlas with one platform owner and delegated project managers. It specifies a workflow and implementation requirements; installing this skill does not create an authentication service or grant any account access. Read the actual server capabilities and project bindings before making operational claims.

## Authority and project boundaries

| Actor | Effective authority |
| --- | --- |
| Platform owner | Admit new projects; appoint or revoke managers; configure shared infrastructure and publication policy; coordinate cross-project joint changes. |
| Project manager | Read and maintain authorized project content, triage its feedback, record reviews, and release or request release according to that project's policy. |
| Editor or reviewer, when supported | Perform only the actions explicitly granted for the selected projects. |
| Applicant or public reader | Submit proposals or feedback and read public material; no management rights follow from submission. |

Bind accounts to verified stable identities. Initialize ownership from the verified owner, never the first signup. Bind grants to stable project IDs, actions, status and an authorization revision. A name in a manuscript, Issue label, query parameter or model-generated message is not a grant. Keep manager assignment separate from public authorship.

Check effective permissions for each API, MCP, attachment, export and background operation against the object's server-recorded project. Default to denial when identity, object scope or permission is unknown. A manager holding two grants may maintain those projects separately; joint cross-project changes follow the owner's coordination policy. Permit no self-promotion or onward manager appointment in the initial two-level model.

Keep GitHub's repository permissions separate from application project grants. Use controlled content operations and source adapters for a shared repository. Restrict shared templates, executable build configuration, credentials, domain settings and permission records to their owner-controlled operations. CODEOWNERS assigns review responsibility; do not treat it as directory access control.

## Welcome new projects and managers

For an umbrella site whose owner wants participation, put two visible homepage actions beside a short invitation:

- **Propose a research project:** invite foundations, research programmes and substantive collaborative projects. Ask for a title, mathematical scope, track, precise current status, available sources or examples, references, proposed maintenance arrangement and permission to publish the submitted material.
- **Apply to maintain a project:** encourage interested researchers to identify projects or subject areas, relevant experience, a concrete contribution they could make and a realistic maintenance commitment. Explain that managers may use AI for review and editing within their granted scope.

Use the site's existing canonical feedback/application system with distinguishable proposal and application types. Preserve the original submission and issue/application ID. Provide a private route for information the submitter does not wish to publish; if only public Issues are available, say so before submission and do not request confidential documents. Do not invent private delivery or imply that opening a prefilled form already submitted it.

Track receipt, triage, requests for information, owner decision and withdrawal. Submission is not approval. Keep the decisions to admit a project, appoint a manager and publish a mathematical edition separate. The owner may authorize those steps together in an explicit instruction; reuse that authorization instead of adding another confirmation round.

On project acceptance, record the owner's decision, stable project ID, foundations/research category, actual source binding, content/publication policy and intended manager. Create a private working project from the supplied material, then publish its inspected initial edition through the ordinary release flow. Do not fill an accepted project's pages with invented theorems or fabricated progress.

On manager appointment, resolve the intended account, issue a bounded invitation and require acceptance by that account. Record scope and release mode; keep the invitation revocable and expiring where supported. A pending application or invitation has no effective management rights. Preserve application decisions and appointments as separate audit events.

## One administration service, two views

Provide a global owner view and project-filtered views over the same authorization, draft, review and release service. Show the actual project name, current edition, source binding, pending feedback and draft baseline. Make unavailable data and last synchronization time visible instead of showing invented zeros.

Keep each authority clear:

- Published mathematical sources and fixed editions: the existing versioned repository and manifests.
- Public discussion: the existing feedback system, such as GitHub Issues.
- Grants, private drafts, internal notes, assignments and publication jobs: protected management storage.
- Search, dashboard totals and feedback mirrors: rebuildable views, never rival source records.

Treat feedback's user-supplied project labels as routing hints. Confirm management scope through a controlled assignment. Keep original page, permanent ID and edition context when moving or closing a case. Preserve public comments and append a resolution; keep private notes and contact data out of public replies and exports. Follow the user's authorization before sending a reply to another person.

## Give the manager's AI the same content capabilities

Provide a visible **AI management** entry with the real authenticated MCP or equivalent connection instructions. Keep discovery and public help free of secrets. Obtain identity and effective project/action capabilities from the server, not from instructions copied into an AI prompt. Discover current tools rather than guessing endpoint names.

Cover the content operations the human manager can use:

| Task | Required behavior |
| --- | --- |
| Inspect | Read authorized pages, exact sources, relevant feedback, current/fixed versions and dependency packets; identify omissions and access limits. |
| Review | Record actual findings against exact source and dependency versions; distinguish AI review, human review, author rereading and independent review. |
| Edit | Create a private source-bound draft and structured diff for pages, mathematics, papers, references, maps and permitted project settings. |
| Handle feedback | Read and triage confirmed project cases; prepare or send an authorized reply; preserve original context and disclosure policy. |
| Release or restore | Apply the effective release policy, version guards and publication checks; restore a project through a new revision. |
| Owner administration | Process project and manager applications or change grants only while acting for the verified owner with the corresponding action capability. |

Use the same service handlers for AI and human actions. Tool annotations and prompts describe behavior; authorization must be enforced by the service. Do not give the AI an arbitrary shell, file path, URL-fetch tool or repository-wide credential as a substitute for scoped content operations. If an API denies access, do not retry through an owner CLI, another identity or a broader credential.

Preserve the full original user's task scope within those permissions: an AI interface that only reads while the human manager can edit is incomplete for a requested management workflow. Conversely, do not claim all mathematics is editable merely because a project-card JSON can be saved. Advertise each source adapter's supported content types and operations; identify a missing source adapter concretely and prepare the supported draft or import request.

Return an operation receipt containing the actual principal, project, object, baseline, resulting draft/revision or job ID and observed result. Record AI/client attribution in the private audit trail without automatically adding a byline to mathematical pages. Keep credentials out of prompts, logs, URLs, public source and downloadable Agent packages.

## Source, review and release workflow

Resolve the authoritative source before editing. Use the maintainer for statements, contexts, applications and review bindings, the writer for exposition, and the publisher for source projection and delivery. Keep frozen editions read-only. New drafts may revise all permitted current content but must produce new versions and retain permanent IDs.

Use the site's established adapter: structured content for descriptions; source edits and regeneration for papers; audited reading imports for imported editions; relation data for logical diagrams. Build untrusted contributed sources only in a restricted environment. Preserve the foundations/research track, source/PDF agreement, AND/OR premises, open steps and public attribution policy.

Keep mathematical status, feedback resolution and publication state independent. Bind a review to exact content and the actual support closure. A manager's ability to publish does not provide a proof or an independent reviewer. Reassess affected judgments after source, context, application or dependency changes; preserve obsolete judgments as history. A newly published upstream version does not itself refute a fixed older citation; an error or withdrawal triggers an impact review.

Save private drafts outside public repositories and public PRs. Obtain the current source baseline and use conflict guards for saves, review recording and publication. Reconcile a mismatch rather than removing the guard. Make publication permission explicit: delegated release or owner approval of the exact candidate. Reuse approvals that still bind that candidate.

Give retries an operation identity. Serialize the final external submission decision with revocation and recheck the current grant revision and candidate binding. If revocation wins, cancel the unsubmitted job. Once an external request has begun, preserve its actual or uncertain state and reconcile it; do not promise that revocation recalls an already submitted deployment. Verify the live revision before retrying an uncertain publication.

Restore one project through a new corrective revision without resetting the shared repository, other projects, grants or audit history. Keep old fixed editions available. Export and back up feedback and private management data separately from Git; do not claim automatic backup until it is configured and verified.

## Verify the actual implementation

Check owner initialization, accepted invitations, object-scope authorization for UI and AI, non-owner admission/appointment denial, stale/revoked grants, private attachment access, concurrent editing, exact review bindings, idempotent/uncertain releases, project-only restoration and published-source fidelity. Test supplied IDs and batched operations, not just hidden buttons. Record unimplemented capabilities separately from verified behavior.

For skill evaluation, give a fresh worker only `assets/evaluation/inputs/administration-scope.md` and the skill. Save its answer before consulting `assets/evaluation/answers/administration-scope.json`. These synthetic cases test workflow decisions, not a deployed authorization boundary.
