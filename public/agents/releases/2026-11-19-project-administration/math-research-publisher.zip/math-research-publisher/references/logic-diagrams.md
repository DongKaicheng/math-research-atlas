# Publish mathematical logical diagrams

Build a diagram that explains what each argument uses and supplies. Recover the exact statement, proof and programme records before choosing the layout. Keep the graph a derived view of those records; drawing or publishing it does not change their mathematical status.

## Reuse the mathematical graph

Load the installed `math-project-maintainer` and its `references/logic-diagrams.md`. Use its `math-logic-map/v1` contract and `scripts/logic_map.py` tools when the project lacks a compatible graph implementation. Resolve the loaded skill directory and inspect the actual command help. Let the maintainer validate the source-bound logical data; let this publisher integrate it into the website. Do not create a competing theorem database or a second independently edited graph.

For that portable workflow, use the resolved directory and the project's exact graph and sources:

```bash
python3 <maintainer-dir>/scripts/logic_map.py validate graph.json --source-root <source-root>
python3 <maintainer-dir>/scripts/logic_map.py render graph.json --output <new-output-directory> --source-root <source-root>
python3 <maintainer-dir>/scripts/logic_map.py verify graph.json --output <output-directory> --source-root <source-root>
```

The outputs include SVG, HTML, DOT and an artifact manifest. Use native Mermaid for a small figure when the output medium supports it, preserving the same logical semantics. Passing structural checks binds the declared records and artifacts; inspect their actual mathematical justification separately. If source files are unavailable, report that limitation rather than treating the omitted source check as completed.

For a site with canonical logical records, extend its existing generator and preserve IDs, anchors, statuses and source bindings. Reuse the same mathematical invariants even when its schema differs. A diagram page ID or relation ID is not automatically a permanent theorem ID.

Use these relation meanings consistently:

| Relation | Visible meaning |
| --- | --- |
| Deduction | All displayed inputs and additional hypotheses supply the stated conclusion. |
| Proof input | The linked argument uses this input; the edge alone need not be sufficient. |
| Open step | The precise missing inference remains identified and linked. |
| Blocked shortcut | The specified inference or method fails; distinguish this from a refuted target. |

Show joint premises through **AND**. Show **OR** only for separate sufficient routes to the same scoped conclusion; keep each route's own joint premises and conditions. Alternative research ideas remain proposed routes. Mark analogies, reading order and topic membership separately from mathematical support. Preserve shared inputs and cross-branch connections instead of forcing the support graph into a single-parent tree.

## Offer useful reading levels

Give a requested overall map a clear homepage navigation link and a stable page or fragment. For a large project provide a principal-route view, a complete view of the selected corpus, and focused branch/proof diagrams. Disclose the scope and any omitted branches in a principal view. A complete view must account for every source record in its declared scope; do not add connecting arrows merely to make independent components look unified.

Let each node open its full statement and exact status. Let each relation label open one canonical record containing all premises, all additional hypotheses, the conclusion, why the connection holds, and precise proof/source links. Share those records across views. Preserve labels and URLs when a result moves; retain an alias or explicit redirect where required.

## Preserve readable geometry

Prefer code-generated SVG or the site's established vector renderer for exact diagrams. Use short conventional mathematical titles and enough space for readable text. Use top-down layouts with scoped clusters or focused diagrams; simplify geometry before shrinking fonts. Keep layout-only edges invisible and absent from the displayed mathematical relation list. Label relation types as well as colouring them.

For a large canvas provide node location/highlighting, bounded zoom, fit-to-width for orientation, and a readable-size reset. Finding a node should make its text readable. Make the toolbar keyboard accessible and touch-friendly. Keep wide graph scrolling inside its own container so the document itself does not overflow.

Generate a connected HTML reading view from the same records. On narrow screens show its explicit premises, relation, conclusion and full conditions, with links to the canonical proof details. Do not replace a multi-input argument with a flat list of titles. Provide this view without requiring hover, colour perception or successful SVG interaction.

## Keep feedback and revisions coherent

Use the existing shared feedback board. Overall-map feedback carries the project, page fragment and applicable edition, with no invented theorem ID. Relation feedback carries its exact page fragment and version. General site feedback remains available without a result or version. Publishing a comment does not automatically change a mathematical assertion.

Bind generated artifacts to the exact graph input, relevant source versions, ambient scopes and renderer. Rebuild and check affected views when any binding changes. Reuse the project's history protections; preserve frozen editions and previous anchors. Treat a layout revision separately from a mathematical revision, while recording both accurately.

## Verify the delivered view

Compare rendered node and relation identities with the canonical records, including the complete premise set at each AND gate and the independently sufficient routes at OR gates. Check that an open step or blocker has not acquired a deduction style. Verify duplicate IDs, source destinations, disclosure expansion and old deep links. Exercise the actual homepage entry, node locator, representative relation/proof links, shared feedback context, keyboard controls and a narrow viewport. Inspect text size, clipping and page overflow in rendered screenshots.

Keep structural validation, mathematical source review, visual inspection and live deployment as separate recorded observations. A valid schema or a successful build is not a proof audit or evidence that the live page works.
