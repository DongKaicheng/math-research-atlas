# Check a mathematical website edition

Keep mathematical, document-integrity, interface and deployment checks separate. None of these is a formal proof certificate. Use the project's existing checks first, and this small read-only checker when local rendered HTML/PDF files are available.

## Artifact manifest and command

Make a derived edition manifest in the project, not another authoritative result database. Bind actual source and PDF bytes with SHA-256. Use relative file paths inside one root. Include all affected overview/paper pages, important entry links and formal section anchors. A paper route must refer to a separate HTML article, and its PDF link must be a real anchor to a PDF asset.

```json
{
  "schemaVersion": 1,
  "title": "The full mathematical project title",
  "edition": "v1.2",
  "origin": "https://research.example.org",
  "authorPolicy": "omit",
  "pages": [
    {"route": "/", "file": "rendered/index.html", "kind": "home"},
    {"route": "/results", "file": "rendered/results.html", "kind": "overview"},
    {"route": "/papers/programme", "file": "rendered/programme.html", "kind": "paper"}
  ],
  "papers": [{
    "id": "programme",
    "route": "/papers/programme",
    "pdfRoute": "/pdf/programme-v1.2.pdf",
    "pdfFile": "public/pdf/programme-v1.2.pdf",
    "pdfSha256": "<actual SHA-256>",
    "source": {"file": "papers/programme.tex", "sha256": "<actual SHA-256>"},
    "anchors": ["problem-descent", "proof-reduction"]
  }],
  "entryLinks": [
    {"from": "/", "to": "/papers/programme"},
    {"from": "/results", "to": "/papers/programme#proof-reduction"}
  ]
}
```

```bash
python3 <skill-dir>/scripts/check_publication.py <manifest.json> --root <project-root>
python3 -m unittest discover -s <skill-dir>/scripts/tests -p 'test_*.py'
```

For signed papers use `authorPolicy: "preserve"`. If an edition has different author policies, validate each policy-scoped group separately. Do not anonymize cited references. Old HTML anchors and PDF editions should stay reachable; list important retained URLs in the manifest or test their redirects through the site's integration checks.

The checker reads HTML and source/PDF files without executing TeX, JavaScript or fetching URLs. It rejects path escape, duplicate routes/IDs, missing article pages, missing important links/anchors, stale byte bindings and obvious non-PDF downloads. If `pdfinfo` is installed it also parses PDFs and checks the author field for unsigned papers. Author detection in TeX/HTML catches common patterns, not arbitrary macros or all visible bylines. An unavailable parser is reported as unchecked. Success checks artifact consistency only: a correctly hashed PDF can still contain the wrong theorem or an incomplete proof.

## Required editorial checks

1. **Coverage and logic.** Reconcile the previous/current result inventory by stable IDs. Include recovered partial cases and exact gaps. Check each displayed implication against its complete premises and evidence; distinguish AND premises, OR routes, special cases and prospective arrows. Use the maintainer's research-outline audit where applicable. A hidden/collapsed child must remain reachable.
2. **Formal writing.** Read the linked paper, not only the card summary. Check complete definitions, hypotheses, actual proof text, conditional arguments, formal research problems and references. Compare HTML, PDF and source of the same edition. Preserve existing proof bodies and source anchors when only presentation changed; inspect prose changes as well as formula counts.
3. **Titles and attribution.** Read headings without their internal project context. Use standard mathematical terms, not round IDs or newly invented labels. Verify the requested full title and scoped signed/unsigned policy in HTML, PDF metadata and visible pages. Keep citation authors and provenance.
4. **Visible actions.** Inspect computed/displayed size, colour contrast, weight, underline/border and focus of the actual paper/proof/PDF links. Exercise keyboard disclosure and navigation. Check long labels at desktop and narrow widths. Normally target a comfortable roughly 44 px activation area for prominent controls; do not apply a rigid minimum to every inline mathematical citation.
5. **Publication.** Check live page responses, exact downloaded PDF bytes, formal anchors and approved audience. A protected production page is not anonymous-readable; do not bypass it. Test anonymous access and search directives only where public access is authorized. Distinguish local preview from deployment and indexing.

Record what was actually observed, and leave unavailable checks explicitly outstanding. Do not fill “passed” fields from an intended implementation, test counts, another model's agreement or a previous edition's screenshot. Keep this QA record outside the papers.

## Regression tasks

When updating the skill, use fresh, task-local fixtures in addition to the structural tests. Ask a fresh worker to organize mixed complete/partial cases, a conditional multi-premise implication and an independent route; to revise a sparse Plan into a rigorous programme; or to inspect rendered links and a mismatched PDF. Give only raw material and the task, not expected findings. Review afterwards for preserved coverage, exact premises, useful hierarchy, true paper/PDF separation, mature terminology and honest verification limits. A fixture regression is not proof of general writing superiority.

The reusable input is `assets/evaluation/inputs/publication-plan.md`. Give a worker only that packet and the skill. Consult `assets/evaluation/answers/publication-plan.json` only after the response is complete. The packet is a synthetic regression derived from observed failure patterns, not a recovered research manuscript or a held-out benchmark.
