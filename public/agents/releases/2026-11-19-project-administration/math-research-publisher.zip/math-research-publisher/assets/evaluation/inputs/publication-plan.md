# Publication request

Use math-research-publisher for this offline request. Return revised homepage text, a page hierarchy and a publication-check plan. Do not edit a live website or publish. Treat this packet as the entire supplied source.

Make a dedicated website for **Height Pairings and Green Forms**. Keep it simple, include all our partial results, organize implications together, separate summaries from full unsigned papers, and make proof links obvious.

This is a separate single research project, unrelated to an earlier umbrella site. Snapshot s12 records:

- P: a conditional construction of a bilinear pairing on U^r(X) × U^s(X), r+s=n+1, assuming local hypotheses L and rational-equivalence reciprocity R. Its proof is reported available in pairing.tex at thm-pairing.
- Q: restriction of P to A^r × A^s for proved inclusions A^r ⊂ U^r and A^s ⊂ U^s. Proof is reported at cor-restriction.
- C: construction of local Green forms for geometric class C. The norm identity R is still open for this class.
- D: a chat mentions a broader case; its claimed proof archive is absent.
- M: an independent model construction on V^r × V^s assuming supplied regular models and admissible lifts. The proof is reported in model.tex. Comparison between U and V is open.

The Plan draft says “First solve local geometry. Then all heights and positivity follow.” No positivity theorem or precise positivity conjecture is supplied. The original draft intends positivity as a further research objective.

The mock homepage is called “HGF Lab”. P, Q, C, D and M appear as peer cards. A ten-paragraph audit log precedes the motivating question. “Read paper” links to /results, a 150-word overview. “Download PDF” calls window.print(). No source bytes, full article, rendered inspection or deployment is supplied.

This synthetic packet describes publication and source-availability issues; it does not assert new height theorems.
