import copy
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import check_publication as cp
import publish_math as pm


class PublicationChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.title = 'Heights and Green Forms'
        self.home = self.write('home.html', '<title>Heights and Green Forms</title>'
            '<h1>Heights and Green Forms</h1><a href="/papers/green">Read the formal paper</a>')
        self.overview = self.write('results.html', '<h1>Height pairings</h1>'
            '<a href="/papers/green#proof-main">Read the proof</a>')
        self.html = self.write('green.html', '<title>Green forms</title><article>'
            '<h1>Green forms</h1><h2 id="proof-main">Proof of the main result</h2>'
            '<a href="/pdf/green.pdf">Download PDF</a></article>')
        self.tex = self.write('green.tex', '\\documentclass{article}\n\\author{}\n'
            '\\begin{document}\\section{Green forms}\\end{document}\n')
        self.pdf = self.root / 'green.pdf'
        # Header fixture: PDF parsing is mocked in these unit tests, not certified.
        self.pdf.write_bytes(b'%PDF-1.4\nunit-test fixture\n%%EOF\n')
        self.manifest = {
            'schemaVersion': 1, 'title': self.title, 'edition': 'v1',
            'origin': 'https://research.example.org', 'authorPolicy': 'omit',
            'pages': [{'route': '/', 'file': 'home.html', 'kind': 'home'},
                      {'route': '/results', 'file': 'results.html', 'kind': 'overview'},
                      {'route': '/papers/green', 'file': 'green.html', 'kind': 'paper'}],
            'papers': [{'id': 'green', 'route': '/papers/green',
                        'pdfRoute': '/pdf/green.pdf', 'pdfFile': 'green.pdf',
                        'pdfSha256': cp.digest(self.pdf),
                        'source': {'file': 'green.tex', 'sha256': cp.digest(self.tex)},
                        'anchors': ['proof-main']}],
            'entryLinks': [{'from': '/', 'to': '/papers/green'},
                           {'from': '/results', 'to': '/papers/green#proof-main'}]}
        self.addCleanup(patch.stopall)
        patch('check_publication.shutil.which', return_value='/usr/bin/pdfinfo').start()
        self.pdfinfo = patch('check_publication.subprocess.run', return_value=
            subprocess.CompletedProcess([], 0, 'Pages: 1\nAuthor: \nProducer: test\n', '')).start()

    def write(self, filename, text):
        path = self.root / filename
        path.write_text(text, encoding='utf-8')
        return path

    def check(self):
        return cp.check(self.manifest, self.root)

    def fails(self, text):
        result = self.check()
        self.assertFalse(result['valid'], result)
        self.assertIn(text, '\n'.join(result['errors']))

    def test_complete_artifact_links_keep_verification_limits(self):
        result = self.check()
        self.assertTrue(result['valid'], result)
        self.assertEqual(result['paperCount'], 1)
        self.assertFalse(result['proofCorrectnessVerified'])
        self.assertFalse(result['visualQualityVerified'])
        self.assertFalse(result['liveAccessVerified'])
        self.assertEqual(result['warnings'], [])

    def test_abbreviated_home_title(self):
        self.write('home.html', '<title>HGF</title><h1>HGF</h1>')
        self.fails('full project title')

    def test_summary_cannot_be_formal_paper(self):
        self.manifest['papers'][0]['route'] = '/results'
        self.fails('own registered paper page')

    def test_relabelled_summary_is_not_a_separate_page(self):
        self.manifest['pages'][2]['file'] = 'results.html'
        self.fails('reuses another page file')

    def test_missing_paper_body(self):
        self.write('green.html', '<h1>Green forms</h1><a href="/pdf/green.pdf">PDF</a>')
        self.fails('article element')

    def test_print_button_is_not_pdf_download(self):
        self.write('green.html', '<article><h1>Green forms</h1><h2 id="proof-main">Proof</h2>'
            '<button onclick="window.print()">Download PDF</button></article>')
        self.fails('real anchor')

    def test_link_must_exist_in_rendered_html(self):
        self.write('home.html', '<title>Heights and Green Forms</title><h1>Heights and Green Forms</h1>')
        self.fails('absent from the rendered page')

    def test_proof_fragment_is_not_just_a_valid_page(self):
        self.manifest['entryLinks'][1]['to'] = '/papers/green#proof-absent'
        self.write('results.html', '<a href="/papers/green#proof-absent">Proof</a>')
        self.fails('target section anchor is missing')

    def test_declared_formal_anchor(self):
        self.manifest['papers'][0]['anchors'] = ['problem-absent']
        self.fails('missing formal section anchor')

    def test_duplicate_ids(self):
        self.write('green.html', self.html.read_text() + '<div id="proof-main"></div>')
        self.fails('duplicate HTML IDs')

    def test_duplicate_page_route(self):
        self.manifest['pages'].append(copy.deepcopy(self.manifest['pages'][0]))
        self.fails('duplicate page route')

    def test_no_unregistered_paper_can_skip_pdf_checks(self):
        self.write('other.html', '<article><h1>Other paper</h1></article>')
        self.manifest['pages'].append({'route': '/papers/other', 'file': 'other.html', 'kind': 'paper'})
        self.fails('missing its source/PDF registry record')

    def test_empty_html_attributes_do_not_crash(self):
        self.write('green.html', self.html.read_text() + '<meta name><p class>Text</p>')
        self.assertTrue(self.check()['valid'])

    def test_source_revision_changed(self):
        self.write('green.tex', self.tex.read_text() + '% revised mathematical source\n')
        self.fails('source bytes differ')

    def test_pdf_revision_changed(self):
        self.manifest['papers'][0]['pdfSha256'] = '0' * 64
        self.fails('PDF bytes differ')

    def test_html_returned_as_pdf(self):
        self.pdf.write_text('<html>Sign in</html>')
        self.manifest['papers'][0]['pdfSha256'] = cp.digest(self.pdf)
        self.fails('not a PDF file')

    def test_broken_pdf_parsing(self):
        self.pdfinfo.return_value = subprocess.CompletedProcess([], 1, '', 'error')
        self.fails('could not parse')

    def test_unsigned_html_metadata(self):
        self.write('green.html', self.html.read_text() + '<meta name="author" content="A Researcher">')
        self.fails('HTML author metadata')

    def test_unsigned_visible_byline(self):
        self.write('green.html', self.html.read_text() + '<p class="byline">A Researcher</p>')
        self.fails('byline')

    def test_unsigned_pdf_metadata(self):
        self.pdfinfo.return_value = subprocess.CompletedProcess([], 0, 'Author: A Researcher\nPages: 1\n', '')
        self.fails('PDF contains author metadata')

    def test_unsigned_tex_author(self):
        self.write('green.tex', '\\author{A Researcher}\n')
        self.manifest['papers'][0]['source']['sha256'] = cp.digest(self.tex)
        self.fails('source contains author data')

    def test_unsigned_hyperref_author(self):
        self.write('green.tex', '\\hypersetup{pdfauthor={A Researcher}}\n')
        self.manifest['papers'][0]['source']['sha256'] = cp.digest(self.tex)
        self.fails('source contains author data')

    def test_citation_attribution_is_preserved(self):
        self.write('green.tex', '\\author{}\n\\hypersetup{pdfauthor={}}\n'
            '\\bibitem{source} A. Researcher, Green forms.\n')
        self.write('green.html', self.html.read_text() + '<div class="bib-author">A. Researcher</div>')
        self.manifest['papers'][0]['source']['sha256'] = cp.digest(self.tex)
        self.assertTrue(self.check()['valid'])

    def test_signed_policy_does_not_anonymize(self):
        self.manifest['authorPolicy'] = 'preserve'
        self.write('green.tex', '\\author{A Researcher}\n')
        self.write('green.html', self.html.read_text() + '<meta name="author" content="A Researcher">')
        self.manifest['papers'][0]['source']['sha256'] = cp.digest(self.tex)
        self.pdfinfo.return_value = subprocess.CompletedProcess([], 0, 'Author: A Researcher\nPages: 1\n', '')
        self.assertTrue(self.check()['valid'])

    def test_unavailable_pdf_tool_is_not_passed_metadata(self):
        with patch('check_publication.shutil.which', return_value=None):
            result = self.check()
        self.assertTrue(result['valid'])
        self.assertIn('unchecked', result['warnings'][0])

    def test_path_traversal(self):
        self.manifest['papers'][0]['source']['file'] = '../outside.tex'
        self.fails('inside the artifact root')

    def test_symlink_escape(self):
        with tempfile.TemporaryDirectory() as outside:
            path = Path(outside) / 'source.tex'
            path.write_text('private')
            (self.root / 'escape.tex').symlink_to(path)
            self.manifest['papers'][0]['source']['file'] = 'escape.tex'
            self.fails('outside the root')

    def test_cross_origin_is_not_the_actual_entry_link(self):
        self.write('results.html', '<a href="https://unrelated.example/papers/green#proof-main">Proof</a>')
        self.fails('absent from the rendered page')

    def test_absolute_same_origin_link(self):
        self.write('results.html', '<a href="https://research.example.org/papers/green#proof-main">Proof</a>')
        self.assertTrue(self.check()['valid'])

    def test_relative_links_and_trailing_slash(self):
        self.assertEqual(cp.destination('green.pdf', '/papers/green/', self.manifest['origin']),
                         ('/papers/green/green.pdf', ''))
        self.assertEqual(cp.route('/papers/green/'), '/papers/green/')
        self.assertEqual(cp.destination('#p', '/papers/green', self.manifest['origin']),
                         ('/papers/green', 'p'))

    def test_route_guard(self):
        for invalid in ('//example.org', '/%2e%2e/out', '/%2f%2fexample.org', '/paper?x=1'):
            with self.subTest(route=invalid), self.assertRaises(ValueError):
                cp.route(invalid)

    def test_malformed_records_report_errors(self):
        self.manifest['papers'].append(None)
        self.manifest['pages'].append(False)
        self.manifest['entryLinks'].append([])
        self.fails('expected object')


class ExistingBundleContract(unittest.TestCase):
    def entry(self, identifier, dependencies):
        return {'id': identifier, 'kind': 'result', 'title': 'Result', 'summary': 'Summary',
                'statement': 'Statement', 'proof': 'Argument', 'status': 'proved',
                'dependencies': dependencies, 'references': []}

    def bundle(self):
        return {'schemaVersion': 1, 'project': {'id': 'test-project', 'category': 'research',
            'title': 'Test', 'summary': 'Summary', 'authors': [], 'keywords': [],
            'motivation': '', 'programme': ''},
            'entries': [self.entry('RES-A', []), self.entry('RES-B', ['RES-A'])]}

    def test_existing_bundle_remains_valid(self):
        self.assertTrue(pm.validate(self.bundle())['valid'])

    def test_no_silent_cycle(self):
        b = self.bundle()
        b['entries'][0]['dependencies'] = ['RES-B']
        self.assertFalse(pm.validate(b)['valid'])

    def test_upstream_content_changes_support_binding(self):
        b = self.bundle()
        before = pm.support_hash(b, 'RES-B')
        b['entries'][0]['statement'] = 'Changed premise'
        self.assertNotEqual(before, pm.support_hash(b, 'RES-B'))

    def test_upstream_status_changes_support_binding(self):
        b = self.bundle()
        before = pm.support_hash(b, 'RES-B')
        b['entries'][0]['status'] = 'conditional'
        self.assertNotEqual(before, pm.support_hash(b, 'RES-B'))


if __name__ == '__main__':
    unittest.main()
