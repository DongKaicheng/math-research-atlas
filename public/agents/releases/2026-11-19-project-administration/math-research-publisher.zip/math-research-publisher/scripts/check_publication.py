#!/usr/bin/env python3
"""Check local paper routes, anchors, source bindings and standalone PDF assets.

This read-only artifact check does not judge mathematical fidelity, visual quality,
or live access. The manifest is a derived edition view, not a theorem database.
"""
import argparse
import hashlib
from html.parser import HTMLParser
import json
import posixpath
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
from urllib.parse import unquote, urlsplit

from publish_math import load_json


class Page(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.ids = set()
        self.duplicate_ids = set()
        self.links = []
        self.author_markers = []
        self.title = ''
        self.h1 = ''
        self.articles = 0
        self._title = self._h1 = False
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attributes):
        attrs = {key: value or '' for key, value in attributes}
        identifier = attrs.get('id')
        if identifier:
            if identifier in self.ids:
                self.duplicate_ids.add(identifier)
            self.ids.add(identifier)
        if tag == 'a' and attrs.get('href'):
            self.links.append(attrs['href'])
        if tag == 'title':
            self._title = True
        if tag == 'h1':
            self._h1 = True
        if tag == 'article':
            self.articles += 1
        if tag == 'meta' and (attrs.get('name', '').lower() == 'author' or
                              attrs.get('property', '').lower() == 'article:author'):
            if attrs.get('content', '').strip():
                self.author_markers.append('author metadata')
        if ('author' in attrs.get('itemprop', '').lower().split() or
                'author' in attrs.get('rel', '').lower().split() or
                'byline' in attrs.get('class', '').lower().split()):
            self.author_markers.append('author/byline element')

    def handle_endtag(self, tag):
        if tag == 'title':
            self._title = False
        if tag == 'h1':
            self._h1 = False

    def handle_data(self, data):
        if self._title:
            self.title += data
        if self._h1:
            self.h1 += data


def local_file(root, name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        raise ValueError('expected a nonempty project-relative file path')
    parts = PurePosixPath(name)
    if parts.is_absolute() or '..' in parts.parts:
        raise ValueError('path must stay inside the artifact root')
    resolved = (root / name).resolve(strict=True)
    if not resolved.is_relative_to(root) or not resolved.is_file():
        raise ValueError('path is outside the root or is not a regular file')
    return resolved


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def route(value):
    if not isinstance(value, str) or not value.startswith('/') or value.startswith('//'):
        raise ValueError('registry routes must be root-relative')
    parts = urlsplit(value)
    path = unquote(parts.path)
    if (parts.query or parts.fragment or '\\' in path or '\x00' in path or
            '..' in PurePosixPath(path).parts):
        raise ValueError('registry routes must be plain paths without traversal')
    if path.startswith('//'):
        raise ValueError('registry routes must not encode an external host')
    normalized = posixpath.normpath(path)
    return normalized + '/' if path.endswith('/') and normalized != '/' else normalized


def destination(href, current, origin):
    parts = urlsplit(href)
    if parts.scheme or parts.netloc:
        base = urlsplit(origin)
        if (parts.scheme and parts.scheme != base.scheme) or parts.netloc != base.netloc:
            return None
    path = unquote(parts.path)
    if not path:
        path = current
    elif not path.startswith('/'):
        path = posixpath.join(posixpath.dirname(current), path)
    normalized = posixpath.normpath(path)
    if path.endswith('/') and normalized != '/':
        normalized += '/'
    return (normalized, unquote(parts.fragment))


def check(manifest, root):
    root = Path(root).resolve(strict=True)
    errors, warnings = [], []
    def error(where, message):
        errors.append(f'{where}: {message}')
    def file(where, name):
        try:
            return local_file(root, name)
        except (OSError, ValueError) as exc:
            error(where, str(exc))
            return None
    def registered(where, value):
        try:
            return route(value)
        except (ValueError, TypeError) as exc:
            error(where, str(exc))
            return None
    if not isinstance(manifest, dict):
        return {'valid': False, 'errors': ['manifest must be an object']}
    if type(manifest.get('schemaVersion')) is not int or manifest['schemaVersion'] != 1:
        error('schemaVersion', 'expected integer 1')
    for key in ('title', 'edition'):
        if not isinstance(manifest.get(key), str) or not manifest[key].strip():
            error(key, 'expected nonempty string')
    if manifest.get('authorPolicy') not in ('preserve', 'omit'):
        error('authorPolicy', 'expected preserve or omit')
    origin = manifest.get('origin', '')
    try:
        u = urlsplit(origin)
        if (u.scheme not in ('https', 'http') or not u.hostname or u.username or u.password or
                u.path not in ('', '/') or u.query or u.fragment):
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        error('origin', 'expected HTTP(S) origin without credentials')
        origin = 'https://invalid.example'
    pages, page_files = {}, {}
    records = manifest.get('pages')
    if not isinstance(records, list) or not records:
        error('pages', 'expected nonempty page registry')
        records = []
    for i, rec in enumerate(records):
        where = f'pages[{i}]'
        if not isinstance(rec, dict):
            error(where, 'expected object')
            continue
        path = registered(where + '.route', rec.get('route'))
        source = file(where + '.file', rec.get('file'))
        if rec.get('kind') not in ('home', 'overview', 'paper'):
            error(where + '.kind', 'expected home, overview or paper')
        if path in pages:
            error(where, 'duplicate page route')
        if not path or not source:
            continue
        page = Page(source.read_text(encoding='utf-8'))
        pages[path] = (rec, page)
        page_files[path] = source
        if page.duplicate_ids:
            error(where, 'duplicate HTML IDs: ' + ', '.join(sorted(page.duplicate_ids)))
        if rec.get('kind') == 'home':
            title = manifest.get('title', '')
            normalized = lambda s: ' '.join(s.split())
            if (not isinstance(title, str) or normalized(title) not in normalized(page.title) or
                    normalized(title) not in normalized(page.h1)):
                error(where, 'home title and heading must contain the full project title')
    papers = manifest.get('papers')
    if not isinstance(papers, list) or not papers:
        error('papers', 'expected nonempty paper registry for this check')
        papers = []
    ids, pdf_routes, paper_routes = set(), set(), set()
    pdfinfo = shutil.which('pdfinfo')
    if not pdfinfo:
        warnings.append('pdfinfo unavailable: PDF parsing and PDF author metadata unchecked')
    for i, paper in enumerate(papers):
        where = f'papers[{i}]'
        if not isinstance(paper, dict):
            error(where, 'expected object')
            continue
        identifier = paper.get('id')
        if not isinstance(identifier, str) or not identifier.strip() or identifier in ids:
            error(where + '.id', 'expected unique nonempty paper ID')
        else:
            ids.add(identifier)
        path = registered(where + '.route', paper.get('route'))
        pdf_route = registered(where + '.pdfRoute', paper.get('pdfRoute'))
        if path in paper_routes:
            error(where, 'paper route is reused')
        if pdf_route in pdf_routes or pdf_route in pages:
            error(where, 'PDF route is reused or points to an HTML page')
        paper_routes.add(path)
        pdf_routes.add(pdf_route)
        record, page = pages.get(path, ({}, None))
        if record.get('kind') != 'paper' or not page:
            error(where, 'paper requires its own registered paper page')
        elif not page.articles or not page.h1.strip():
            error(where, 'paper page requires an article element and a title heading')
        if path in page_files:
            aliases = [p for p, f in page_files.items() if f == page_files[path] and p != path]
            if aliases:
                error(where, 'paper reuses another page file instead of a separate article')
        if page:
            if manifest.get('authorPolicy') == 'omit' and page.author_markers:
                error(where, 'unsigned paper contains HTML author metadata or a byline')
            if (pdf_route, '') not in [destination(x, path, origin) for x in page.links]:
                error(where, 'paper has no real anchor to its standalone PDF')
            anchors = paper.get('anchors', [])
            if not isinstance(anchors, list) or any(not isinstance(a, str) or not a for a in anchors):
                error(where + '.anchors', 'expected array of nonempty HTML IDs')
            else:
                for anchor in anchors:
                    if anchor not in page.ids:
                        error(where, 'missing formal section anchor ' + anchor)
        source_rec = paper.get('source')
        if not isinstance(source_rec, dict):
            error(where + '.source', 'expected file and sha256 binding')
            source_rec = {}
        tex = file(where + '.source.file', source_rec.get('file'))
        if tex:
            if digest(tex) != source_rec.get('sha256'):
                error(where + '.source.sha256', 'source bytes differ from edition binding')
            if manifest.get('authorPolicy') == 'omit' and tex.suffix == '.tex':
                source_text = re.sub(r'(?m)(?<!\\)%.*$', '', tex.read_text(encoding='utf-8'))
                if (re.search(r'\\author(?:\[[^\]]*\])?\s*\{\s*[^\s}]', source_text) or
                        re.search(r'pdfauthor\s*=\s*(?:\{\s*[^\s}]|[^\s{,}])', source_text)):
                    error(where, 'unsigned source contains author data')
        pdf = file(where + '.pdfFile', paper.get('pdfFile'))
        if pdf:
            with pdf.open('rb') as stream:
                if not stream.read(5) == b'%PDF-':
                    error(where, 'PDF asset is not a PDF file')
            if digest(pdf) != paper.get('pdfSha256'):
                error(where + '.pdfSha256', 'PDF bytes differ from edition binding')
            if pdfinfo:
                try:
                    info = subprocess.run([pdfinfo, str(pdf)], capture_output=True, text=True, timeout=10)
                    if info.returncode:
                        error(where, 'pdfinfo could not parse the PDF')
                    elif manifest.get('authorPolicy') == 'omit' and re.search(r'(?m)^Author:[ \t]*\S[^\n]*', info.stdout):
                        error(where, 'unsigned PDF contains author metadata')
                except (OSError, subprocess.TimeoutExpired):
                    warnings.append(where + ': PDF parser unavailable or timed out; metadata unchecked')
    for path, (rec, _) in pages.items():
        if rec.get('kind') == 'paper' and path not in paper_routes:
            error(path, 'paper page is missing its source/PDF registry record')
    links = manifest.get('entryLinks')
    if not isinstance(links, list) or not links:
        error('entryLinks', 'list the primary paper and proof entry points to check')
        links = []
    for i, link in enumerate(links):
        where = f'entryLinks[{i}]'
        if not isinstance(link, dict):
            error(where, 'expected object')
            continue
        start = registered(where + '.from', link.get('from'))
        target = link.get('to')
        if not isinstance(target, str) or not target.startswith('/') or target.startswith('//'):
            error(where, 'expected root-relative target, with optional section fragment')
            continue
        end = destination(target, start or '/', origin)
        page = pages.get(start, ({}, None))[1]
        if page is None or end not in [destination(x, start, origin) for x in page.links]:
            error(where, 'declared entry link is absent from the rendered page')
        if not end or (end[0] not in pages and end[0] not in pdf_routes):
            error(where, 'target has no registered page or PDF asset')
        elif end[1] and (end[0] not in pages or end[1] not in pages[end[0]][1].ids):
            error(where, 'target section anchor is missing')
    return {'valid': not errors, 'errors': errors, 'warnings': warnings,
            'pageCount': len(pages), 'paperCount': len(papers), 'entryLinkCount': len(links),
            'proofCorrectnessVerified': False, 'visualQualityVerified': False,
            'liveAccessVerified': False,
            'remainingChecks': ['Mathematical coverage and fidelity against exact sources',
                                'Same-source HTML/PDF content and full proof inspection',
                                'Desktop, narrow-layout, focus and disclosure inspection',
                                'Live routes, downloads and intended audience']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest')
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    try:
        result = check(load_json(args.manifest), args.root)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result['valid'] else 1
    except (OSError, ValueError, TypeError, UnicodeError) as exc:
        print(json.dumps({'valid': False, 'error': str(exc)}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
