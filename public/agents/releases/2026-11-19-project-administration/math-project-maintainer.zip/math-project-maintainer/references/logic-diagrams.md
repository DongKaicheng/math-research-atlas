# Logical diagrams and research maps

## Contents

- Recover the logical structure
- Choose the reading levels
- Use the portable renderer
- Maintain the graph contract
- Check the delivered diagram

## Recover the logical structure

Read exact statements, full proof passages, ambient conventions and the selected
release before extracting a connection. Reuse permanent mathematical IDs and
source locators. A diagram is a derived explanation of those records; it must
not become a second authority for mathematical status. Work from the selected
application records when the maintainer engine supplies them. A citation alone
does not tell whether a result is a premise, an analogy, or a passing mention.

For every connection recover its premises, conclusion, additional hypotheses,
mechanism and source. Keep object categories, quantifiers, degrees, test classes,
support, field, normalization, convergence and scope restrictions at the place
they operate. Shorten the box label only when its full statement and conditions
remain immediately accessible. Review every cross-branch bridge against its
actual proof: visual proximity is not mathematical evidence.

Use these meanings consistently:

| Relation | Display and meaning |
| --- | --- |
| `implication` | Solid deduction: every displayed premise is jointly required. |
| `conditional-implication` | Solid deduction with explicit additional hypotheses. |
| `proof-dependency` | Dashed proof input; it need not be sufficient for the conclusion. |
| `open-step` | Distinct dashed connection identifying the missing argument. |
| `obstruction` | A terminating bar marks the particular blocked shortcut. |

Represent `(A and H) => B` by `A,H -> AND -> B`. Never erase H to shorten a
principal view. An OR group joins separate sufficient arguments, each retaining
all its own premises and conditions. It does not join complementary proof
inputs, analogies, a chronological work order, or unresolved possible methods.
Show an open alternative as a separate open step, not a certified OR route.
Keep definitions, admitted hypotheses, external inputs, established results,
model cases, open claims, obstructions and withdrawn formulations distinguishable.

Preserve a grounded alternative even if the union of all arguments contains a
cycle. Reciprocal established implications may express an equivalence. Check
the chosen sufficient support plan separately: cyclic reliance on unproved
conclusions supplies no foundation. Do not solve this by silently deleting an
edge or declaring every node in a cyclic union unsupported.

## Choose the reading levels

Use a real dependency graph with shared premises and converging branches. A
tree may guide reading, but must retain links to all other mathematical inputs.
For a large project provide a compact principal map, a complete map of the
declared scope, and focused branch/proof diagrams. The principal map may omit
whole routes; it may not omit an input of a route it retains. State what the
complete map covers, and reconcile it against the source inventory rather than
equating machine coverage with recovery of every historical result.

Keep the topology top-down with short conventional labels. Aim for a few boxes
per row, natural readable type, adequate spacing and distinguishable line styles
as well as color. Use layout-only constraints invisibly; they must not appear
as mathematical arrows. Retain disconnected roots when the source does.

Reuse an existing project's canonical schema, renderer, permanent anchors and
tests. Integrate these invariants into it instead of maintaining a parallel
copy of its result database. The helper below is for a new project, a portable
figure, or an explicitly derived interchange record.

## Use the portable renderer

Run Python 3.10+ and an installed Graphviz `dot`. Inspect actual help first.
The validator uses the standard library; rendering invokes `dot` with a timeout
and does not fetch URLs, install software, or alter mathematical records.

```bash
python3 <skill-dir>/scripts/logic_map.py validate graph.json --source-root <sources>
python3 <skill-dir>/scripts/logic_map.py render graph.json --source-root <sources> --output <new-directory>
python3 <skill-dir>/scripts/logic_map.py verify graph.json --source-root <sources> --output <new-directory>
```

For URL-only provenance, omit `--source-root`; the report explicitly says that
remote bytes were not verified. If any source has a local path, supply its root
when rendering or verifying. Hash a source only after inspecting it; changing
the recorded hash to make a check pass does not resolve a mathematical change.

The output contains `graph.json`, `index.html`, one DOT/SVG pair for each view,
and a manifest binding graph content, version, generator/validator/assets and
exact artifacts. Rendering requires a new destination; integrate reviewed
changes into an existing site through its ordinary revision workflow. Verify
rejects a changed graph, source, renderer or output file. It establishes this
binding, not the correctness or completeness of the mathematics.

The HTML includes one canonical detail per node and relation, linked vector
views, full joint premises and additional hypotheses, and a connected text
projection. Use the text projection for narrow screens and detailed reading.
Node finding, highlighting, zoom and fit controls support larger canvases.
Fit-to-width is an orientation tool; retain a readable-size control. For a
short diagram directly in chat or a manuscript, native Mermaid or TikZ is also
appropriate. Preserve the same relation semantics; do not generate a raster
image for a precise mathematical graph.

The portable reader renders literal text, not TeX. Use short Unicode/plain-text
math labels, or the existing project's equation renderer for fully typeset
formulae. Keep the exported SVG beside `index.html`: standalone SVG hyperlinks
open that reader, while embedded SVG links open the local canonical records.

The bundled `assets/logic-map-example.json` and `assets/logic-map-example.md`
form a small supplied example. Their claims are elementary demonstrations,
not project research. Render with `--source-root <skill-dir>/assets`; copy the
example Markdown beside the exported HTML if its relative source link is used.

## Maintain the graph contract

Use JSON with schema `math-logic-map/v1`. Keep arrays explicit, including empty
`alternatives` and `conditions`. IDs use letters, numbers, dots, colons, hyphens
or underscores; the map and view IDs use lowercase hyphenated slugs. Node,
relation and alternative IDs are distinct. Do not replace permanent result IDs
with layout positions. Versions are exact source editions or snapshots.

| Field | Required content |
| --- | --- |
| `id`, `title`, `version`, `scope` | Map identity, reader title, exact source version and declared mathematical scope. |
| `sources` | `{id,label,href}`; optionally paired `path` and SHA-256 `sha256` for local bytes. Paths stay inside the supplied source root. |
| `nodes` | `{id,label,status,statement,scope,sourceIds,href?}`. Preserve the full assertion and its precise scope. |
| `relations` | `{id,label,kind,from,to,conditions,explanation,sourceIds,href?}`. `from` is the entire joint premise array; `to` is one conclusion. |
| `alternatives` | `{id,label,to,relations,explanation}`. At least two separately sufficient implication records with the same conclusion. |
| `views` | `{id,title,description,nodeIds,relationIds,complete}`. Every retained relation includes all endpoints. A `complete:true` view contains all canonical records. |
| `support` | Optional `{roots,selected}`. Explicit available/admitted roots and one chosen sufficient relation per derived conclusion. |

Allowed node statuses: `established`, `conditional`, `open`, `hypothesis`,
`model-case`, `obstruction`, `definition`, `external`, `withdrawn`.
`established` is displayed as **Established in source**, not independent review.
The helper never promotes these values. Review bindings remain in the original
project. A condition can be an available established input used as an assumption;
its label and scope should say so instead of suggesting an open conjecture.

Node and relation `href` fields point to their original canonical statement or
argument. Generated graph links first open `#node-<id>` or `#relation-<id>`;
those records carry full scope, sources and the canonical destination. Preserve
old public anchors or explicit redirects during site integration. Check actual
destinations: a nonempty URL is not evidence that a source was read or a page
exists. Relative source links are resolved by the delivered site's structure.

`support` does not claim every node is established. It checks only that the
selected sufficient arguments can be grounded in their declared roots; proof
inputs and open steps are ineligible as sufficient support. Additional textual
hypotheses still require mathematical discharge. The engine's reviewed support
closure, when available, remains authoritative.

## Check the delivered diagram

Compare every visible SVG edge and gate with the canonical data. Verify AND/OR,
line direction, blockers, scope labels, link destinations, and source version.
Check that duplicate SVG IDs, invisible layout constraints and collapsed views
do not introduce false connections or broken links. Inspect actual rendered
text for clipping and crossing labels; a successful build cannot show that.

Exercise the complete/principal selectors, one node link and one argument link,
keyboard expansion, node locator, zoom/readable reset, and a narrow viewport.
Ensure the narrow view retains every premise and full additional hypothesis.
Use local preview for a generic skill test; do not publish a test to a live site.

For substantial changes, use a fresh worker with raw source and a normal
diagram request. Inspect its output without giving it an expected verdict.
Keep the fixture and its exact source hash reproducible. Test a dropped joint
premise, a false OR group, an unsupported selected cycle and changed source or
artifact bytes. Report concrete limitations, including unavailable Graphviz or
unchecked remote sources. Keep source/math review separate from these checks.

Use the publisher's workflow for authorized site deployment, unified feedback
and historical revisions. General diagram feedback needs no invented theorem
ID; a comment on a specific argument carries its exact page fragment/version.
