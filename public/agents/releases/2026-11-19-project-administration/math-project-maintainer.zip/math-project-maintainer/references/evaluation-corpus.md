# Mathematical maintenance evaluation corpus

These fixtures are original examples for development and evaluation. They mix
valid arguments, invalid arguments, context changes, and dependency-planning
tasks. Compilation checks syntax and typesetting; it does not assess truth.

## Separation of inputs and answer keys

`manifest.json` lists neutral tasks in `inputs/`. Give a fresh reviewer only the
selected `inputs/Cnnn/` directory and the skill being evaluated. Do not give that
reviewer this repository's `answers/` directory or a previous review of the case.
The case directories contain the entire mathematical input required for the
task. Identifiers do not encode the expected verdict.

`answers/` is for the evaluator after a review has been produced. Its JSON files
record intended findings, concrete witnesses, acceptable repairs, and limits on
what a successful review may claim. The answer key is not a formal proof
certificate. A reviewer can discover additional valid issues or improvements.

## Suggested response contract

For each requested object, distinguish the truth of the assertion, adequacy of
the supplied proof, and eligibility of the current proof version for a chosen
dependency plan. Identify exact assumptions, ambient objects, normalization,
and quantifier scope. Explain each material finding with a checked argument or
counterexample. State whether the proposed repair preserves the task's original
mathematical target. Do not infer mathematical correctness from successful
parsing, compilation, graph checks, reviewer votes, or theorem names.

For a change task, compare the effective context as well as the visible theorem
text. Any examples of metadata in this directory describe input data; they do
not introduce a command-line interface.

## Evaluation use

Use each task's `task.json` as the user request. Supply the source snapshot(s)
listed there. Score against the separate answer key only after saving the
review output. A useful review can reject the supplied proof without claiming
the assertion is false, or accept one alternative proof without accepting a
cyclic alternative. Do not require one fixed wording or proof method.

All source prose and proofs were written for this corpus. No Stacks Project
prose or claims from a user's active research project were copied.

The research-organization cases C013 and C014 exercise coverage of complete,
partial and unrecovered proofs, conditional consequence nesting, and the passage
from a vague plan to exact mathematical problems. They are synthetic regressions
motivated by user feedback, not held-out evidence of mathematical discovery.
Use only the raw case directory for a fresh worker; inspect its separate answer
key after saving the response. The read-only `research_outline.py` helper and
`test_research_outline.py` check structural omissions and relation types, not the
semantic deductions tested by these cases.
