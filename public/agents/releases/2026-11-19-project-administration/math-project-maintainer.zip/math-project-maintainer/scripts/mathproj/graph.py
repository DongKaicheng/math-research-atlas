"""Deterministic dependency bookkeeping for mathematical projects.

The functions in this module do not infer whether a proof is mathematically
correct.  ``eligible`` and the admitted ``roots`` are supplied by the review
and release workflow.  A support plan records a well-founded choice among
those supplied proofs: all dependencies of one proof are required, while
different proofs of the same conclusion are alternatives.

No recursive graph traversal is used.  Reverse-impact witnesses share their
prefixes, so a long dependency chain does not produce a quadratic-size result.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
import heapq
import json
from typing import Any


def _is_id(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _as_rows(values: Any, name: str) -> list[Any]:
    if values is None:
        return []
    if isinstance(values, (str, bytes)) or not isinstance(values, Iterable):
        raise TypeError(f"{name} must be an iterable, not a single value")
    return list(values)


def _sort_diagnostics(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        rows,
        key=lambda row: (
            row["code"],
            row.get("proof", ""),
            row.get("node", ""),
            json.dumps(row, sort_keys=True, ensure_ascii=False),
        ),
    )


@dataclass(frozen=True)
class _Proof:
    id: str
    conclusion: str
    dependencies: tuple[str, ...]
    eligible: bool
    errors: tuple[str, ...]
    missing: tuple[str, ...]


def _cyclic_components(adjacency: Mapping[str, set[str]]) -> list[list[str]]:
    """Return cyclic SCCs using iterative Kosaraju traversal.

    The input is the *residual* graph after grounding.  A cycle reported here
    is a remaining cycle among supplied eligible proof alternatives; its
    existence is not a claim that every alternative has that same obstacle.
    """
    neighbors = {node: sorted(deps) for node, deps in adjacency.items()}
    reverse: dict[str, list[str]] = {node: [] for node in adjacency}
    for node in sorted(neighbors):
        for dependency in neighbors[node]:
            reverse[dependency].append(node)
    for consumers in reverse.values():
        consumers.sort()

    visited: set[str] = set()
    finishing: list[str] = []
    for start in sorted(neighbors):
        if start in visited:
            continue
        visited.add(start)
        stack: list[tuple[str, int]] = [(start, 0)]
        while stack:
            node, index = stack[-1]
            if index == len(neighbors[node]):
                finishing.append(node)
                stack.pop()
                continue
            dependency = neighbors[node][index]
            stack[-1] = (node, index + 1)
            if dependency not in visited:
                visited.add(dependency)
                stack.append((dependency, 0))

    visited.clear()
    cycles: list[list[str]] = []
    for start in reversed(finishing):
        if start in visited:
            continue
        component: list[str] = []
        stack = [start]
        visited.add(start)
        while stack:
            node = stack.pop()
            component.append(node)
            for consumer in reverse[node]:
                if consumer not in visited:
                    visited.add(consumer)
                    stack.append(consumer)
        component.sort()
        if len(component) > 1 or start in adjacency[start]:
            cycles.append(component)
    return sorted(cycles)


def solve_support(
    nodes: Iterable[str] | Mapping[str, Any],
    proofs: Iterable[Mapping[str, Any]],
    roots: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Choose a well-founded support plan from explicitly eligible proofs.

    Args:
        nodes: Known item IDs, or a mapping whose keys are those IDs.  Values
            in a mapping are deliberately ignored; a status in a node's
            metadata does not automatically admit it as a foundation.
        proofs: Records with ``id``, ``conclusion``, ``dependencies``, and
            literal boolean ``eligible``.  Duplicate proof IDs are ambiguous
            and all records sharing that ID are excluded.
        roots: Explicit foundation input IDs.  Unknown roots are diagnosed
            and cannot support known items.

    Returns:
        ``grounded`` and ``blocked`` are sorted ID lists. ``order`` places
        each selected proof's dependencies before its conclusion.
        ``selected_proofs`` maps each non-root grounded item to one proof ID.
        ``cycles`` contains cyclic SCCs only in the ungrounded residual
        eligible-proof graph. ``blocked_details`` explains other obstacles.

    Determinism:
        Prefer a support plan of minimum derivation height; break ties by
        conclusion ID and proof ID.  Input order does not affect a valid
        input's selected plan. Foundation inputs have height zero, as do
        explicitly eligible proofs with no dependencies.

    Complexity:
        O(V + E + P log P), apart from sorting IDs and diagnostic output.
        No conclusion is grounded merely because it is in a reference cycle.
    """
    diagnostics: list[dict[str, Any]] = []
    node_ids: set[str] = set()
    for index, node in enumerate(_as_rows(nodes, "nodes")):
        if not _is_id(node):
            diagnostics.append({
                "code": "invalid_node_id", "severity": "error",
                "message": "Node IDs must be nonempty strings.",
                "index": index,
            })
        else:
            node_ids.add(node)
    if not node_ids:
        diagnostics.append({
            "code": "empty_nodes", "severity": "info",
            "message": "No known mathematical items were supplied.",
        })

    root_ids: set[str] = set()
    for index, root in enumerate(_as_rows(roots, "roots")):
        if not _is_id(root):
            diagnostics.append({
                "code": "invalid_root_id", "severity": "error",
                "message": "Foundation IDs must be nonempty strings.",
                "index": index,
            })
        elif root not in node_ids:
            diagnostics.append({
                "code": "unknown_root", "severity": "error", "node": root,
                "message": "An unknown item cannot be admitted as a foundation.",
            })
        else:
            root_ids.add(root)

    rows = _as_rows(proofs, "proofs")
    counts = Counter(
        row["id"] for row in rows
        if isinstance(row, Mapping) and _is_id(row.get("id"))
    )
    duplicates = {proof_id for proof_id, count in counts.items() if count > 1}
    for proof_id in sorted(duplicates):
        diagnostics.append({
            "code": "duplicate_proof_id", "severity": "error", "proof": proof_id,
            "message": "All records with this ambiguous proof ID are excluded.",
            "count": counts[proof_id],
        })

    records: list[_Proof] = []
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            diagnostics.append({
                "code": "invalid_proof", "severity": "error", "index": index,
                "message": "A proof must be a mapping with explicit eligibility.",
            })
            continue
        proof_id = row.get("id")
        conclusion = row.get("conclusion")
        if not _is_id(proof_id) or not _is_id(conclusion):
            diagnostics.append({
                "code": "invalid_proof_identity", "severity": "error",
                "index": index,
                "message": "Proof ID and conclusion ID must be nonempty strings.",
            })
            continue

        errors: list[str] = []
        if proof_id in duplicates:
            errors.append("duplicate_proof_id")
        if conclusion not in node_ids:
            errors.append("unknown_conclusion")
            diagnostics.append({
                "code": "unknown_conclusion", "severity": "error",
                "proof": proof_id, "node": conclusion,
                "message": "The proof's conclusion is not a known item.",
            })

        raw_eligibility = row.get("eligible")
        eligible = raw_eligibility is True
        if type(raw_eligibility) is not bool:
            errors.append("invalid_eligibility")
            diagnostics.append({
                "code": "invalid_eligibility", "severity": "error",
                "proof": proof_id,
                "message": "Eligibility must be an explicit boolean, not a truthy value.",
            })

        raw_dependencies = row.get("dependencies")
        if not isinstance(raw_dependencies, (list, tuple, set, frozenset)):
            errors.append("invalid_dependencies")
            diagnostics.append({
                "code": "invalid_dependencies", "severity": "error",
                "proof": proof_id,
                "message": "Dependencies must be a collection of nonempty item IDs.",
            })
            dependencies: tuple[str, ...] = ()
        elif any(not _is_id(dependency) for dependency in raw_dependencies):
            errors.append("invalid_dependency_id")
            diagnostics.append({
                "code": "invalid_dependency_id", "severity": "error",
                "proof": proof_id,
                "message": "Every dependency must be a nonempty string ID.",
            })
            dependencies = tuple(sorted({
                dependency for dependency in raw_dependencies if _is_id(dependency)
            }))
        else:
            dependencies = tuple(sorted(set(raw_dependencies)))
        missing = tuple(dependency for dependency in dependencies if dependency not in node_ids)
        if missing:
            diagnostics.append({
                "code": "missing_dependency", "severity": "error" if eligible else "warning",
                "proof": proof_id, "dependencies": list(missing),
                "message": "The referenced items are absent from the supplied node universe.",
            })
        records.append(_Proof(
            proof_id, conclusion, dependencies, eligible, tuple(sorted(set(errors))), missing,
        ))

    valid = {
        record.id: record for record in records
        if record.eligible and not record.errors and not record.missing
    }
    watchers: dict[str, list[str]] = defaultdict(list)
    pending: dict[str, int] = {}
    ready: list[tuple[int, str, str]] = []
    grounded = set(root_ids)
    depths = {node: 0 for node in root_ids}
    order = sorted(root_ids)
    selected: dict[str, str] = {}
    for proof_id in sorted(valid):
        record = valid[proof_id]
        ungrounded = [dependency for dependency in record.dependencies if dependency not in root_ids]
        pending[proof_id] = len(ungrounded)
        for dependency in ungrounded:
            watchers[dependency].append(proof_id)
        if not ungrounded:
            height = 0 if not record.dependencies else 1
            heapq.heappush(ready, (height, record.conclusion, proof_id))

    while ready:
        height, conclusion, proof_id = heapq.heappop(ready)
        if conclusion in grounded:
            continue
        grounded.add(conclusion)
        depths[conclusion] = height
        selected[conclusion] = proof_id
        order.append(conclusion)
        for consumer_proof in watchers.get(conclusion, []):
            pending[consumer_proof] -= 1
            if pending[consumer_proof] == 0:
                consumer = valid[consumer_proof]
                consumer_height = 1 + max(depths[dependency] for dependency in consumer.dependencies)
                heapq.heappush(ready, (consumer_height, consumer.conclusion, consumer_proof))

    blocked = sorted(node_ids - grounded)
    blocked_set = set(blocked)
    adjacency: dict[str, set[str]] = {node: set() for node in blocked}
    by_conclusion: dict[str, list[_Proof]] = defaultdict(list)
    for record in records:
        by_conclusion[record.conclusion].append(record)
        if record.conclusion in blocked_set and record.eligible and not record.errors:
            adjacency[record.conclusion].update(
                dependency for dependency in record.dependencies if dependency in blocked_set
            )
    cycles = _cyclic_components(adjacency)
    for component in cycles:
        diagnostics.append({
            "code": "ungrounded_cycle", "severity": "warning", "nodes": component,
            "message": (
                "Eligible proof alternatives retain a cycle after grounding. "
                "Inspect blocked_details for other alternatives and missing inputs."
            ),
        })

    details: dict[str, dict[str, Any]] = {}
    for node in blocked:
        alternatives = sorted(by_conclusion.get(node, []), key=lambda r: (r.id, r.dependencies))
        if not alternatives:
            reason = "no_proofs"
        elif not any(record.eligible for record in alternatives):
            reason = "no_eligible_proofs"
        elif not any(record.eligible and not record.errors and not record.missing for record in alternatives):
            reason = "no_valid_eligible_proofs"
        else:
            reason = "unresolved_dependencies"
        details[node] = {
            "reason": reason,
            "proofs": [{
                "id": record.id,
                "eligible": record.eligible,
                "valid": not record.errors and not record.missing,
                "errors": list(record.errors),
                "missing_dependencies": list(record.missing),
                "ungrounded_dependencies": [
                    dependency for dependency in record.dependencies if dependency in blocked_set
                ],
            } for record in alternatives],
        }

    return {
        "grounded": sorted(grounded),
        "selected_proofs": dict(sorted(selected.items())),
        "order": order,
        "depths": dict(sorted(depths.items())),
        "blocked": blocked,
        "blocked_details": details,
        "cycles": cycles,
        "diagnostics": _sort_diagnostics(diagnostics),
    }


def reverse_impact(
    edges: Iterable[Mapping[str, Any]],
    seeds: Iterable[str],
) -> dict[str, Any]:
    """Find consumers reachable from changed dependency IDs.

    ``edges`` have ``consumer``, ``dependency`` and optional ``kind`` fields.
    The caller chooses relevant edge kinds: this function does not turn a
    textual mention into a mathematical dependency. Every supplied valid edge
    is traversed, and the selected edge's kind is retained in the witness.

    ``paths`` is a compact witness forest. Each affected ID maps to
    ``{seed, predecessor, distance, kind}``, where predecessor is one step
    closer to a seed and is null at a seed. Use :func:`impact_path` to obtain
    one full seed-to-consumer path. BFS chooses shortest witnesses; sorted
    seeds and neighbors make ties independent of input order.

    An isolated seed remains affected by its own change and gets an
    informational diagnostic. An empty seed set produces no affected items.
    """
    diagnostics: list[dict[str, Any]] = []
    consumers: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    known: set[str] = set()
    for index, edge in enumerate(_as_rows(edges, "edges")):
        if not isinstance(edge, Mapping) or not _is_id(edge.get("consumer")) or not _is_id(edge.get("dependency")):
            diagnostics.append({
                "code": "invalid_impact_edge", "severity": "error", "index": index,
                "message": "Impact edges require nonempty consumer and dependency IDs.",
            })
            continue
        consumer, dependency = edge["consumer"], edge["dependency"]
        kind = edge.get("kind", "dependency")
        if not _is_id(kind):
            diagnostics.append({
                "code": "invalid_impact_kind", "severity": "error", "index": index,
                "message": "An edge kind, when supplied, must be a nonempty string.",
            })
            continue
        consumers[dependency][consumer].add(kind)
        known.update((consumer, dependency))

    seed_ids: set[str] = set()
    for index, seed in enumerate(_as_rows(seeds, "seeds")):
        if not _is_id(seed):
            diagnostics.append({
                "code": "invalid_impact_seed", "severity": "error", "index": index,
                "message": "Impact seeds must be nonempty string IDs.",
            })
        else:
            seed_ids.add(seed)
    if not seed_ids:
        diagnostics.append({
            "code": "empty_seeds", "severity": "info",
            "message": "No changed item IDs were supplied.",
        })

    paths: dict[str, dict[str, Any]] = {}
    for seed in sorted(seed_ids):
        paths[seed] = {"seed": seed, "predecessor": None, "distance": 0, "kind": None}
        if seed not in known:
            diagnostics.append({
                "code": "seed_not_in_graph", "severity": "info", "node": seed,
                "message": "The changed item has no supplied dependency edges; it remains affected itself.",
            })
    queue = deque(sorted(seed_ids))
    while queue:
        predecessor = queue.popleft()
        for consumer in sorted(consumers.get(predecessor, {})):
            if consumer in paths:
                continue
            paths[consumer] = {
                "seed": paths[predecessor]["seed"],
                "predecessor": predecessor,
                "distance": paths[predecessor]["distance"] + 1,
                "kind": min(consumers[predecessor][consumer]),
            }
            queue.append(consumer)
    return {
        "affected": sorted(paths),
        "paths": dict(sorted(paths.items())),
        "diagnostics": _sort_diagnostics(diagnostics),
    }


def impact_path(result: Mapping[str, Any], target: str) -> list[str]:
    """Materialize one compact reverse-impact witness, checking its integrity.

    Raise KeyError for an unaffected target and ValueError for a corrupt
    witness forest. Reconstruction is iterative and O(path length).
    """
    paths = result.get("paths")
    if not isinstance(paths, Mapping):
        raise ValueError("Impact result has no witness mapping")
    if target not in paths:
        raise KeyError(target)
    reverse: list[str] = []
    seen: set[str] = set()
    cursor = target
    seed: str | None = None
    expected_distance: int | None = None
    while True:
        if cursor in seen:
            raise ValueError("Impact witness contains a cycle")
        seen.add(cursor)
        descriptor = paths.get(cursor)
        if not isinstance(descriptor, Mapping):
            raise ValueError(f"Missing impact witness for {cursor!r}")
        distance = descriptor.get("distance")
        if type(distance) is not int or distance < 0:
            raise ValueError("Impact witness distance must be a nonnegative integer")
        if expected_distance is not None and distance != expected_distance:
            raise ValueError("Impact witness distances are inconsistent")
        witness_seed = descriptor.get("seed")
        if not _is_id(witness_seed):
            raise ValueError("Impact witness has an invalid seed")
        if seed is None:
            seed = witness_seed
        elif witness_seed != seed:
            raise ValueError("Impact witness changes seed")
        reverse.append(cursor)
        predecessor = descriptor.get("predecessor")
        if predecessor is None:
            if distance != 0 or cursor != seed:
                raise ValueError("Impact witness does not terminate at its seed")
            return list(reversed(reverse))
        if not _is_id(predecessor) or distance == 0:
            raise ValueError("Impact witness predecessor is inconsistent")
        expected_distance = distance - 1
        cursor = predecessor
