"""Local static atlases and immutable, review-bound release archives.

Only an explicitly created release can be exported as reviewed. Its selected
support plan, attributable judgments, admissions, and source snapshot are
frozen together. No publication operation certifies prose mathematics with a
formal kernel or uploads files to a network service.
"""
from __future__ import annotations

from collections import defaultdict, deque
from copy import deepcopy
import ctypes
import errno
import hashlib
from html import escape
import json
import os
from pathlib import Path
import re
import secrets
from typing import Any, Iterator

from .store import ProjectError, ProjectStore, atomic_json, canonical, contained, digest, empty_state, read_json, utc_now, valid_name, validate_snapshot_sources


FORMAT_VERSION = 1
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_REF = re.compile(r"\\(?:ref|eqref|cref|Cref|autoref|nameref)\s*\{([^{}]*)\}")
_MEANING = ("Reviewed release means a frozen support plan based on named review judgments "
            "and explicitly admitted inputs. It is not formal kernel verification.")


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode("utf-8") + b"\n"


def _targets(state: dict, references: list[str] | None, *, mathematical_only: bool = False) -> list[str]:
    from .project import NAVIGATION, resolve_item
    if references is not None:
        if not isinstance(references, list) or not references or any(not isinstance(r, str) or not r.strip() for r in references):
            raise ProjectError("Targets must be a nonempty list of item IDs or labels when supplied")
        return sorted({resolve_item(state, reference) for reference in references})
    return sorted(iid for iid, item in state["items"].items() if item.get("lifecycle") == "active"
                  and (not mathematical_only or item.get("kind") not in NAVIGATION))


def _closure(report: dict, requested: list[str]) -> list[str]:
    grounded, included = set(report["grounded"]), set(requested)
    queue = deque(sorted(included))
    while queue:
        item_id = queue.popleft()
        if item_id not in grounded:
            raise ProjectError(f"No well-founded reviewed support for {item_id}")
        if item_id in report["admissions"]:
            continue
        proof_id = report["selected_proofs"].get(item_id)
        choice = report["eligibility"].get(proof_id, {})
        if not proof_id or not choice.get("eligible"):
            raise ProjectError(f"The selected proof for {item_id} is not eligible")
        for dependency in choice["dependencies"]:
            if dependency not in included:
                included.add(dependency)
                queue.append(dependency)
    return sorted(included)


def _audit_blockers(state: dict, included: list[str], selected: dict) -> None:
    """Statement-wide objections cannot disappear behind a proof alternative."""
    scope = set(included)
    blockers = []
    for issue_id, issue in sorted(state["issues"].items()):
        item_id = issue.get("item_id")
        if item_id not in scope or issue.get("status") != "open" or issue.get("severity") not in {"blocker", "error"}:
            continue
        if issue.get("scope") == "statement" or not issue.get("proof_id") or issue.get("proof_id") == selected.get(item_id):
            blockers.append(issue_id)
    if blockers:
        raise ProjectError("Release contains unresolved mathematical blockers: " + ", ".join(blockers))


def _freeze_state(state: dict, included: list[str]) -> dict:
    scope = set(included)
    frozen = empty_state()
    frozen["current_snapshot"] = state["current_snapshot"]
    frozen["items"] = {iid: deepcopy(state["items"][iid]) for iid in included}
    proof_ids = {pid for item in frozen["items"].values() for pid in item.get("proof_ids", [])}
    subjects = proof_ids | {iid + ":statement" for iid in included}
    frozen["proofs"] = {pid: deepcopy(state["proofs"][pid]) for pid in sorted(proof_ids) if pid in state["proofs"]}
    frozen["aliases"] = {key: iid for key, iid in sorted(state["aliases"].items()) if iid in scope}
    frozen["applications"] = {key: deepcopy(row) for key, row in sorted(state["applications"].items()) if row.get("proof_id") in subjects}
    frozen["reviews"] = {key: deepcopy(row) for key, row in sorted(state["reviews"].items()) if row.get("binding", {}).get("item_id") in scope}
    frozen["issues"] = {key: deepcopy(row) for key, row in sorted(state["issues"].items()) if row.get("item_id") in scope}
    frozen["foundations"] = {key: deepcopy(row) for key, row in sorted(state["foundations"].items()) if key in scope}
    frozen["contexts"] = deepcopy(state["contexts"])
    frozen["source_records"] = deepcopy(state["source_records"])
    frozen["citations"] = deepcopy(state.get("citations", {}))
    frozen["manifest_hash"] = state.get("manifest_hash")
    return frozen


def create_release(store: ProjectStore, name: str, targets: list[str] | None = None) -> dict:
    """Freeze a current reviewed support closure under a never-reused name.

    The content-addressed manifest embeds the exact source snapshot and the
    relevant review state, including issue_context in every review binding.
    Its hash is registered in the authoritative event log. A failed registry
    write can leave an unregistered immutable file, never a valid release.
    """
    if not isinstance(name, str):
        raise ProjectError("Release name must be a string")
    valid_name(name, "release name")
    def change(state):
        from .workflow import require_fresh, support_report
        if name in state["releases"] or any(row.get("name") == name for row in state["releases"].values()):
            raise ProjectError(f"Release name is already frozen: {name}")
        require_fresh(store, state)
        requested = _targets(state, targets, mathematical_only=True)
        if not requested:
            raise ProjectError("A reviewed release must contain at least one mathematical item")
        report = support_report(store, requested, check_freshness=False, state=state)
        if report["requested_blocked"]:
            raise ProjectError("Requested release items have no reviewed support: " + ", ".join(report["requested_blocked"]))
        included = _closure(report, requested)
        selected = {iid: report["selected_proofs"][iid] for iid in included if iid in report["selected_proofs"]}
        _audit_blockers(state, included, selected)
        frozen = _freeze_state(state, included)
        eligibility = {pid: deepcopy(row) for pid, row in sorted(report["eligibility"].items())
                       if pid in frozen["proofs"] or pid.removesuffix(":declaration") in frozen["items"]}
        support = {"order": [iid for iid in report["order"] if iid in frozen["items"]],
                   "grounded": included, "selected_proofs": selected, "eligibility": eligibility,
                   "admissions": {iid: deepcopy(row) for iid, row in sorted(report["admissions"].items()) if iid in frozen["items"]},
                   "requested": requested, "requested_supported": requested, "requested_blocked": [],
                   "meaning": _MEANING}
        sid = state["current_snapshot"]
        snapshot = store.snapshot(sid)
        payload = {"schema_version": FORMAT_VERSION, "kind": "reviewed_release", "name": name,
                   "created_at": utc_now(), "snapshot": sid, "snapshot_data": snapshot,
                   "policy": deepcopy(snapshot["manifest"].get("policy", {})),
                   "requested": requested, "included": included, "state": frozen,
                   "support": support, "meaning": _MEANING}
        release_id = digest(payload)
        manifest = {"id": release_id, **payload}
        directory = store.meta / "releases"
        if directory.is_symlink() or not directory.is_dir():
            raise ProjectError("Release metadata directory must be a real directory")
        path = directory / f"{release_id}.json"
        if path.is_symlink():
            raise ProjectError("Release manifest must not be a symlink")
        if path.exists():
            if read_json(path) != manifest:
                raise ProjectError("A conflicting release manifest already exists")
        else:
            atomic_json(path, manifest)
        entry = {"id": release_id, "name": name, "snapshot": sid, "created_at": payload["created_at"],
                 "manifest_sha256": release_id, "requested": requested, "included": included}
        state["releases"][name] = entry
        return {**deepcopy(entry), "release_id": release_id, "manifest": str(path),
                "selected_proofs": selected, "admitted_inputs": sorted(support["admissions"]), "meaning": _MEANING}
    return store.transact("create_release", change, details={"name": name, "targets": targets})


def _load_release(store: ProjectStore, state: dict, reference: str) -> dict:
    if not isinstance(reference, str) or not reference:
        raise ProjectError("A release ID or registered name is required")
    entry = state["releases"].get(reference)
    if entry is None:
        matches = [row for row in state["releases"].values() if row.get("id") == reference or row.get("name") == reference]
        if len(matches) != 1:
            raise ProjectError(f"Unknown or ambiguous release: {reference}")
        entry = matches[0]
    release_id = entry.get("id", "")
    if not isinstance(release_id, str) or not _HASH.fullmatch(release_id) or entry.get("manifest_sha256") != release_id:
        raise ProjectError("Invalid registered release identity")
    path = store.meta / "releases" / f"{release_id}.json"
    if path.is_symlink() or path.parent.is_symlink():
        raise ProjectError("Release manifest paths must not be symlinks")
    value = read_json(path)
    if not isinstance(value, dict):
        raise ProjectError("Invalid release manifest")
    payload = {key: val for key, val in value.items() if key != "id"}
    if value.get("id") != release_id or digest(payload) != release_id:
        raise ProjectError("Release manifest integrity failed")
    if value.get("schema_version") != FORMAT_VERSION or value.get("kind") != "reviewed_release":
        raise ProjectError("The registered artifact is not a supported reviewed release")
    if value.get("snapshot") != entry.get("snapshot") or digest(value.get("snapshot_data")) != value["snapshot"]:
        raise ProjectError("Frozen release source snapshot integrity failed")
    validate_snapshot_sources(value["snapshot_data"], allow_legacy=True)
    if value.get("requested") != entry.get("requested") or value.get("included") != entry.get("included"):
        raise ProjectError("Frozen release scope differs from its registered scope")
    return value


def _preview_data(store: ProjectStore, state: dict, snapshot: str | None, targets: list[str] | None) -> dict:
    from .workflow import support_report
    sid = snapshot or state.get("current_snapshot")
    if not sid:
        raise ProjectError("Import sources before exporting a preview")
    source = store.snapshot(sid)
    if sid == state.get("current_snapshot"):
        selected_state = state
        support = support_report(store, check_freshness=True, state=state)
        freshness = support["freshness"]
        status_note = "Current workflow records are shown separately from the imported mathematical text."
    else:
        selected_state = empty_state()
        selected_state.update(current_snapshot=sid, items=deepcopy(source.get("items", {})),
                              proofs=deepcopy(source.get("proofs", {})), contexts=deepcopy(source.get("contexts", {})),
                              source_records=deepcopy(source.get("source_records", {})),
                              citations=deepcopy(source.get("citations", {})))
        selected_state["aliases"] = {row["source_key"]: iid for iid, row in selected_state["items"].items() if row.get("source_key")}
        support = {"selected_proofs": {}, "eligibility": {}, "admissions": {}, "grounded": []}
        freshness = {"fresh": None, "reasons": [{"kind": "historical_snapshot"}], "snapshot": sid}
        status_note = "Historical source preview: current review judgments are not transferred to this snapshot."
    included = _targets(selected_state, targets)
    if not included:
        raise ProjectError("There are no active items to export")
    return {"schema_version": FORMAT_VERSION, "kind": "draft_preview", "snapshot": sid,
            "snapshot_data": source, "requested": included, "included": included,
            "state": _freeze_state(selected_state, included), "support": support,
            "source_freshness": freshness, "status_note": status_note,
            "meaning": "Draft preview. This export is not a reviewed release."}


def _safe_id(item_id: str) -> str:
    return item_id if _ID.fullmatch(item_id) else "item-" + digest(item_id)


def _anchor(prefix: str, value: str) -> str:
    return prefix + "-" + hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


def _item_link(item_id: str, pages: dict, prefix: str = "", label: str | None = None) -> str:
    text = escape(label if label is not None else item_id)
    if item_id not in pages:
        return f'<span class="outside">{text} <small>(outside this export)</small></span>'
    return f'<a href="{prefix}{pages[item_id]}#{_safe_id(item_id)}">{text}</a>'


def _tex(text: str, references: list[dict], pages: dict, prefix: str) -> str:
    targets = defaultdict(set)
    for reference in references:
        if isinstance(reference.get("label"), str) and reference.get("target_id"):
            targets[reference["label"]].add(reference["target_id"])
    rendered, cursor = [], 0
    for match in _REF.finditer(text):
        rendered.append(escape(text[cursor:match.start()]))
        candidates = targets.get(match.group(1), set())
        target = next(iter(candidates)) if len(candidates) == 1 else None
        command = escape(match.group(0))
        if target in pages:
            command = f'<a class="tex-ref" href="{prefix}{pages[target]}#{_safe_id(target)}">{command}</a>'
        rendered.append(command)
        cursor = match.end()
    rendered.append(escape(text[cursor:]))
    return '<pre class="tex"><code>' + "".join(rendered) + '</code></pre>'


_CSS = """*{box-sizing:border-box}html{color:#182b35;background:#f3f5f4;font:16px/1.6 Georgia,serif}body{margin:0}a{color:#075b75;text-underline-offset:.17em}header,main,footer{max-width:1160px;margin:auto;padding:1.3rem 2rem}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #cad5d8;font-family:system-ui,sans-serif}header a{text-decoration:none;font-weight:650}.badge{font:600 .78rem/1.3 system-ui,sans-serif;padding:.35rem .65rem;border:1px solid #9aadb2;border-radius:4px}.preview{background:#fff0cb}.reviewed{background:#dfeee5}.notice,.metadata,details{padding:1rem 1.3rem;background:#fff;border:1px solid #d7e0e1;border-radius:6px;margin:1.3rem 0}.notice{border-left:4px solid #bc8d3a}.reviewed-note{border-left-color:#3a7c63}h1{font-size:2.15rem;font-weight:500;line-height:1.25;margin:.5rem 0 1rem}h2{font-size:1.4rem;margin-top:1.8rem}h3{font-size:1.1rem}.eyebrow,small,dt,.status{font-family:system-ui,sans-serif}.eyebrow{color:#42616d;letter-spacing:.05em;font-size:.85rem}.tex{white-space:pre-wrap;overflow-wrap:anywhere;background:#fff;padding:1.2rem;border:1px solid #d7e0e1;border-radius:5px;font: .95rem/1.75 ui-monospace,SFMono-Regular,Consolas,monospace}.metadata{font-size:.9rem}dl{display:grid;grid-template-columns:minmax(8rem,1fr) 4fr;gap:.4rem 1rem}dt{font-weight:600}dd{margin:0;overflow-wrap:anywhere}code{overflow-wrap:anywhere;font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.columns{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1rem 2rem}.clean{list-style:none;padding:0}.clean li{padding:.35rem 0;border-bottom:1px solid #e1e7e7}.outside{color:#64757a}.source-line{display:block}.line-number{display:inline-block;width:4em;user-select:none;color:#718087}.proof-choice{font-family:system-ui,sans-serif;font-size:.85rem;font-weight:650;color:#3d6653}.muted{color:#60747a}footer{border-top:1px solid #cad5d8;color:#60747a;font-size:.85rem}summary{cursor:pointer;font-weight:600}@media(max-width:650px){header,main,footer{padding:1rem}header{gap:1rem;align-items:flex-start}h1{font-size:1.7rem}dl{display:block}dd{margin:.25rem 0 1rem}.tex{padding:.8rem}}"""


def _page(title: str, body: str, data: dict, prefix: str = "") -> bytes:
    reviewed = data["kind"] == "reviewed_release"
    label = "Reviewed release · " + data["name"] if reviewed else "Draft preview"
    project_name = data["snapshot_data"]["manifest"]["name"]
    document = ('<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'self\'; '
        'script-src \'none\'; base-uri \'none\'; form-action \'none\'; object-src \'none\'">'
        f'<title>{escape(title)} · {escape(project_name)}</title><link rel="stylesheet" href="{prefix}assets/style.css">'
        f'</head><body><header><a href="{prefix}index.html">{escape(project_name)}</a>'
        f'<span class="badge {"reviewed" if reviewed else "preview"}">{escape(label)}</span></header><main>{body}</main>'
        f'<footer>Snapshot <code>{escape(data["snapshot"])}</code>. '
        'Mathematical text and review provenance are presented separately. No TeX or scripts are executed.</footer></body></html>\n')
    return document.encode("utf-8")


def _references(refs: list[dict], pages: dict, prefix: str) -> str:
    rows = []
    seen = set()
    for ref in refs:
        target, label = ref.get("target_id"), ref.get("label", "unresolved reference")
        if (target, label) in seen:
            continue
        seen.add((target, label))
        rows.append("<li>" + (_item_link(target, pages, prefix, label) if target else escape(label) + " <small>(unresolved)</small>") + "</li>")
    return '<ul class="clean">' + "".join(rows) + "</ul>" if rows else ""


def _render_files(data: dict) -> Iterator[tuple[str, bytes]]:
    from .project import dependency_edges
    state, support, included = data["state"], data["support"], data["included"]
    pages = {iid: "items/" + _safe_id(iid) + ".html" for iid in included}
    if len(set(pages.values())) != len(pages):
        raise ProjectError("Permanent ID page names collide")
    source_files = {entry["path"]: entry for entry in data["snapshot_data"].get("files", [])}
    source_pages = {path: "sources/" + _anchor("source", path) + ".html" for path in source_files}
    backlinks = defaultdict(set)
    for edge in dependency_edges(state, include_candidates=True):
        backlinks[edge["dependency"]].add((edge["consumer"], edge["kind"]))
    reviewed = data["kind"] == "reviewed_release"
    archive = "release.json" if reviewed else "preview.json"
    notice = f'<div class="notice {"reviewed-note" if reviewed else ""}"><p>{escape(data["meaning"])}</p>'
    if not reviewed:
        notice += f'<p>{escape(data["status_note"])}</p>'
        if data["source_freshness"]["fresh"] is False:
            notice += '<p><strong>Working sources or metadata have changed since import.</strong> This preview retains the imported snapshot.</p>'
    notice += f'<p><a href="{archive}">Download the exact {"frozen release" if reviewed else "preview"} archive</a> · <a href="reviews.html">Review provenance</a></p></div>'
    groups = defaultdict(list)
    for iid in included:
        item = state["items"][iid]
        section = " / ".join(item.get("section", [])) or "Unsectioned material"
        groups[section].append(iid)
    body = '<p class="eyebrow">MATHEMATICAL ATLAS</p><h1>' + escape(data["snapshot_data"]["manifest"]["name"]) + "</h1>" + notice
    selected_count = len(set(support.get("selected_proofs", {})) & set(included))
    admission_count = len(set(support.get("admissions", {})) & set(included))
    body += f'<p>{len(included)} included items · {admission_count} explicitly admitted inputs · {selected_count} selected proof records.</p>'
    body += '<div class="columns"><section><h2>Chapters and sections</h2>'
    for section, ids in sorted(groups.items()):
        body += '<h3>' + escape(section) + '</h3><ul class="clean">'
        for iid in ids:
            item = state["items"][iid]
            label = iid + " · " + item.get("kind", "item") + (" · " + item["title"] if item.get("title") else "")
            body += "<li>" + _item_link(iid, pages, label=label) + "</li>"
        body += "</ul>"
    body += '</section><section><h2>Source navigation</h2><p class="muted">Source pages preserve the imported files; material outside the published item scope may appear there.</p><ul class="clean">'
    for path in sorted(source_pages):
        body += f'<li><a href="{source_pages[path]}">{escape(path)}</a></li>'
    body += '</ul><h2>Requested items</h2><ul class="clean">'
    body += "".join("<li>" + _item_link(iid, pages) + "</li>" for iid in data["requested"])
    body += "</ul></section></div>"
    yield "assets/style.css", _CSS.encode("utf-8")
    yield "index.html", _page("Index", body, data)

    for iid in included:
        item = state["items"][iid]
        selected = support.get("selected_proofs", {}).get(iid)
        admission = support.get("admissions", {}).get(iid)
        title = item.get("title") or item.get("kind", "Item").capitalize()
        body = f'<article id="{_safe_id(iid)}"><p class="eyebrow">{escape(iid)} · {escape(item.get("kind", "item"))}</p><h1>{escape(title)}</h1>'
        body += _tex(item.get("statement", ""), item.get("statement_references", []), pages, "../")
        body += _references(item.get("statement_references", []), pages, "../")
        if item.get("contexts"):
            body += '<h2>Context and assumptions</h2>'
            for context in item["contexts"]:
                body += '<h3>' + escape(context.get("key", "Context")) + '</h3>' + _tex(context.get("text", ""), [], pages, "../")
        proof_ids = item.get("proof_ids", [])
        for number, pid in enumerate(proof_ids, 1):
            proof = state["proofs"].get(pid)
            if not proof:
                continue
            chosen = selected == pid
            body += f'<section id="{_anchor("proof", pid)}"><h2>Proof {number}</h2>'
            if chosen:
                label = "Selected proof in the frozen support plan" if reviewed else "Selected by the current support records"
            else:
                label = "Alternative proof from the source; not part of this release's support plan" if reviewed else "Alternative proof; not selected by the current support records"
            body += '<p class="proof-choice">' + escape(label) + "</p>"
            body += _tex(proof.get("text", ""), proof.get("references", []), pages, "../")
            body += _references(proof.get("references", []), pages, "../")
            eligibility = support.get("eligibility", {}).get(pid)
            if eligibility:
                status = "Eligible according to the recorded review inputs" if eligibility.get("eligible") else "Not eligible according to the recorded review inputs"
                body += '<details><summary>Proof review provenance</summary><p>' + escape(status) + '</p>'
                body += '<p>Proof revision <code>' + escape(proof.get("revision", "unrecorded")) + '</code></p>'
                for rid in eligibility.get("review_ids", []):
                    body += f'<p><a href="../reviews.html#{_anchor("review", rid)}">{escape(rid)}</a></p>'
                if eligibility.get("reasons"):
                    body += '<pre class="tex">' + escape(json.dumps(eligibility["reasons"], ensure_ascii=False, sort_keys=True, indent=2)) + '</pre>'
                body += '</details>'
            body += '</section>'
        body += '</article><aside class="metadata"><h2>Identity and review status</h2><dl>'
        metadata = [("Permanent ID", iid), ("Item revision", item.get("revision", "unrecorded")),
                    ("Declaration revision", item.get("declaration_revision", "unrecorded")), ("Snapshot", data["snapshot"])]
        for label, value in metadata:
            body += '<dt>' + escape(label) + '</dt><dd><code>' + escape(value) + '</code></dd>'
        body += '</dl>'
        if admission:
            body += '<p><strong>Explicitly admitted input:</strong> ' + escape(admission.get("kind", "input")) + '</p><p>' + escape(admission.get("reason", "")) + '</p>'
        elif selected:
            body += '<p>Selected support record: <code>' + escape(selected) + '</code>.</p>'
        else:
            body += '<p>No selected support record is included in this preview.</p>'
        if selected and selected not in proof_ids:
            row = support.get("eligibility", {}).get(selected, {})
            body += '<p>Declaration review: ' + "; ".join(f'<a href="../reviews.html#{_anchor("review", rid)}">{escape(rid)}</a>' for rid in row.get("review_ids", [])) + '</p>'
        path = item.get("source", {}).get("path")
        if path in source_pages:
            line = item["source"].get("start_line", 1)
            body += f'<p><a href="../{source_pages[path]}#L{int(line)}">Source: {escape(path)}, line {int(line)}</a></p>'
        body += '</aside><section><h2>Backlinks</h2><ul class="clean">'
        for consumer, kind in sorted(backlinks.get(iid, set())):
            body += '<li>' + _item_link(consumer, pages, "../") + ' <small>' + escape(kind.replace("_", " ")) + '</small></li>'
        body += '</ul></section>'
        yield pages[iid], _page(iid + " · " + title, body, data, "../")

    for path, source in sorted(source_files.items()):
        lines = source.get("text", "").splitlines()
        body = '<p class="eyebrow">IMPORTED SOURCE</p><h1>' + escape(path) + '</h1>'
        body += '<p>Exact source archive. Review status applies to the selected item support plan, not every passage in this file.</p>'
        body += '<p>SHA-256 <code>' + escape(source.get("sha256", "unrecorded")) + '</code></p><pre class="tex"><code>'
        for number, line in enumerate(lines, 1):
            body += f'<span class="source-line" id="L{number}"><a class="line-number" href="#L{number}">{number}</a>{escape(line)}</span>'
        body += '</code></pre>'
        yield source_pages[path], _page(path, body, data, "../")

    body = '<h1>Review provenance</h1><p>These are attributable judgments on exact recorded inputs. They do not constitute formal kernel verification.</p>'
    for rid, row in sorted(state["reviews"].items()):
        reviewer = row.get("reviewer", {})
        body += f'<section class="metadata" id="{_anchor("review", rid)}"><h2>{escape(rid)}</h2>'
        body += '<p>Reviewer: ' + escape(reviewer.get("id", "unrecorded")) + ' · ' + escape(reviewer.get("kind", "unrecorded")) + '</p>'
        body += '<p>Recorded verdict: <strong>' + escape(row.get("verdict", "unrecorded")) + '</strong></p><p>' + escape(row.get("summary", "")) + '</p>'
        body += '<details><summary>Exact binding, checks, and findings</summary><pre class="tex">' + escape(json.dumps(row, ensure_ascii=False, sort_keys=True, indent=2)) + '</pre></details></section>'
    if not state["reviews"]:
        body += '<p>No review records are included. Admitted inputs, if any, are identified on their item pages.</p>'
    if state["issues"]:
        body += '<h2>Frozen issue context</h2><pre class="tex">' + escape(json.dumps(state["issues"], ensure_ascii=False, sort_keys=True, indent=2)) + '</pre>'
    yield "reviews.html", _page("Review provenance", body, data)
    yield archive, _json_bytes(data)
    yield "atlas.json", _json_bytes({"schema_version": FORMAT_VERSION, "snapshot": data["snapshot"],
                                      "mode": "reviewed" if reviewed else "preview", "items": pages,
                                      "sources": source_pages, "requested": data["requested"], "included": included})


def _output_path(store: ProjectStore, output: str | Path, source_snapshot: dict) -> tuple[Path, tuple[str, ...]]:
    if not isinstance(output, (str, Path)):
        raise ProjectError("Export destination must be a project-relative path")
    raw = Path(output)
    absolute = raw if raw.is_absolute() else store.root / raw
    if ".." in raw.parts:
        raise ProjectError("Export destination must not contain '..'")
    candidate = contained(store.root, str(absolute))
    relative = candidate.relative_to(store.root)
    if not relative.parts:
        raise ProjectError("The project root cannot be an export destination")
    # Use both the frozen and current source layouts. A historical release
    # must not be exported into a newly configured live source directory.
    manifests = [source_snapshot["manifest"], store.manifest()]
    protected = [store.meta, store.manifest_path]
    for manifest in manifests:
        protected.extend(contained(store.root, path) for path in manifest["source_roots"])
        protected.extend(contained(store.root, path) for path in manifest["entrypoints"])
    protected.extend(contained(store.root, source["path"]) for source in source_snapshot.get("files", []))
    for path in protected:
        if candidate == path or candidate in path.parents or path in candidate.parents:
            raise ProjectError(f"Export destination overlaps protected project sources or metadata: {candidate}")
    cursor = store.root
    # Inspect the lexical path too: resolving an internal symlink is safe
    # containment but still not an acceptable export destination.
    lexical = absolute.relative_to(store.root)
    for part in lexical.parts:
        cursor /= part
        if cursor.is_symlink():
            raise ProjectError("Export paths must not contain symlinks")
    if candidate.exists():
        raise ProjectError("Export destination already exists; choose a new directory")
    return candidate, relative.parts


def _rename_new(source: str, destination: str, parent_fd: int) -> None:
    """Atomic Linux promotion with RENAME_NOREPLACE, never an overwrite."""
    libc = ctypes.CDLL(None, use_errno=True)
    renameat2 = getattr(libc, "renameat2", None)
    if renameat2 is None:
        raise ProjectError("Atomic non-overwriting export currently requires renameat2 on Linux")
    renameat2.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    renameat2.restype = ctypes.c_int
    if renameat2(parent_fd, os.fsencode(source), parent_fd, os.fsencode(destination), 1) != 0:
        error = ctypes.get_errno()
        if error == errno.EEXIST:
            raise ProjectError("Export destination appeared while generating files; it was not overwritten")
        raise ProjectError("Cannot atomically install export: " + os.strerror(error))


def _write_atlas(store: ProjectStore, output: Path, parts: tuple[str, ...], data: dict) -> dict:
    parent_fds, stage_fd, stage_name = [], None, None
    written, directories = [], []
    installed = False
    try:
        parent = os.open(store.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        parent_fds.append(parent)
        for component in parts[:-1]:
            try:
                os.mkdir(component, mode=0o755, dir_fd=parent)
            except FileExistsError:
                pass
            parent = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            parent_fds.append(parent)
        # Mode 0700 protects incomplete outputs; only this owned staging
        # directory is cleaned after failure, using tracked generated paths.
        stage_name = ".mpm-export-" + secrets.token_hex(12)
        os.mkdir(stage_name, mode=0o700, dir_fd=parent)
        stage_fd = os.open(stage_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        hashes = {}
        files = _render_files(data)
        for name, content in files:
            if name.startswith("/") or ".." in Path(name).parts or name in hashes:
                raise ProjectError("Unsafe or duplicate generated export path")
            segments = name.split("/")
            if len(segments) > 2:
                raise ProjectError("Unexpected export path depth")
            if len(segments) == 2 and segments[0] not in directories:
                os.mkdir(segments[0], mode=0o755, dir_fd=stage_fd)
                directories.append(segments[0])
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=stage_fd)
            written.append(name)
            with os.fdopen(fd, "wb") as output_file:
                output_file.write(content)
                output_file.flush()
                os.fsync(output_file.fileno())
            hashes[name] = hashlib.sha256(content).hexdigest()
        description = {"schema_version": FORMAT_VERSION, "mode": "reviewed" if data["kind"] == "reviewed_release" else "preview",
                       "snapshot": data["snapshot"], "release_id": data.get("id"),
                       "requested": data["requested"], "included": data["included"],
                       "files": dict(sorted(hashes.items()))}
        fd = os.open("export.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=stage_fd)
        written.append("export.json")
        with os.fdopen(fd, "wb") as output_file:
            output_file.write(_json_bytes(description))
            output_file.flush()
            os.fsync(output_file.fileno())
        for directory in directories:
            descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=stage_fd)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        os.fchmod(stage_fd, 0o755)
        os.fsync(stage_fd)
        _rename_new(stage_name, parts[-1], parent)
        installed = True
        os.fsync(parent)
        return {"output": str(output), "index": str(output / "index.html"),
                "mode": description["mode"], "snapshot": data["snapshot"], "release_id": data.get("id"),
                "items": len(data["included"]), "files": len(written),
                "requested": data["requested"], "included": data["included"],
                "meaning": data["meaning"]}
    except OSError as exc:
        raise ProjectError(f"Cannot write safe export destination: {exc}") from exc
    finally:
        if stage_fd is not None:
            if not installed:
                for name in reversed(written):
                    try:
                        os.unlink(name, dir_fd=stage_fd)
                    except OSError:
                        pass
                for directory in reversed(directories):
                    try:
                        os.rmdir(directory, dir_fd=stage_fd)
                    except OSError:
                        pass
            os.close(stage_fd)
        if stage_name and not installed and parent_fds:
            try:
                os.rmdir(stage_name, dir_fd=parent_fds[-1])
            except OSError:
                pass
        for descriptor in reversed(parent_fds):
            os.close(descriptor)


def export_project(store: ProjectStore, output: str | Path, *, snapshot: str | None = None,
                   targets: list[str] | None = None, mode: str = "preview",
                   release_id: str | None = None) -> dict:
    """Export a self-contained atlas to a new project-contained directory.

    Reviewed exports require mode='reviewed' and a registered release ID or
    name. Their scope and source snapshot are immutable; current review state
    is not consulted. Preview exports may select the current or an older
    source snapshot and remain conspicuously labeled as previews.
    """
    if mode not in {"preview", "reviewed"}:
        raise ProjectError("Export mode must be preview or reviewed")
    if mode == "reviewed":
        if not release_id:
            raise ProjectError("A reviewed export requires an explicitly created release")
        if snapshot is not None or targets is not None:
            raise ProjectError("A frozen release's snapshot and included scope cannot be overridden")
    elif release_id is not None:
        raise ProjectError("Use mode='reviewed' to export a registered release")
    with store.locked():
        state = store.replay()[0]
        data = _load_release(store, state, release_id) if mode == "reviewed" else _preview_data(store, state, snapshot, targets)
    destination, parts = _output_path(store, output, data["snapshot_data"])
    return _write_atlas(store, destination, parts, data)
