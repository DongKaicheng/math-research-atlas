"""Append-only project records and disposable materialized state.

The event log and immutable snapshots are authoritative. state.json and the
search index may be rebuilt. All writers acquire the same advisory lock.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
from typing import Any, Callable


class ProjectError(Exception):
    """A user-actionable project validation or consistency failure."""


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise ProjectError(f"Cannot read valid JSON from {path}: {exc}") from exc


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ProjectError(f"Refusing to replace a symlink: {path}")
    fd, name = tempfile.mkstemp(prefix=".write-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as out:
            out.write(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                 indent=2, allow_nan=False).encode("utf-8") + b"\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def contained(root: Path, value: str, *, must_exist: bool = False) -> Path:
    p = Path(value)
    resolved = (root / p).resolve() if not p.is_absolute() else p.resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise ProjectError(f"Path leaves project root: {value}") from exc
    if must_exist and not resolved.exists():
        raise ProjectError(f"Path does not exist: {value}")
    return resolved


def valid_name(value: str, what: str = "name") -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", value):
        raise ProjectError(f"Invalid {what}: use 1-80 letters, digits, '.', '_' or '-'")
    return value


def snapshot_source_bytes(source: dict, *, legacy_omitted_bom: bool = False) -> bytes:
    """Recover only bytes whose digest exactly matches the archived evidence.

    Early format-1 readers used ``utf-8-sig`` while hashing the original raw
    source. Their single omitted leading BOM can be reconstructed without
    changing the immutable archive. No newline or other text repair is allowed.
    Callers must opt into this compatibility rule for a known legacy snapshot.
    """
    path, text, expected = source.get("path"), source.get("text"), source.get("sha256")
    if not isinstance(text, str) or not isinstance(expected, str):
        raise ProjectError(f"Snapshot source text or hash is missing: {path}")
    try:
        raw = text.encode("utf-8")
    except UnicodeError as exc:
        raise ProjectError(f"Snapshot source text is not valid UTF-8: {path}") from exc
    if re.fullmatch(r"[0-9a-f]{64}", expected):
        if hashlib.sha256(raw).hexdigest() == expected:
            return raw
        if legacy_omitted_bom and hashlib.sha256(b"\xef\xbb\xbf" + raw).hexdigest() == expected:
            return b"\xef\xbb\xbf" + raw
    raise ProjectError(f"Snapshot source byte integrity failed: {path}")


def validate_snapshot_sources(value: dict, *, allow_legacy: bool = False) -> None:
    """Require archived UTF-8 source text to reconstruct its claimed bytes.

    An outer snapshot hash protects a record from later modification, but it
    does not by itself prove that the record's text and source hashes agree.
    Preserve BOMs and CRLF exactly; normalized text belongs in item revisions.
    Reads may recognize the early format-1 encoding convention, before source
    layout and reader fingerprints existed. New snapshot writes stay strict.
    """
    files = value.get("files", [])
    if not isinstance(files, list):
        raise ProjectError("Snapshot source files must be a list")
    legacy_bom = (allow_legacy and value.get("schema_version") == 1
                  and not any(key in value for key in ("source_encoding", "source_layout", "reader_fingerprint")))
    paths = set()
    for source in files:
        if not isinstance(source, dict):
            raise ProjectError("Malformed snapshot source record")
        path = source.get("path")
        if not isinstance(path, str) or not path or path in paths:
            raise ProjectError("Snapshot source paths must be nonempty and unique")
        paths.add(path)
        snapshot_source_bytes(source, legacy_omitted_bom=legacy_bom)


COLLECTIONS = ("items", "aliases", "contexts", "proofs", "applications",
               "reviews", "issues", "tasks", "foundations", "releases",
               "source_records", "proposals", "citations")


def empty_state() -> dict:
    return {"schema_version": 1, "next_id": 1, "current_snapshot": None,
            "snapshot_history": [], "manifest_hash": None, "source_basis": None,
            **{name: {} for name in COLLECTIONS}}


def state_diff(old: dict, new: dict) -> list[dict]:
    changes = []
    for field in sorted(old.keys() | new.keys()):
        if field in COLLECTIONS:
            before, after = old.get(field, {}), new.get(field, {})
            for key in sorted(before.keys() | after.keys()):
                if key not in after:
                    changes.append({"path": [field, key], "delete": True})
                elif key not in before or before[key] != after[key]:
                    changes.append({"path": [field, key], "value": after[key]})
        elif field not in new:
            changes.append({"path": [field], "delete": True})
        elif field not in old or old[field] != new[field]:
            changes.append({"path": [field], "value": new[field]})
    return changes


def apply_patch(state: dict, patch: list[dict]) -> None:
    if not isinstance(patch, list):
        raise ProjectError("Event patch must be a list")
    for change in patch:
        path = change.get("path", [])
        if not isinstance(path, list) or not 1 <= len(path) <= 2:
            raise ProjectError("Malformed event patch path")
        if not all(isinstance(p, str) for p in path):
            raise ProjectError("Event patch path components must be strings")
        if path[0] not in empty_state():
            raise ProjectError(f"Unknown state field: {path[0]}")
        if len(path) == 2 and path[0] not in COLLECTIONS:
            raise ProjectError("Only collection entries can have nested patch paths")
        target = state if len(path) == 1 else state.setdefault(path[0], {})
        key = path[-1]
        if change.get("delete") is True:
            target.pop(key, None)
        elif "value" in change:
            target[key] = deepcopy(change["value"])
        else:
            raise ProjectError("Event patch has neither value nor deletion")


class ProjectStore:
    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()
        self.meta = self.root / "mpm"
        self.manifest_path = self.root / "mathproject.json"
        self._initializing = False
        if not self.manifest_path.is_file():
            raise ProjectError(f"No mathproject.json in {self.root}; initialize the project first")
        if self.meta.is_symlink():
            raise ProjectError("Project metadata directory must not be a symlink")
        if not self.meta.is_dir():
            raise ProjectError("Project metadata is missing; restore mpm/events.jsonl")
        for name in ("snapshots", "releases"):
            if (self.meta / name).is_symlink():
                raise ProjectError(f"Metadata {name} directory must not be a symlink")
        self.events = self.meta / "events.jsonl"
        self.state_path = self.meta / "state.json"
        self.lock_path = self.meta / "write.lock"

    @classmethod
    def create(cls, root: str | Path, name: str, namespace: str = "MATH",
               source_roots: list[str] | None = None,
               entrypoints: list[str] | None = None) -> "ProjectStore":
        root = Path(root).expanduser().resolve()
        if not re.fullmatch(r"[A-Z][A-Z0-9]{1,11}", namespace):
            raise ProjectError("Namespace must contain 2-12 uppercase letters/digits, starting with a letter")
        if not name.strip():
            raise ProjectError("Project name is required")
        if (root / "mathproject.json").exists() or (root / "mpm").exists():
            raise ProjectError("Project or metadata already exists; initialization never overwrites it")
        roots = source_roots or ["content"]
        for p in roots + (entrypoints or []):
            contained(root, p)
        root.mkdir(parents=True, exist_ok=True)
        (root / "mpm" / "snapshots").mkdir(parents=True)
        (root / "mpm" / "releases").mkdir()
        manifest = {"schema_version": 1, "name": name, "namespace": namespace,
                    "language": "en", "source_roots": roots,
                    "entrypoints": entrypoints or [],
                    "policy": {"require_independent_review": True,
                               "require_application_records": True,
                               "allow_external_foundations": True}}
        atomic_json(root / "mathproject.json", manifest)
        store = cls(root)
        store._initializing = True
        try:
            store.transact("initialize", lambda state: state.update(manifest_hash=digest(manifest)),
                           details={"name": name, "namespace": namespace})
        finally:
            store._initializing = False
        for p in roots:
            contained(root, p).mkdir(parents=True, exist_ok=True)
        return store

    def manifest(self) -> dict:
        value = read_json(self.manifest_path)
        if not isinstance(value, dict) or value.get("schema_version") != 1:
            raise ProjectError("Unsupported project manifest schema")
        if not re.fullmatch(r"[A-Z][A-Z0-9]{1,11}", value.get("namespace", "")):
            raise ProjectError("Invalid namespace in project manifest")
        for field in ("source_roots", "entrypoints"):
            if not isinstance(value.get(field), list) or not all(isinstance(p, str) for p in value[field]):
                raise ProjectError(f"Manifest {field} must be a list of paths")
            for p in value[field]:
                contained(self.root, p)
        if not isinstance(value.get("policy", {}), dict):
            raise ProjectError("Manifest policy must be an object")
        for field in ("require_independent_review", "require_application_records", "allow_external_foundations"):
            if not isinstance(value.get("policy", {}).get(field, True), bool):
                raise ProjectError(f"Manifest policy {field} must be a boolean")
        if value.get("policy", {}).get("require_application_records", True) is not True:
            raise ProjectError("This schema requires explicit application records for accepting a referenced argument")
        return value

    @contextmanager
    def locked(self):
        if self.lock_path.is_symlink():
            raise ProjectError("Metadata lock must not be a symlink")
        try:
            import fcntl
        except ImportError as exc:
            raise ProjectError("Concurrent writes currently require a POSIX file-locking environment") from exc
        with self.lock_path.open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def replay(self, *, repair_tail: bool = False) -> tuple[dict, list[dict]]:
        state = empty_state()
        if not self.events.exists():
            if self._initializing:
                return state, []
            raise ProjectError("Authoritative event log is missing; restore it before continuing")
        if self.events.is_symlink():
            raise ProjectError("Event log must not be a symlink")
        raw = self.events.read_bytes()
        if not raw and not self._initializing:
            raise ProjectError("Authoritative event log is empty; restore it before continuing")
        lines = raw.splitlines(keepends=True)
        events = []
        offset = 0
        previous = "0" * 64
        for index, line in enumerate(lines):
            if not line.endswith(b"\n"):
                if index == len(lines)-1 and repair_tail:
                    recovery = self.meta / ("incomplete-tail-" + hashlib.sha256(line).hexdigest()[:16] + ".bin")
                    if recovery.is_symlink():
                        raise ProjectError("Interrupted-tail backup must not be a symlink; event log was preserved")
                    if recovery.exists():
                        if not recovery.is_file() or recovery.read_bytes() != line:
                            raise ProjectError("Interrupted-tail backup differs from the current fragment; event log was preserved")
                    else:
                        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
                        fd = os.open(recovery, flags, 0o600)
                        with os.fdopen(fd, "wb") as backup:
                            backup.write(line)
                            backup.flush()
                            os.fsync(backup.fileno())
                        directory = os.open(self.meta, os.O_RDONLY)
                        try:
                            os.fsync(directory)
                        finally:
                            os.close(directory)
                    with self.events.open("r+b") as out:
                        out.truncate(offset)
                        out.flush()
                        os.fsync(out.fileno())
                    break
                raise ProjectError("Incomplete final event; run recover to preserve and remove the interrupted tail")
            try:
                event = json.loads(line)
            except (ValueError, UnicodeError) as exc:
                raise ProjectError(f"Corrupt complete event at line {index+1}; restore authoritative records") from exc
            if not isinstance(event, dict):
                raise ProjectError(f"Invalid event at line {index+1}")
            recorded_hash = event.get("hash")
            payload = {k: v for k, v in event.items() if k != "hash"}
            if (event.get("schema_version") != 1 or event.get("seq") != index+1 or event.get("previous") != previous
                    or recorded_hash != digest(payload)):
                raise ProjectError(f"Event chain validation failed at line {index+1}")
            apply_patch(state, event.get("patch"))
            events.append(event)
            previous = recorded_hash
            offset += len(line)
        if not events and not self._initializing:
            raise ProjectError("No complete initialization record remains; restore authoritative records")
        if events and events[0].get("operation") != "initialize":
            raise ProjectError("Event log does not start with initialization")
        if state.get("schema_version") != 1 or not isinstance(state.get("next_id"), int) or state["next_id"] < 1:
            raise ProjectError("Invalid materialized state schema or ID counter")
        if any(not isinstance(state.get(name), dict) for name in COLLECTIONS):
            raise ProjectError("Invalid materialized state collection")
        return state, events

    def state(self) -> dict:
        # Replay rather than trusting a stale or manually modified state cache.
        with self.locked():
            return self.replay()[0]

    def transact(self, operation: str, change: Callable[[dict], Any], *,
                 details: dict | None = None) -> Any:
        with self.locked():
            old, events = self.replay()
            state = deepcopy(old)
            result = change(state)
            patch = state_diff(old, state)
            if not patch and events:
                return result
            payload = {"schema_version": 1, "seq": len(events)+1,
                       "previous": events[-1]["hash"] if events else "0"*64,
                       "at": utc_now(), "operation": operation,
                       "details": details or {}, "patch": patch}
            event = {**payload, "hash": digest(payload)}
            with self.events.open("ab") as out:
                out.write(canonical(event)+b"\n")
                out.flush()
                os.fsync(out.fileno())
            atomic_json(self.state_path, state)
            return result

    def put_snapshot(self, value: dict) -> str:
        validate_snapshot_sources(value)
        snapshot_id = digest(value)
        path = self.meta / "snapshots" / f"{snapshot_id}.json"
        if path.is_symlink() or path.parent.is_symlink():
            raise ProjectError("Snapshot paths must not be symlinks")
        if path.exists():
            if digest(read_json(path)) != snapshot_id:
                raise ProjectError(f"Snapshot content mismatch: {snapshot_id}")
        else:
            atomic_json(path, value)
        return snapshot_id

    def snapshot(self, snapshot_id: str | None = None) -> dict:
        snapshot_id = snapshot_id or self.state().get("current_snapshot")
        if not snapshot_id or not re.fullmatch(r"[0-9a-f]{64}", snapshot_id):
            raise ProjectError("No valid snapshot selected; import the project first")
        path = self.meta / "snapshots" / f"{snapshot_id}.json"
        if path.is_symlink() or path.parent.is_symlink():
            raise ProjectError("Snapshot paths must not be symlinks")
        value = read_json(path)
        if digest(value) != snapshot_id:
            raise ProjectError(f"Snapshot integrity failed: {snapshot_id}")
        validate_snapshot_sources(value, allow_legacy=True)
        return value

    def snapshot_bytes_hash(self, snapshot_id: str) -> str:
        """Hash archive bytes without decoding the potentially large JSON.

        Imports record this hash with their authoritative source summary. A
        later freshness check can validate that same archive and source basis
        without materializing every historical statement and proof again.
        """
        if not isinstance(snapshot_id, str) or not re.fullmatch(r"[0-9a-f]{64}", snapshot_id):
            raise ProjectError("Invalid snapshot identity for byte validation")
        path = self.meta / "snapshots" / f"{snapshot_id}.json"
        if path.is_symlink() or path.parent.is_symlink():
            raise ProjectError("Snapshot paths must not be symlinks")
        checksum = hashlib.sha256()
        try:
            with path.open("rb") as source:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    checksum.update(chunk)
        except OSError as exc:
            raise ProjectError(f"Cannot validate source snapshot archive: {snapshot_id}") from exc
        return checksum.hexdigest()

    def recover(self) -> dict:
        with self.locked():
            state, events = self.replay(repair_tail=True)
            for sid in state.get("snapshot_history", []):
                self.snapshot(sid)
            atomic_json(self.state_path, state)
            return {"events": len(events), "current_snapshot": state["current_snapshot"],
                    "items": len(state["items"]), "tasks": len(state["tasks"]),
                    "recovered": True}

    def history(self, limit: int | None = None) -> list[dict]:
        with self.locked():
            events = self.replay()[1]
        selected = events[-limit:] if limit else events
        return [{k: v for k, v in e.items() if k != "patch"} for e in selected]
