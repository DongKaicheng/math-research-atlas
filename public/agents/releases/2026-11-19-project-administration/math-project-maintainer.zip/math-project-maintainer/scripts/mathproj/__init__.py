"""Versioned maintenance tools for mathematical source projects."""

__version__ = "0.2.0"
