"""Durable work queues with version-bound checkpoints and explicit ownership.

Task completion records satisfaction of a work item's acceptance criteria. It
does not admit a mathematical foundation, approve a proof, or certify a result.
Every mutation goes through the project event log; no second queue is kept.
"""
from __future__ import annotations

from collections import defaultdict, deque
from copy import deepcopy
import hashlib
import json
import os
from pathlib import PurePosixPath
import stat
from typing import Any

from .store import ProjectError, ProjectStore, canonical, digest, empty_state, utc_now, valid_name


STATUSES = frozenset({"ready", "running", "blocked", "review", "done", "cancelled"})
CLOSED = frozenset({"done", "cancelled"})
_TRANSITIONS = {
    "ready": {"running", "blocked", "cancelled"},
    "running": {"ready", "blocked", "review", "done", "cancelled"},
    "blocked": {"ready", "running", "cancelled"},
    "review": {"running", "blocked", "done", "cancelled"},
    "done": set(),
    "cancelled": set(),
}
_NON_EVIDENCE = frozenset({"time", "elapsed_time", "elapsed", "duration", "progress", "status"})


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProjectError(f"{field} must be a nonempty string")
    return value.strip()


def _strings(value: Any, field: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, (list, tuple, set, frozenset)):
        raise ProjectError(f"{field} must be a list of strings")
    return sorted({_text(entry, field) for entry in value})


def _task(state: dict, task_id: str, expected_revision: int | None = None) -> dict:
    task = state["tasks"].get(task_id)
    if not isinstance(task, dict):
        raise ProjectError(f"Unknown task: {task_id}")
    revision = task.get("revision", 0)  # Imports can create recheck tasks.
    if type(revision) is not int or revision < 0:
        raise ProjectError(f"Invalid task revision: {task_id}")
    if expected_revision is not None:
        if type(expected_revision) is not int or expected_revision < 0:
            raise ProjectError("expected_revision must be a nonnegative integer")
        if expected_revision != revision:
            raise ProjectError(f"Task {task_id} changed: expected revision {expected_revision}, current {revision}")
    if task.get("status") not in STATUSES:
        raise ProjectError(f"Invalid task status: {task_id}")
    return task


def _touch(task: dict) -> None:
    task["revision"] = task.get("revision", 0) + 1
    task["updated_at"] = utc_now()


def _owner(task: dict, assignee: str | None, *, required: bool = False) -> str | None:
    actor = _text(assignee, "assignee") if assignee is not None else task.get("assignee")
    if required and not actor:
        raise ProjectError("An assignee is required for this task action")
    if task.get("assignee") and actor != task["assignee"]:
        raise ProjectError(f"Task {task['id']} is assigned to {task['assignee']}; explicitly requeue it before a handoff")
    return actor


def _validate_task_graph(tasks: dict) -> None:
    """Validate missing references and find an actual cycle without recursion."""
    edges = {}
    for task_id, task in sorted(tasks.items()):
        deps = _strings(task.get("dependencies", []), "dependencies")
        missing = sorted(set(deps) - tasks.keys())
        if missing:
            raise ProjectError(f"Task {task_id} has missing dependencies: {', '.join(missing)}")
        edges[task_id] = deps
    finished: set[str] = set()
    for start in edges:
        if start in finished:
            continue
        trail = [start]
        positions = {start: 0}
        stack = [(start, 0)]
        while stack:
            node, index = stack[-1]
            if index == len(edges[node]):
                stack.pop()
                positions.pop(node)
                trail.pop()
                finished.add(node)
                continue
            dependency = edges[node][index]
            stack[-1] = (node, index + 1)
            if dependency in positions:
                cycle = trail[positions[dependency]:] + [dependency]
                raise ProjectError("Cyclic task dependencies: " + " -> ".join(cycle))
            if dependency not in finished:
                positions[dependency] = len(trail)
                trail.append(dependency)
                stack.append((dependency, 0))


def _unresolved(state: dict, task: dict) -> list[dict]:
    result = []
    for dependency in sorted(task.get("dependencies", [])):
        entry = state["tasks"].get(dependency)
        if entry is None:
            raise ProjectError(f"Task {task['id']} has missing dependency {dependency}")
        if entry.get("status") != "done":
            result.append({"id": dependency, "status": entry.get("status")})
    return result


def _require_dependencies(state: dict, task: dict) -> None:
    unresolved = _unresolved(state, task)
    if unresolved:
        raise ProjectError("Task dependencies are unresolved: " + ", ".join(
            f"{entry['id']} ({entry['status']})" for entry in unresolved))


def _edges(state: dict) -> list[dict]:
    from .project import dependency_edges
    return dependency_edges(state, include_candidates=True)


def _basis(store: ProjectStore, state: dict, target_ids: list[str], *,
           source_only: bool = False, manifest: dict | None = None) -> dict:
    """Capture only the task's targets and their transitive prerequisites."""
    from .project import matching_contexts
    edges = _edges(state)
    dependencies = defaultdict(set)
    for edge in edges:
        dependencies[edge["consumer"]].add(edge["dependency"])
    scope = set(target_ids) if target_ids else set(state["items"])
    queue = deque(sorted(scope))
    while queue:
        for dependency in sorted(dependencies.get(queue.popleft(), ())):
            if dependency not in scope:
                scope.add(dependency)
                queue.append(dependency)

    by_subject = defaultdict(dict)
    if not source_only:
        for collection in ("applications", "reviews", "issues", "citations"):
            for key, row in state.get(collection, {}).items():
                if not isinstance(row, dict):
                    continue
                subjects = {row.get(field) for field in ("proof_id", "item_id", "target_id", "subject_id")
                            if isinstance(row.get(field), str)}
                targets = row.get("target_ids", [])
                if isinstance(targets, list):
                    subjects.update(entry for entry in targets if isinstance(entry, str))
                binding = row.get("binding", {})
                if isinstance(binding, dict):
                    subjects.update(binding[field] for field in ("item_id", "proof_id", "target_id")
                                    if isinstance(binding.get(field), str))
                for subject in subjects:
                    by_subject[subject][collection + ":" + key] = row
                    # Bind both the citation and the current source registry
                    # entry. A citation can remain unchanged while its source
                    # revision moves, making the old evidence stale. Retired
                    # uses remain recorded but no longer depend on the source.
                    if collection == "citations" and row.get("active", True):
                        source_key = row.get("source_key")
                        if isinstance(source_key, str):
                            by_subject[subject]["source_records:" + source_key] = state.get("source_records", {}).get(source_key)

    inputs = {}
    for item_id in sorted(scope):
        item = state["items"].get(item_id)
        if item is None:
            inputs[item_id] = None
            continue
        proof_ids = item.get("proof_ids", [])
        proof_records = {pid: state["proofs"].get(pid) for pid in proof_ids}
        contexts = (matching_contexts(state, item) if item.get("source", {}).get("path")
                    else item.get("contexts", []))
        payload = {"item": item, "proofs": proof_records, "contexts": contexts}
        if not source_only:
            metadata = dict(by_subject.get(item_id, {}))
            for proof_id in proof_ids:
                metadata.update(by_subject.get(proof_id, {}))
                for ref in (state["proofs"].get(proof_id) or {}).get("references", []):
                    key = ref.get("application_key")
                    if key in state["applications"]:
                        metadata["applications:" + key] = state["applications"][key]
            payload.update(metadata=metadata, foundation=state["foundations"].get(item_id))
        inputs[item_id] = digest(payload)
    return {"snapshot": state.get("current_snapshot"),
            "mode": "source_only" if source_only else "full",
            "manifest_hash": digest(manifest if manifest is not None else store.manifest()),
            "inputs": inputs,
            "edges": [edge for edge in edges if edge["consumer"] in scope]}


def _original_basis(store: ProjectStore, state: dict, task: dict) -> dict:
    if isinstance(task.get("basis"), dict):
        return task["basis"]
    # Imported recheck tasks predate this module's additional fields. Recover
    # their source baseline from its immutable snapshot, not today's state.
    sid = task.get("base_snapshot")
    if sid:
        snapshot = store.snapshot(sid)
        historic = empty_state()
        historic.update(current_snapshot=sid, items=snapshot.get("items", {}),
                        proofs=snapshot.get("proofs", {}), contexts=snapshot.get("contexts", {}))
        return _basis(store, historic, task.get("target_ids", []), source_only=True,
                      manifest=snapshot["manifest"])
    return _basis(store, state, task.get("target_ids", []), source_only=True)


def _freshness_basis(store: ProjectStore, state: dict, task: dict) -> dict:
    from .graph import reverse_impact
    checkpoints = task.get("checkpoints", [])
    reference = checkpoints[-1].get("basis") if checkpoints else None
    reference = reference if isinstance(reference, dict) else _original_basis(store, state, task)
    current = _basis(store, state, task.get("target_ids", []), source_only=reference.get("mode") == "source_only")
    before, after = reference.get("inputs", {}), current["inputs"]
    changed = sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key))
    manifest_changed = reference.get("manifest_hash") != current["manifest_hash"]
    impact = reverse_impact(reference.get("edges", []) + current["edges"], changed)
    targets = set(task.get("target_ids", []))
    impacted = set(impact["affected"]) & targets if targets else set(impact["affected"])
    if manifest_changed:
        impacted.update(targets or after.keys())
    required = changed + (["metadata:manifest"] if manifest_changed else [])
    snapshot_changed = reference.get("snapshot") != current["snapshot"]
    return {"reference": "checkpoint" if checkpoints else "task_creation",
            "base_snapshot": reference.get("snapshot"), "current_snapshot": current["snapshot"],
            "snapshot_changed": snapshot_changed, "manifest_changed": manifest_changed,
            "stale": bool(snapshot_changed or required), "relevant_changes": bool(required),
            "changed_inputs": changed, "impacted_targets": sorted(impacted),
            "required_acknowledgments": sorted(required), "impact": impact}


def _artifact(store: ProjectStore, value: str) -> dict:
    """Hash a regular file using an anchored, non-symlink POSIX path walk."""
    value = _text(value, "artifact path")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or "\\" in value or not path.parts:
        raise ProjectError(f"Artifact must use a project-relative path without '..': {value}")
    directories = []
    fd = None
    try:
        directory = os.open(store.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        directories.append(directory)
        for component in path.parts[:-1]:
            directory = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            directories.append(directory)
        fd = os.open(path.parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ProjectError(f"Artifact is not a regular file: {value}")
        checksum = hashlib.sha256()
        while chunk := os.read(fd, 1024 * 1024):
            checksum.update(chunk)
        after = os.fstat(fd)
        fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
        if any(getattr(before, field) != getattr(after, field) for field in fields):
            raise ProjectError(f"Artifact changed while it was being read: {value}")
        return {"path": path.as_posix(), "sha256": checksum.hexdigest(), "size": before.st_size}
    except (OSError, ValueError) as exc:
        raise ProjectError(f"Cannot read safe artifact {value!r}: {exc}") from exc
    finally:
        if fd is not None:
            os.close(fd)
        for directory in reversed(directories):
            os.close(directory)


def _artifact_status(store: ProjectStore, checkpoint: dict | None) -> list[dict]:
    result = []
    for record in (checkpoint or {}).get("artifacts", []):
        try:
            current = _artifact(store, record["path"])
            result.append({**record, "status": "current" if current == record else "changed",
                           "current": current})
        except ProjectError as exc:
            result.append({**record, "status": "unavailable", "error": str(exc)})
    return result


def _evidence(value: Any) -> list[dict]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ProjectError("Evidence must be a list of structured JSON objects")
    result = []
    for entry in value:
        if not isinstance(entry, dict):
            raise ProjectError("Each evidence record must be an object")
        kind, summary = _text(entry.get("kind"), "evidence.kind"), _text(entry.get("summary"), "evidence.summary")
        try:
            record = json.loads(canonical(entry))
        except (ValueError, TypeError, RecursionError) as exc:
            raise ProjectError("Evidence must contain finite JSON values") from exc
        record.update(kind=kind, summary=summary)
        result.append(record)
    return result


def _report(store: ProjectStore, state: dict, task: dict) -> dict:
    from .workflow import freshness
    checkpoint = task.get("checkpoints", [])[-1] if task.get("checkpoints") else None
    unresolved = _unresolved(state, task)
    return {"task": deepcopy(task), "revision": task.get("revision", 0),
            "unresolved_dependencies": unresolved,
            "runnable": task["status"] == "ready" and not unresolved,
            "basis": _freshness_basis(store, state, task),
            "source_freshness": freshness(store, state),
            "latest_checkpoint": deepcopy(checkpoint),
            "artifacts": _artifact_status(store, checkpoint),
            "next_step": checkpoint.get("next_step") if checkpoint else task.get("acceptance"),
            "verification_scope": "task_workflow_only"}


def add_task(store: ProjectStore, title: str, *, acceptance: str,
             target_ids: list[str] | None = None, dependencies: list[str] | None = None,
             task_id: str | None = None, kind: str = "maintenance") -> dict:
    """Create an actionable task; unknown item/task references are rejected."""
    title, acceptance, kind = _text(title, "title"), _text(acceptance, "acceptance"), _text(kind, "kind")
    targets, deps = _strings(target_ids, "target_ids"), _strings(dependencies, "dependencies")
    if task_id is not None:
        valid_name(task_id, "task ID")
    def change(state):
        from .project import resolve_item
        resolved = sorted({resolve_item(state, target, active=False) for target in targets})
        identifier = task_id
        if identifier is None:
            serial = len(state["tasks"]) + 1
            identifier = f"task-{serial:06d}"
            while identifier in state["tasks"]:
                serial += 1
                identifier = f"task-{serial:06d}"
        if identifier in state["tasks"]:
            raise ProjectError(f"Task already exists: {identifier}")
        now = utc_now()
        task = {"id": identifier, "title": title, "kind": kind, "target_ids": resolved,
                "acceptance": acceptance, "dependencies": deps, "status": "ready", "assignee": None,
                "revision": 1, "base_snapshot": state.get("current_snapshot"),
                "created_at": now, "updated_at": now, "checkpoints": []}
        state["tasks"][identifier] = task
        _validate_task_graph(state["tasks"])
        if _unresolved(state, task):
            task.update(status="blocked", blocked_on="dependencies",
                        status_reason="Waiting for prerequisite tasks to finish.")
        task["basis"] = _basis(store, state, resolved)
        return _report(store, state, task)
    return store.transact("task_add", change, details={"task_id": task_id, "title": title})


def list_tasks(store: ProjectStore, *, status: str | None = None, assignee: str | None = None,
               include_closed: bool = False) -> list[dict]:
    """List queue records without reparsing sources once for every task."""
    if status is not None and status not in STATUSES:
        raise ProjectError("Unknown task status")
    state = store.state()
    result = []
    for task_id in sorted(state["tasks"]):
        task = _task(state, task_id)
        if status is not None and task["status"] != status:
            continue
        if status is None and not include_closed and task["status"] in CLOSED:
            continue
        if assignee is not None and task.get("assignee") != assignee:
            continue
        unresolved = _unresolved(state, task)
        result.append({**deepcopy(task), "revision": task.get("revision", 0),
                       "unresolved_dependencies": unresolved,
                       "runnable": task["status"] == "ready" and not unresolved})
    return result


def task_context(store: ProjectStore, task_id: str) -> dict:
    """Read resumable evidence, artifact integrity, stale inputs, and next work."""
    state = store.state()
    return _report(store, state, _task(state, task_id))


def claim_task(store: ProjectStore, task_id: str, assignee: str, *,
               expected_revision: int | None = None) -> dict:
    assignee = _text(assignee, "assignee")
    def change(state):
        task = _task(state, task_id, expected_revision)
        if task["status"] != "ready":
            raise ProjectError(f"Task {task_id} is {task['status']}, not ready")
        _owner(task, assignee, required=True)
        _require_dependencies(state, task)
        task.setdefault("basis", _original_basis(store, state, task))
        task.update(status="running", assignee=assignee, status_reason="")
        task.pop("blocked_on", None)
        task.setdefault("started_at", utc_now())
        _touch(task)
        return _report(store, state, task)
    return store.transact("task_claim", change, details={"task_id": task_id, "assignee": assignee})


def checkpoint_task(store: ProjectStore, task_id: str, assignee: str, *,
                    evidence: list[dict] | None = None, artifacts: list[str] | None = None,
                    next_step: str, summary: str = "", expected_revision: int | None = None) -> dict:
    """Append a checkpoint. The latest checkpoint is the completion evidence set.

    Evidence objects require kind and summary. A completion checkpoint needs
    an acceptance record with outcome='satisfied' and supporting evidence or
    an artifact; elapsed time is never sufficient. Restate relevant artifacts
    in the latest checkpoint.
    """
    assignee, next_step = _text(assignee, "assignee"), _text(next_step, "next_step")
    if not isinstance(summary, str):
        raise ProjectError("summary must be a string")
    records, paths = _evidence(evidence), _strings(artifacts, "artifacts")
    def change(state):
        from .workflow import freshness
        task = _task(state, task_id, expected_revision)
        _owner(task, assignee, required=True)
        if task["status"] not in {"running", "blocked", "review"} or not task.get("assignee"):
            raise ProjectError("Claim the task before recording a checkpoint")
        by_path = {record["path"]: record for record in (_artifact(store, path) for path in paths)}
        artifact_records = [by_path[path] for path in sorted(by_path)]
        checkpoint = {"id": f"{task_id}:checkpoint:{len(task.get('checkpoints', []))+1}",
                      "at": utc_now(), "assignee": assignee, "summary": summary.strip(),
                      "evidence": records, "artifacts": artifact_records, "next_step": next_step,
                      "basis": _basis(store, state, task.get("target_ids", [])),
                      "source_freshness": freshness(store, state)}
        task.setdefault("checkpoints", []).append(checkpoint)
        _touch(task)
        return _report(store, state, task)
    return store.transact("task_checkpoint", change, details={"task_id": task_id, "assignee": assignee})


def _complete(store: ProjectStore, state: dict, task: dict, acknowledgments: list[str], reason: str) -> None:
    from .workflow import require_fresh
    _require_dependencies(state, task)
    require_fresh(store, state)
    checkpoints = task.get("checkpoints", [])
    if not checkpoints:
        raise ProjectError("Task completion requires an evidence checkpoint")
    checkpoint = checkpoints[-1]
    evidence = checkpoint.get("evidence", [])
    substantive = [row for row in evidence if row.get("kind", "").lower() not in _NON_EVIDENCE
                   and isinstance(row.get("summary"), str) and row["summary"].strip()]
    accepted = any(row.get("kind") == "acceptance" and row.get("outcome") == "satisfied" for row in substantive)
    supporting = [row for row in substantive if row.get("kind") != "acceptance"]
    if not accepted or not (supporting or checkpoint.get("artifacts")):
        raise ProjectError("The latest checkpoint needs concrete evidence and an acceptance record with outcome='satisfied'; elapsed time is insufficient")
    changed_artifacts = [row["path"] for row in _artifact_status(store, checkpoint) if row["status"] != "current"]
    if changed_artifacts:
        raise ProjectError("Checkpoint artifacts changed or are unavailable: " + ", ".join(changed_artifacts))
    freshness = _freshness_basis(store, state, task)
    if acknowledgments and not reason.strip():
        raise ProjectError("Acknowledging changed inputs requires a concrete reason")
    unknown = set(acknowledgments) - state["items"].keys() - {"metadata:manifest"}
    if unknown:
        raise ProjectError("Unknown acknowledged inputs: " + ", ".join(sorted(unknown)))
    missing = set(freshness["required_acknowledgments"]) - set(acknowledgments)
    if missing:
        raise ProjectError("Checkpoint has changed relevant inputs; record a current checkpoint or explicitly acknowledge: " + ", ".join(sorted(missing)))
    task["completion"] = {"at": utc_now(), "checkpoint_id": checkpoint["id"],
                          "snapshot": state.get("current_snapshot"),
                          "acknowledged_changes": acknowledgments,
                          "acknowledgment_reason": reason.strip() if acknowledgments else None,
                          "verification_scope": "task_acceptance_only"}


def _release_dependents(state: dict) -> list[str]:
    released = []
    for task_id, task in sorted(state["tasks"].items()):
        if task.get("status") == "blocked" and task.get("blocked_on") == "dependencies" and not _unresolved(state, task):
            task.update(status="ready", status_reason="Prerequisite tasks completed.")
            task.pop("blocked_on", None)
            _touch(task)
            released.append(task_id)
    return released


def transition_task(store: ProjectStore, task_id: str, status: str, *, assignee: str | None = None,
                    reason: str = "", expected_revision: int | None = None,
                    acknowledge_changes: list[str] | None = None) -> dict:
    """Perform an audited transition. Requeueing a running task releases ownership.

    Changed checkpoint inputs can be acknowledged by their exact IDs and a
    reason. A changed manifest uses the token 'metadata:manifest'. This does
    not bypass importing pending source/context edits or artifact integrity.
    """
    if status not in STATUSES:
        raise ProjectError("Unknown task status")
    if not isinstance(reason, str):
        raise ProjectError("reason must be a string")
    acknowledgments = _strings(acknowledge_changes, "acknowledge_changes")
    if acknowledgments and status != "done":
        raise ProjectError("Changed-input acknowledgments apply only to completion")
    def change(state):
        task = _task(state, task_id, expected_revision)
        old_status = task["status"]
        if status not in _TRANSITIONS[old_status]:
            raise ProjectError(f"Task transition {old_status} -> {status} is not allowed")
        actor = _owner(task, assignee, required=status in {"running", "review", "done"})
        if status in {"blocked", "cancelled"} or status == "ready":
            _text(reason, "transition reason")
        if status in {"ready", "running", "review", "done"}:
            _require_dependencies(state, task)
        if status == "review" and not task.get("checkpoints"):
            raise ProjectError("Record a checkpoint before requesting task review")
        if status == "done":
            _complete(store, state, task, acknowledgments, reason)
        if status == "ready":
            task["assignee"] = None
        elif status == "running":
            task["assignee"] = actor
            task.setdefault("started_at", utc_now())
        task.update(status=status, status_reason=reason.strip())
        if status == "blocked":
            task["blocked_on"] = "manual"
        else:
            task.pop("blocked_on", None)
        if status == "cancelled":
            task["cancelled_at"] = utc_now()
        _touch(task)
        released = _release_dependents(state) if status == "done" else []
        return {**_report(store, state, task), "released_tasks": released}
    return store.transact("task_transition", change, details={"task_id": task_id, "status": status,
                          "assignee": assignee, "reason": reason, "acknowledge_changes": acknowledgments})


def resume_task(store: ProjectStore, task_id: str, assignee: str, *,
                expected_revision: int | None = None) -> dict:
    """Resume an owned task while retaining every prior checkpoint and basis."""
    assignee = _text(assignee, "assignee")
    def change(state):
        task = _task(state, task_id, expected_revision)
        if task["status"] in CLOSED:
            raise ProjectError("Closed tasks cannot resume; create a follow-up task")
        _owner(task, assignee, required=True)
        _require_dependencies(state, task)
        task.setdefault("basis", _original_basis(store, state, task))
        task.update(status="running", assignee=assignee, resumed_at=utc_now(), status_reason="")
        task.pop("blocked_on", None)
        task.setdefault("started_at", utc_now())
        _touch(task)
        return _report(store, state, task)
    return store.transact("task_resume", change, details={"task_id": task_id, "assignee": assignee})


def set_task_dependencies(store: ProjectStore, task_id: str, dependencies: list[str], *,
                          assignee: str | None = None, expected_revision: int | None = None) -> dict:
    deps = _strings(dependencies, "dependencies")
    def change(state):
        task = _task(state, task_id, expected_revision)
        _owner(task, assignee)
        if task["status"] not in {"ready", "blocked"}:
            raise ProjectError("Requeue or block the task before editing its prerequisites")
        if task.get("dependencies", []) == deps:
            return _report(store, state, task)
        task["dependencies"] = deps
        _validate_task_graph(state["tasks"])
        if _unresolved(state, task):
            if task["status"] == "ready" or task.get("blocked_on") == "dependencies":
                task.update(status="blocked", blocked_on="dependencies",
                            status_reason="Waiting for prerequisite tasks to finish.")
        elif task.get("blocked_on") == "dependencies":
            task.update(status="ready", status_reason="Prerequisite tasks resolved.")
            task.pop("blocked_on", None)
        _touch(task)
        return _report(store, state, task)
    return store.transact("task_dependencies", change, details={"task_id": task_id, "dependencies": deps,
                          "assignee": assignee})
