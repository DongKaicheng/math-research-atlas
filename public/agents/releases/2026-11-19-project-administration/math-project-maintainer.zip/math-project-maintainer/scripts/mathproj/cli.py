"""Command-line interface for the Math Project Maintainer skill."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import shutil
import sys

from . import __version__
from .project import (dependency_edges, ingest, item_history, resolve_item,
                      set_context, set_foundation)
from .store import ProjectError, ProjectStore, atomic_json, contained, read_json


def _file_text(value: str | None, path: str | None) -> str:
    if path:
        try:
            return Path(path).read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise ProjectError(f"Cannot read text file {path}: {exc}") from exc
    return value or ""


def _text_arguments(parser, name="text", *, required=True):
    group = parser.add_mutually_exclusive_group(required=required)
    group.add_argument("--"+name)
    group.add_argument("--"+name+"-file")


def _guard_report_destination(args, output: Path, project: Path) -> None:
    if output == project:
        raise ProjectError("JSON report output must not replace the project root")
    if output in {project / "mathproject.json", project / "mpm"} or project / "mpm" in output.parents or output.suffix == ".tex":
        raise ProjectError("JSON report output must not replace project metadata or mathematical source files")
    if output.exists() and not output.is_file():
        raise ProjectError("JSON report output must be a file path")
    if project not in output.parents:
        return
    manifest_path = project / "mathproject.json"
    if manifest_path.is_file():
        store = ProjectStore(project)
        manifest = store.manifest()
    else:
        store = None
        manifest = {"source_roots": getattr(args, "source_roots", None) or ["content"],
                    "entrypoints": getattr(args, "entrypoints", None) or (["main.tex"] if args.command == "demo" else [])}
    for value in manifest["source_roots"]:
        root = contained(project, value)
        if output == root or root in output.parents:
            raise ProjectError("JSON report output must be outside declared mathematical source roots")
    for value in manifest["entrypoints"]:
        entry = contained(project, value)
        candidates = [entry] if entry.suffix else [entry, entry.with_suffix(".tex")]
        if output in candidates:
            raise ProjectError("JSON report output must not replace a mathematical entrypoint")
    current = None
    if store is not None:
        try:
            state = store.state()
        except ProjectError as exc:
            if (args.command != "recover" or str(exc) !=
                    "Incomplete final event; run recover to preserve and remove the interrupted tail"):
                raise
            # Recovery must remain possible with a report inside the project.
            # Do not repair the ledger in this guard. Its committed source
            # summary is unavailable, so this exceptional path validates all
            # archives to retain protection for previously imported sources.
            for archive in sorted((store.meta / "snapshots").glob("*.json")):
                for source in store.snapshot(archive.stem)["files"]:
                    if output == contained(project, source["path"]):
                        raise ProjectError("JSON report output must not replace an imported mathematical source")
            state = {}
        basis = state.get("source_basis")
        trusted_basis = isinstance(basis, dict) and basis.get("snapshot") == state.get("current_snapshot")
        if not trusted_basis and state.get("current_snapshot"):
            basis = store.snapshot(state["current_snapshot"])
        for source in (basis or {}).get("files", []):
            if output == contained(project, source["path"]):
                raise ProjectError("JSON report output must not replace an imported mathematical source")
        layout = (basis or {}).get("source_layout")
        recorded = {source["path"] for source in (basis or {}).get("files", [])}
        if (trusted_basis and isinstance(layout, dict)
                and isinstance(basis.get("reader_fingerprint"), str)
                and all(row.get("selected") is None or row["selected"] in recorded
                        for row in layout.get("lookups", []))
                and all(row.get("status") != "file" or row.get("resolved") in recorded
                        for row in layout.get("discovered", []))):
            from .workflow import freshness
            # This validates the authoritative import's archive, reader,
            # manifest, source bytes and lookup choices without reparsing a
            # clean corpus. Context changes and recorded structural errors
            # do not alter membership. Unreadable/unloaded sources above
            # require a parse because their bytes were not recorded.
            check = freshness(store, state)
            if all(reason["kind"] in {"contexts_changed", "parse_error"} for reason in check["reasons"]):
                current = basis
    if current is None:
        from .latex import parse_project
        current = parse_project(project, entrypoints=manifest["entrypoints"] or None,
                                source_roots=manifest["source_roots"])
    for source in current["files"]:
        if output == contained(project, source["path"]):
            raise ProjectError("JSON report output must not replace a current mathematical source")
    for lookup in current.get("source_layout", {}).get("lookups", []):
        if lookup.get("status") == "invalid":
            continue
        name = Path(lookup["value"].strip())
        origin = lookup.get("from_path")
        bases = [project] if name.is_absolute() or origin is None else [project, (project / origin).parent]
        for base in bases:
            initial = name if name.is_absolute() else base / name
            try:
                candidates = [initial] if initial.suffix else [initial, initial.with_suffix(".tex")]
            except ValueError:
                candidates = [initial]
            for candidate in candidates:
                try:
                    resolved = contained(project, str(candidate))
                except (ProjectError, OSError, RuntimeError, ValueError):
                    continue
                if output == resolved:
                    raise ProjectError("JSON report output must not create or replace a literal mathematical source lookup")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="math_project.py", description="Maintain versioned mathematical sources, applications, reviews and support plans.")
    p.add_argument("--project", "-p", default=".", help="Project root containing mathproject.json")
    p.add_argument("--output", "-o", help="Write the JSON result to this file as well as stdout")
    p.add_argument("--version", action="version", version=__version__)
    p.add_argument("--debug", action="store_true", help="Show Python tracebacks for developer diagnostics")
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="Inspect local runtime, search, export and LaTeX capabilities without a project")

    init = sub.add_parser("init", help="Initialize records without overwriting an existing project")
    init.add_argument("--name", required=True)
    init.add_argument("--namespace", default="MATH")
    init.add_argument("--source-root", action="append", dest="source_roots")
    init.add_argument("--entrypoint", action="append", dest="entrypoints")
    demo = sub.add_parser("demo", help="Create and import the original bundled demonstration corpus")
    demo.add_argument("--name", default="Mathematical Foundations Demo")
    demo.add_argument("--namespace", default="DEMO")
    imp = sub.add_parser("ingest", help="Import source objects into a reproducible snapshot")
    imp.add_argument("--allow-incomplete", action="store_true", help="Import structural errors as an explicitly incomplete snapshot")
    sub.add_parser("status", help="Show current source freshness and record counts")
    items = sub.add_parser("items", help="List permanent item IDs")
    items.add_argument("--kind")
    items.add_argument("--include-missing", action="store_true")
    show = sub.add_parser("show", help="Inspect one item and its proofs")
    show.add_argument("item")
    show.add_argument("--snapshot")
    hist = sub.add_parser("history", help="Read event history or item snapshots")
    hist.add_argument("item", nargs="?")
    hist.add_argument("--limit", type=int, default=20)
    sub.add_parser("recover", help="Verify authoritative records and rebuild disposable state")

    context = sub.add_parser("context", help="Manage scoped ambient assumptions and conventions")
    ctx = context.add_subparsers(dest="action", required=True)
    ctx.add_parser("list")
    cs = ctx.add_parser("set")
    cs.add_argument("key")
    _text_arguments(cs)
    cs.add_argument("--global", dest="global_scope", action="store_true")
    cs.add_argument("--path", action="append", dest="paths")
    cs.add_argument("--label", action="append", dest="labels")

    foundation = sub.add_parser("foundation", help="Record explicitly admitted inputs")
    fsub = foundation.add_subparsers(dest="action", required=True)
    fsub.add_parser("list")
    fa = fsub.add_parser("add")
    fa.add_argument("item")
    fa.add_argument("--kind", choices=["axiom", "definition", "external_theorem", "assumption"], default="external_theorem")
    _text_arguments(fa, "reason")
    fr = fsub.add_parser("revoke")
    fr.add_argument("item")
    _text_arguments(fr, "reason")

    application = sub.add_parser("application", help="Record exact uses, mentions and internal references")
    ap = application.add_subparsers(dest="action", required=True)
    at = ap.add_parser("template")
    at.add_argument("proof", help="Proof ID or ITEM:statement")
    ar = ap.add_parser("record")
    ar.add_argument("--file", required=True, help="JSON list, or an object with records/applications")

    review = sub.add_parser("review", help="Prepare and submit version-bound mathematical reviews")
    rv = review.add_subparsers(dest="action", required=True)
    rp = rv.add_parser("prepare")
    rp.add_argument("item")
    rp.add_argument("--proof")
    rr = rv.add_parser("record")
    rr.add_argument("--file", required=True, help="JSON review report matching the prepared template")
    rl = rv.add_parser("list")
    rl.add_argument("--item")

    issue = sub.add_parser("issue", help="Inspect and resolve concrete review findings")
    iss = issue.add_subparsers(dest="action", required=True)
    il = iss.add_parser("list")
    il.add_argument("--item")
    il.add_argument("--all", action="store_true")
    ir = iss.add_parser("resolve")
    ir.add_argument("issue")
    ir.add_argument("--reviewer", required=True)
    ir.add_argument("--disposition", choices=["fixed", "invalid", "superseded"], default="fixed")
    _text_arguments(ir, "reason")

    support = sub.add_parser("support", help="Compute support from eligible alternative proofs and explicit roots")
    support.add_argument("items", nargs="*")
    impact = sub.add_parser("impact", help="Find reverse dependency impact and shortest witnesses")
    impact.add_argument("items", nargs="+")
    impact.add_argument("--confirmed-only", action="store_true")
    impact.add_argument("--path-to", help="Reconstruct one path to this affected ID")

    tasks = sub.add_parser("task", help="Maintain recoverable work and evidence checkpoints")
    ts = tasks.add_subparsers(dest="action", required=True)
    ta = ts.add_parser("add")
    ta.add_argument("--title", required=True)
    _text_arguments(ta, "acceptance")
    ta.add_argument("--target", action="append", dest="targets")
    ta.add_argument("--depends-on", action="append", dest="dependencies")
    ta.add_argument("--id", dest="task_id")
    ta.add_argument("--kind", default="maintenance")
    tl = ts.add_parser("list")
    tl.add_argument("--status")
    tl.add_argument("--assignee")
    tl.add_argument("--all", action="store_true")
    tv = ts.add_parser("show")
    tv.add_argument("task")
    for action in ("claim", "resume"):
        tc = ts.add_parser(action)
        tc.add_argument("task")
        tc.add_argument("--assignee", required=True)
        tc.add_argument("--expected-revision", type=int)
    tcp = ts.add_parser("checkpoint")
    tcp.add_argument("task")
    tcp.add_argument("--assignee", required=True)
    tcp.add_argument("--file", required=True, help="JSON with evidence, artifacts, next_step and optional summary")
    tcp.add_argument("--expected-revision", type=int)
    tt = ts.add_parser("transition")
    tt.add_argument("task")
    tt.add_argument("status", choices=["ready", "running", "blocked", "review", "done", "cancelled"])
    tt.add_argument("--assignee")
    _text_arguments(tt, "reason", required=False)
    tt.add_argument("--expected-revision", type=int)
    tt.add_argument("--acknowledge-change", action="append", dest="acknowledge_changes")
    td = ts.add_parser("dependencies")
    td.add_argument("task")
    td.add_argument("--depends-on", action="append", dest="dependencies", default=[])
    td.add_argument("--assignee")
    td.add_argument("--expected-revision", type=int)
    changes = sub.add_parser("change", help="Prepare, inspect and apply recoverable source edits")
    ch = changes.add_subparsers(dest="action", required=True)
    cp = ch.add_parser("prepare")
    cp.add_argument("--file", required=True, help="JSON proposal with base_snapshot, author, rationale and exact before hashes")
    ch.add_parser("list")
    cv = ch.add_parser("show")
    cv.add_argument("proposal")
    ca = ch.add_parser("apply")
    ca.add_argument("proposal")
    ca.add_argument("--no-import", action="store_true")
    ch.add_parser("recover")
    search = sub.add_parser("search", help="Retrieve snapshot-bound text using a disposable lexical index")
    search.add_argument("query")
    search.add_argument("--snapshot")
    search.add_argument("--kind")
    search.add_argument("--path")
    search.add_argument("--limit", type=int, default=20)
    search.add_argument("--exact", action="store_true", help="Case-sensitive literal substring including formula punctuation")
    tags = sub.add_parser("stacks-tag", help="Map supplied Stacks Tags into an exact local snapshot without changing identities")
    tags.add_argument("tags", nargs="*", help="One or more four-character uppercase Stacks Tags")
    tags.add_argument("--registry", required=True, help="Absolute local path to the supplied Stacks tags/tags registry")
    tags.add_argument("--snapshot", help="Recorded snapshot ID; defaults to the current imported snapshot")
    tags.add_argument("--audit", action="store_true", help="Count all registry mappings with bounded diagnostics instead of individual tags")
    index = sub.add_parser("reindex", help="Rebuild the disposable search index")
    index.add_argument("--snapshot")
    packet = sub.add_parser("packet", help="Assemble statements, proofs and direct prerequisites with explicit omissions")
    packet.add_argument("items", nargs="+")
    packet.add_argument("--snapshot")
    packet.add_argument("--max-items", type=int, default=40)
    packet.add_argument("--max-chars", type=int, default=30000)
    release = sub.add_parser("release", help="Freeze a reviewed support closure and its exact evidence")
    rs = release.add_subparsers(dest="action", required=True)
    rc = rs.add_parser("create")
    rc.add_argument("name")
    rc.add_argument("--target", action="append", dest="targets")
    rs.add_parser("list")
    export = sub.add_parser("export", help="Create a local static atlas without external publication")
    export.add_argument("--destination", required=True, help="A new project-relative directory outside sources and metadata")
    export.add_argument("--mode", choices=["preview", "reviewed"], default="preview")
    export.add_argument("--release", dest="release_id")
    export.add_argument("--snapshot")
    export.add_argument("--target", action="append", dest="targets")
    api = sub.add_parser("api", help="Export a frozen public corpus and independent read-only REST/MCP server")
    aps = api.add_subparsers(dest="action", required=True)
    ape = aps.add_parser("export", help="Owner operation: publish only whitelisted fields of a reviewed release")
    ape.add_argument("--release", dest="release_id", required=True)
    ape.add_argument("--destination", required=True, help="New directory outside mathematical source roots and metadata; absolute paths allowed")
    ape.add_argument("--title", help="Public corpus title; otherwise use the frozen project name")
    ape.add_argument("--demo", action="store_true", help="Explicitly label this corpus as a demonstration")
    sources = sub.add_parser("source", help="Record exact bibliographic evidence without automatic foundation admission")
    ss = sources.add_subparsers(dest="action", required=True)
    sa = ss.add_parser("add")
    sa.add_argument("key")
    sa.add_argument("--file", required=True)
    ss.add_parser("list")
    sa = ss.add_parser("audit")
    sa.add_argument("--include-unowned", action="store_true", help="Also inspect archived file citations outside indexed objects")
    sc = ss.add_parser("cite")
    sc.add_argument("item")
    sc.add_argument("source_key")
    sc.add_argument("--file", required=True)
    sr = ss.add_parser("retire")
    sr.add_argument("citation")
    sr.add_argument("--expected-revision", required=True)
    sr.add_argument("--reviewer", required=True)
    _text_arguments(sr, "reason")
    return p


def run(args: argparse.Namespace) -> object:
    root = Path(args.project).expanduser().resolve()
    command = args.command
    if command == "doctor":
        from .doctor import runtime_report
        return runtime_report()
    if command == "init":
        store = ProjectStore.create(root, args.name, args.namespace, args.source_roots, args.entrypoints)
        return {"project": str(root), "manifest": store.manifest(), "initialized": True}
    if command == "demo":
        if root.exists() and any(root.iterdir()):
            raise ProjectError("Demo destination must be empty; existing files are never replaced")
        source = Path(__file__).resolve().parents[2] / "assets" / "demo"
        store = ProjectStore.create(root, args.name, args.namespace, ["content"], ["main.tex"])
        shutil.copytree(source, root, dirs_exist_ok=True, ignore=shutil.ignore_patterns("*.pdf", "*.aux", "*.log", "*.xdv", "*.fmt"))
        return {"project": str(root), "import": ingest(store),
                "next": "Inspect contexts.proposed.json, register the appropriate scopes, then import and review. Nothing is pre-certified."}
    store = ProjectStore(root)
    if command == "ingest":
        return ingest(store, allow_incomplete=args.allow_incomplete)
    if command == "recover":
        from .changes import recover_changes
        return {"records": store.recover(), "source_changes": recover_changes(store)}
    if command == "status":
        from .workflow import freshness
        state = store.state()
        return {"project": str(root), "name": store.manifest()["name"], "snapshot": state["current_snapshot"],
                "items": dict(Counter(i.get("lifecycle") for i in state["items"].values())),
                "proofs": sum(bool(p.get("active")) for p in state["proofs"].values()),
                "reviews": len(state["reviews"]), "open_issues": sum(i.get("status") == "open" for i in state["issues"].values()),
                "tasks": dict(Counter(t["status"] for t in state["tasks"].values())),
                "freshness": freshness(store, state)}
    if command == "items":
        state = store.state()
        return [{k: i.get(k) for k in ("id", "kind", "label", "title", "source", "lifecycle", "revision", "proof_ids")}
                for _, i in sorted(state["items"].items())
                if (args.include_missing or i.get("lifecycle") == "active") and (not args.kind or i["kind"] == args.kind)]
    if command == "show":
        state = store.state()
        iid = resolve_item(state, args.item, active=False)
        data = store.snapshot(args.snapshot) if args.snapshot else state
        if iid not in data["items"]:
            raise ProjectError(f"{iid} does not exist in the selected snapshot")
        item = data["items"][iid]
        return {"snapshot": args.snapshot or state["current_snapshot"], "item": item,
                "proofs": [data["proofs"][pid] for pid in item["proof_ids"] if pid in data["proofs"]]}
    if command == "history":
        return item_history(store, args.item) if args.item else store.history(args.limit)
    if command == "context":
        if args.action == "list":
            return store.state()["contexts"]
        return set_context(store, args.key, _file_text(args.text, args.text_file), paths=args.paths,
                           labels=args.labels, global_scope=args.global_scope)
    if command == "foundation":
        if args.action == "list":
            return store.state()["foundations"]
        reason = _file_text(args.reason, args.reason_file)
        if args.action == "add":
            return set_foundation(store, args.item, reason, args.kind)
        if not reason.strip():
            raise ProjectError("Revoking an admitted input requires a reason")
        def revoke(state):
            iid = resolve_item(state, args.item, active=False)
            if iid not in state["foundations"]:
                raise ProjectError("Item is not an admitted foundation")
            state["foundations"][iid].update(active=False, revocation_reason=reason)
            return state["foundations"][iid]
        return store.transact("revoke_foundation", revoke)
    if command == "application":
        from .workflow import application_templates, record_applications
        if args.action == "template":
            return application_templates(store, args.proof)
        payload = read_json(Path(args.file))
        records = payload.get("records", payload.get("applications")) if isinstance(payload, dict) else payload
        return record_applications(store, records)
    if command == "review":
        from .workflow import prepare_review, record_review
        if args.action == "prepare":
            return prepare_review(store, args.item, args.proof)
        if args.action == "record":
            return record_review(store, read_json(Path(args.file)))
        state = store.state()
        iid = resolve_item(state, args.item, active=False) if args.item else None
        return [r for r in state["reviews"].values() if not iid or r["binding"]["item_id"] == iid]
    if command == "issue":
        from .workflow import resolve_issue
        if args.action == "resolve":
            return resolve_issue(store, args.issue, reason=_file_text(args.reason, args.reason_file),
                                 reviewer=args.reviewer, disposition=args.disposition)
        state = store.state()
        iid = resolve_item(state, args.item, active=False) if args.item else None
        return [i for i in state["issues"].values() if (not iid or i["item_id"] == iid) and (args.all or i["status"] == "open")]
    if command == "support":
        from .workflow import support_report
        return support_report(store, args.items)
    if command == "impact":
        from .graph import impact_path, reverse_impact
        state = store.state()
        seeds = [resolve_item(state, x, active=False) for x in args.items]
        result = reverse_impact(dependency_edges(state, include_candidates=not args.confirmed_only), seeds)
        if args.path_to:
            target = resolve_item(state, args.path_to, active=False)
            result["selected_path"] = impact_path(result, target)
        return result
    if command == "task":
        from .tasks import (add_task, checkpoint_task, claim_task, list_tasks,
                            resume_task, set_task_dependencies, task_context, transition_task)
        if args.action == "add":
            return add_task(store, args.title, acceptance=_file_text(args.acceptance, args.acceptance_file),
                            target_ids=args.targets, dependencies=args.dependencies, task_id=args.task_id, kind=args.kind)
        if args.action == "list":
            return list_tasks(store, status=args.status, assignee=args.assignee, include_closed=args.all)
        if args.action == "show":
            return task_context(store, args.task)
        if args.action == "dependencies":
            return set_task_dependencies(store, args.task, args.dependencies,
                                         assignee=args.assignee, expected_revision=args.expected_revision)
        if args.action in {"claim", "resume"}:
            fn = claim_task if args.action == "claim" else resume_task
            return fn(store, args.task, args.assignee, expected_revision=args.expected_revision)
        if args.action == "checkpoint":
            payload = read_json(Path(args.file))
            return checkpoint_task(store, args.task, args.assignee, evidence=payload.get("evidence"),
                                   artifacts=payload.get("artifacts"), next_step=payload.get("next_step", ""),
                                   summary=payload.get("summary", ""), expected_revision=args.expected_revision)
        return transition_task(store, args.task, args.status, assignee=args.assignee,
                               reason=_file_text(args.reason, args.reason_file), expected_revision=args.expected_revision,
                               acknowledge_changes=args.acknowledge_changes)
    if command == "change":
        from .changes import apply_proposal, create_proposal, inspect_proposal, recover_changes
        if args.action == "prepare":
            return create_proposal(store, read_json(Path(args.file)))
        if args.action == "show":
            return inspect_proposal(store, args.proposal)
        if args.action == "apply":
            return apply_proposal(store, args.proposal, import_after=not args.no_import)
        if args.action == "recover":
            return recover_changes(store)
        return [{k: v.get(k) for k in ("id", "title", "author", "status", "base_snapshot", "targets", "created_at")}
                for _, v in sorted(store.state()["proposals"].items())]
    if command == "search":
        from .search import search
        return search(store, args.query, snapshot=args.snapshot, kind=args.kind, path=args.path, limit=args.limit, exact=args.exact)
    if command == "stacks-tag":
        from .stacks_tags import lookup_tags, audit_tags
        if args.audit:
            if args.tags:
                raise ProjectError("Choose either individual Stacks Tags or --audit, not both")
            return audit_tags(store, args.registry, snapshot=args.snapshot)
        return lookup_tags(store, args.registry, args.tags, snapshot=args.snapshot)
    if command == "reindex":
        from .search import rebuild_index
        return rebuild_index(store, snapshot=args.snapshot, force=True)
    if command == "packet":
        from .search import context_packet
        return context_packet(store, args.items, snapshot=args.snapshot, max_items=args.max_items, max_chars=args.max_chars)
    if command == "release":
        if args.action == "list":
            return store.state()["releases"]
        from .publish import create_release
        return create_release(store, args.name, args.targets)
    if command == "export":
        from .publish import export_project
        return export_project(store, args.destination, snapshot=args.snapshot, targets=args.targets,
                              mode=args.mode, release_id=args.release_id)
    if command == "api":
        from .public_api import export_public_api
        return export_public_api(store, args.destination, args.release_id, title=args.title, demo=args.demo)
    if command == "source":
        from .sources import audit_sources, cite_source, register_source, retire_citation
        if args.action == "add":
            return register_source(store, args.key, read_json(Path(args.file)))
        if args.action == "cite":
            return cite_source(store, args.item, args.source_key, read_json(Path(args.file)))
        if args.action == "audit":
            return audit_sources(store, include_unowned=args.include_unowned)
        if args.action == "retire":
            return retire_citation(store, args.citation, expected_revision=args.expected_revision,
                                   reason=_file_text(args.reason, args.reason_file), reviewer=args.reviewer)
        state = store.state()
        return {"sources": state["source_records"], "citations": state["citations"]}
    raise ProjectError(f"Unsupported command: {command}")


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.output:
            output = Path(args.output).expanduser().resolve()
            project = Path(args.project).expanduser().resolve()
            _guard_report_destination(args, output, project)
        result = run(args)
        if args.output:
            atomic_json(Path(args.output).expanduser().resolve(), result)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except (ProjectError, OSError, UnicodeError, ValueError, TypeError, KeyError) as exc:
        if args.debug:
            raise
        print(json.dumps({"error": str(exc), "command": args.command}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
