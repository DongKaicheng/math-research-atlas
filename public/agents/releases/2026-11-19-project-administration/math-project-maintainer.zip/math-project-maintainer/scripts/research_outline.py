#!/usr/bin/env python3
"""Read-only structural checks for a derived research outline, never proof certification."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys


RELATIONS = {
    "implication", "conditional_implication", "special_case", "proof_dependency",
    "alternative_route", "analogy", "navigation", "work_order",
}
CONSEQUENCE_RELATIONS = {"implication", "conditional_implication", "special_case"}
PROOF_STATES = {"complete", "partial", "not_recovered", "not_applicable"}


def audit_outline(data):
    """Check declared coverage and relations without reading or changing a project."""
    errors, warnings = [], []

    def text(value, at):
        if not isinstance(value, str) or not value.strip():
            errors.append(f"{at}: expected nonempty string")
            return False
        return True

    def strings(value, at):
        if not isinstance(value, list):
            errors.append(f"{at}: expected array of strings")
            return []
        valid = [v for i, v in enumerate(value) if text(v, f"{at}[{i}]")]
        if len(set(valid)) != len(valid):
            errors.append(f"{at}: duplicate value")
        return valid

    def objects(value, at):
        if not isinstance(value, list):
            errors.append(f"{at}: expected array of objects")
            return {}
        result = {}
        for i, row in enumerate(value):
            if not isinstance(row, dict):
                errors.append(f"{at}[{i}]: expected object")
                continue
            key = row.get("id")
            if not text(key, f"{at}[{i}].id"):
                continue
            if key in result:
                errors.append(f"{at}: duplicate ID {key}")
            result[key] = row
        return result

    def member(value, choices, at):
        if not isinstance(value, str) or value not in choices:
            errors.append(f"{at}: expected one of {', '.join(sorted(choices))}")
            return False
        return True

    if not isinstance(data, dict):
        return {"valid": False, "errors": ["outline: expected object"], "warnings": []}
    if type(data.get("schema")) is not int or data["schema"] != 1:
        errors.append("schema: expected integer 1")
    for field in ("snapshot", "scope"):
        text(data.get(field), field)
    sources = objects(data.get("sources"), "sources")
    for key, source in sources.items():
        text(source.get("locator"), f"sources.{key}.locator")
        available = source.get("availability")
        if member(available, {"available", "summary_only", "missing"}, f"sources.{key}.availability"):
            if available != "available":
                warnings.append(f"sources.{key}: {available}; source coverage remains qualified")

    required = strings(data.get("required_ids"), "required_ids")
    records = objects(data.get("records"), "records")
    for key in required:
        if key not in records:
            errors.append(f"required_ids: unaccounted case {key}")
    for key, record in records.items():
        prefix = f"records.{key}"
        source_ids = strings(record.get("source_ids"), prefix + ".source_ids")
        if not source_ids:
            errors.append(prefix + ".source_ids: source provenance is required")
        for source_id in source_ids:
            if source_id not in sources:
                errors.append(prefix + f": unknown source {source_id}")
        proof_state = record.get("proof_state")
        member(proof_state, PROOF_STATES, prefix + ".proof_state")
        if record.get("statement_ref") is not None or proof_state != "not_recovered":
            text(record.get("statement_ref"), prefix + ".statement_ref")
        text(record.get("domain"), prefix + ".domain")
        strings(record.get("hypotheses"), prefix + ".hypotheses")
        proof_refs = strings(record.get("proof_refs"), prefix + ".proof_refs")
        obligations = strings(record.get("open_obligations"), prefix + ".open_obligations")
        if proof_state in ("complete", "partial"):
            if not proof_refs:
                errors.append(prefix + ": recovered proof needs a proof reference")
            if not any(sources.get(s, {}).get("availability") == "available" for s in source_ids):
                errors.append(prefix + ": a recovered proof needs an available source")
        if proof_state in ("not_recovered", "not_applicable") and proof_refs:
            errors.append(prefix + ": proof references conflict with proof_state")
        if proof_state in ("partial", "not_recovered") and not obligations:
            errors.append(prefix + ": identify the missing proof or unresolved inference")

    relations = objects(data.get("relations"), "relations")
    for key, relation in relations.items():
        prefix = f"relations.{key}"
        kind = relation.get("kind")
        member(kind, RELATIONS, prefix + ".kind")
        premises = strings(relation.get("premises"), prefix + ".premises")
        conclusion = relation.get("conclusion")
        if not premises:
            errors.append(prefix + ": a relation needs a premise")
        if not isinstance(conclusion, str) or conclusion not in records:
            errors.append(prefix + ": unknown conclusion")
        for premise in premises:
            if premise not in records:
                errors.append(prefix + f": unknown premise {premise}")
            if premise == conclusion:
                errors.append(prefix + ": a relation cannot use its own conclusion")
        conditions = strings(relation.get("extra_hypotheses"), prefix + ".extra_hypotheses")
        if kind == "implication" and conditions:
            errors.append(prefix + ": extra hypotheses require conditional_implication")
        if kind == "conditional_implication" and not conditions:
            errors.append(prefix + ": conditional implication needs explicit extra hypotheses")
        state = relation.get("state")
        if member(state, {"established", "proposed"}, prefix + ".state") and state == "established":
            text(relation.get("justification_ref"), prefix + ".justification_ref")

    placements = objects(data.get("placements"), "placements")
    for key in records:
        if key not in placements:
            errors.append(f"placements: record {key} has no reading position")
    parents = {}
    for key, placement in placements.items():
        prefix = f"placements.{key}"
        if key not in records:
            errors.append(prefix + ": unknown record")
        parent, relation_id = placement.get("parent"), placement.get("relation")
        if "parent" not in placement or "relation" not in placement:
            errors.append(prefix + ": parent and relation must be explicit, using null for a root")
        if parent is None:
            if relation_id is not None:
                errors.append(prefix + ": a root has no parent relation")
            continue
        if not isinstance(parent, str) or parent not in records:
            errors.append(prefix + ": unknown parent")
            continue
        parents[key] = parent
        relation = relations.get(relation_id) if isinstance(relation_id, str) else None
        if not relation:
            errors.append(prefix + ": nesting requires a recorded relation")
            continue
        relation_kind = relation.get("kind")
        if not isinstance(relation_kind, str) or relation_kind not in CONSEQUENCE_RELATIONS | {"navigation"}:
            errors.append(prefix + ": dependency or analogy is not a consequence relation")
        if relation.get("state") != "established" and relation.get("kind") != "navigation":
            errors.append(prefix + ": a proposed implication cannot justify consequence nesting")
        relation_premises = relation.get("premises")
        if (relation.get("conclusion") != key or not isinstance(relation_premises, list)
                or parent not in relation_premises):
            errors.append(prefix + ": relation direction does not justify this parent")
    for start in parents:
        seen, node = set(), start
        while node in parents:
            if node in seen:
                errors.append(f"placements: cyclic reading hierarchy through {node}")
                break
            seen.add(node)
            node = parents[node]

    steps = objects(data.get("steps"), "steps")
    for key, step in steps.items():
        prefix = f"steps.{key}"
        target = step.get("target")
        if not isinstance(target, str) or target not in records:
            errors.append(prefix + ": unknown target")
        for input_id in strings(step.get("inputs"), prefix + ".inputs"):
            if input_id not in records:
                errors.append(prefix + f": unknown input {input_id}")
            if input_id == target:
                errors.append(prefix + ": target cannot be its own established input")
        for field in ("problem_ref", "output_ref", "mechanism", "obstruction", "acceptance"):
            text(step.get(field), prefix + "." + field)
    return {
        "valid": not errors, "errors": sorted(set(errors)), "warnings": warnings,
        "checks": {"required_cases": len(required), "records": len(records),
                   "relations": len(relations), "steps": len(steps)},
        "meaning": "Structural consistency only; inspect source coverage and mathematical evidence separately.",
    }


def load_outline(path):
    path = Path(path)
    if path.stat().st_size > 10 * 1024 * 1024:
        raise ValueError("outline exceeds 10 MiB")

    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    def finite(value):
        raise ValueError(f"non-finite JSON value: {value}")

    def finite_float(value):
        number = float(value)
        if not math.isfinite(number):
            finite(value)
        return number

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique,
                      parse_constant=finite, parse_float=finite_float)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("outline", type=Path)
    args = parser.parse_args(argv)
    try:
        report = audit_outline(load_outline(args.outline))
    except (OSError, ValueError, RecursionError) as error:
        report = {"valid": False, "errors": [str(error)], "warnings": []}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["valid"] else 2


if __name__ == "__main__":
    sys.exit(main())
