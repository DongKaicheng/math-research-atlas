"""Snapshot, cache recovery, mathematical token, and context-budget tests."""

from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.project import ingest, set_context
from mathproj.search import context_packet, rebuild_index, search
from mathproj.store import ProjectError, ProjectStore


SOURCE = r"""\section{Groups and rings}\label{section-groups}
\begin{definition}\label{definition-ring}
A ring is an abelian group with multiplication.
\end{definition}
\begin{lemma}[Compact groups]\label{lemma-upper}
Let $\Gamma$ be a compact group and consider $\Gamma \times \Gamma$.
The identity $x=x$ holds. 古典的拟紧空间.
\end{lemma}
\begin{proof}
Use the ring in \ref{definition-ring}; a spectral sequence converges.
\end{proof}
\begin{lemma}[Lowercase parameter]\label{lemma-lower}
Let $\gamma$ be a parameter. Its identity is $y=y$.
\end{lemma}
\begin{proof}
This follows directly by substitution.
\end{proof}
"""


class SearchCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.store = ProjectStore.create(self.root, "Retrieval tests", "TEST")
        self.source = self.root / "content" / "algebra.tex"
        self.source.write_text(SOURCE, encoding="utf-8")
        set_context(self.store, "rings", "Every ring has a multiplicative identity.", global_scope=True)
        self.snapshot = ingest(self.store)["snapshot"]
        self.refresh_ids()

    def refresh_ids(self):
        self.state = self.store.state()
        self.ids = {item["label"]: item_id for item_id, item in self.state["items"].items()}

    def upper(self):
        return self.ids["lemma-upper"]

    def test_terms_and_source_evidence(self):
        result = search(self.store, "spectral sequence")
        self.assertEqual(1, result["total"])
        hit = result["results"][0]
        proof = self.state["proofs"][self.state["items"][self.upper()]["proof_ids"][0]]
        self.assertEqual(self.upper(), hit["id"])
        self.assertEqual("proof", hit["part"])
        self.assertEqual(proof["revision"], hit["revision"])
        self.assertEqual(self.state["items"][self.upper()]["revision"], hit["item_revision"])
        self.assertEqual(self.snapshot, hit["snapshot"])
        self.assertEqual(proof["source"], hit["source"])
        self.assertIn("spectral sequence", hit["excerpt"])
        self.assertIn(r"\Gamma", hit["statement_excerpt"])
        self.assertFalse(result["index"]["authoritative"])

    def test_tex_command_case_is_preserved(self):
        upper = search(self.store, r"\Gamma")
        lower = search(self.store, r"\gamma")
        self.assertEqual({self.ids["lemma-upper"]}, {hit["id"] for hit in upper["results"]})
        self.assertEqual({self.ids["lemma-lower"]}, {hit["id"] for hit in lower["results"]})
        ordinary = search(self.store, "gamma")
        self.assertEqual({self.ids["lemma-upper"], self.ids["lemma-lower"]}, {hit["id"] for hit in ordinary["results"]})

    def test_tex_command_and_plain_terms_are_combined(self):
        self.assertEqual(1, search(self.store, r"\Gamma compact")["total"])
        self.assertEqual(0, search(self.store, r"\gamma compact")["total"])

    def test_fts_operators_are_plain_terms(self):
        for query in ["ring OR spectral", "ring NOT nonexistent", 'ring"; DROP TABLE documents; --', "body:ring NEAR(spectral)"]:
            with self.subTest(query=query):
                self.assertEqual(0, search(self.store, query)["total"])
        self.assertGreater(search(self.store, "ring")["total"], 0)

    def test_exact_formula_and_punctuation(self):
        result = search(self.store, r"$\Gamma \times \Gamma$", exact=True)
        self.assertEqual("exact", result["mode"])
        self.assertEqual([self.upper()], [hit["id"] for hit in result["results"]])
        self.assertEqual(0, search(self.store, r"$\gamma \times \gamma$", exact=True)["total"])
        self.assertEqual(0, search(self.store, "=")["total"])
        self.assertEqual("no_searchable_terms", search(self.store, "=")["diagnostics"][0]["code"])
        self.assertGreater(search(self.store, "=", exact=True)["total"], 0)

    def test_unicode_literal_text(self):
        result = search(self.store, "拟紧空间", exact=True)
        self.assertEqual(1, result["total"])
        self.assertIn("拟紧空间", result["results"][0]["excerpt"])

    def test_exact_excerpt_focus_respects_case(self):
        body = "UPPERCASE " + "padding " * 150 + "uppercase is the exact match."
        self.source.write_text(r"\begin{lemma}\label{case}" + body + r"\end{lemma}")
        ingest(self.store)
        result = search(self.store, "uppercase", exact=True)
        self.assertEqual(1, result["total"])
        self.assertIn("uppercase is the exact match.", result["results"][0]["excerpt"])
        self.assertGreater(result["results"][0]["excerpt_range"]["start_char"], 0)

    def test_kind_and_path_filters(self):
        self.assertGreater(search(self.store, "ring", kind="definition")["total"], 0)
        self.assertTrue(all(hit["kind"] == "definition" for hit in search(self.store, "ring", kind="definition")["results"]))
        self.assertGreater(search(self.store, "ring", path="content/*.tex")["total"], 0)
        self.assertEqual(0, search(self.store, "ring", path="Content/*.tex")["total"])
        self.assertEqual(0, search(self.store, "ring", path="elsewhere/*")["total"])

    def test_permanent_item_and_proof_id_lookup(self):
        item_hit = search(self.store, self.upper())
        self.assertEqual("id", item_hit["mode"])
        self.assertEqual("statement", item_hit["results"][0]["part"])
        self.assertEqual(self.upper(), item_hit["results"][0]["id"])
        proof_id = self.state["items"][self.upper()]["proof_ids"][0]
        proof_hit = search(self.store, proof_id)
        self.assertEqual("id", proof_hit["mode"])
        self.assertEqual(proof_id, proof_hit["results"][0]["evidence_id"])
        self.assertEqual(0, search(self.store, self.upper(), kind="definition")["total"])

    def test_context_hits_are_explicit_bindings_with_item_spans(self):
        result = search(self.store, "multiplicative identity")
        self.assertEqual(len(self.ids), result["total"])
        self.assertTrue(all(hit["part"] == "context" for hit in result["results"]))
        for hit in result["results"]:
            self.assertIsNone(hit["source"])
            self.assertEqual("content/algebra.tex", hit["item_source"]["path"])
            self.assertEqual("explicit_context_binding", hit["source_kind"])
            self.assertEqual("rings", hit["context"]["key"])

    def test_deterministic_ranking_and_limits(self):
        first = search(self.store, "ring", limit=2)
        second = search(self.store, "ring", limit=2)
        self.assertEqual(first["results"], second["results"])
        self.assertEqual(2, len(first["results"]))
        self.assertTrue(first["truncated"])
        self.assertTrue(first["index"]["rebuilt"])
        self.assertFalse(second["index"]["rebuilt"])

    def test_current_and_historical_snapshots_do_not_mix(self):
        old = search(self.store, "spectral")
        self.source.write_text(SOURCE.replace("spectral sequence", "derived functor"), encoding="utf-8")
        new_snapshot = ingest(self.store)["snapshot"]
        self.assertNotEqual(self.snapshot, new_snapshot)
        self.assertEqual(0, search(self.store, "spectral")["total"])
        historical = search(self.store, "spectral", snapshot=self.snapshot)
        self.assertEqual(1, historical["total"])
        self.assertFalse(historical["current_snapshot"])
        self.assertEqual(old["results"], historical["results"])
        current = search(self.store, "derived functor")
        self.assertEqual(new_snapshot, current["snapshot"])
        self.assertNotEqual(old["index"]["path"], current["index"]["path"])

    def test_delete_and_rebuild_cache_preserves_authoritative_records(self):
        index = rebuild_index(self.store)
        events = self.store.events.read_bytes()
        snapshot_bytes = (self.store.meta / "snapshots" / (self.snapshot + ".json")).read_bytes()
        path = self.root / index["path"]
        path.unlink()
        result = search(self.store, "spectral")
        self.assertTrue(result["index"]["rebuilt"])
        self.assertEqual(1, result["total"])
        self.assertEqual(events, self.store.events.read_bytes())
        self.assertEqual(snapshot_bytes, (self.store.meta / "snapshots" / (self.snapshot + ".json")).read_bytes())

    def test_schema_version_mismatch_rebuilds(self):
        index = rebuild_index(self.store)
        with sqlite3.connect(self.root / index["path"]) as connection:
            connection.execute("PRAGMA user_version=999")
        result = search(self.store, "spectral")
        self.assertTrue(result["index"]["rebuilt"])
        self.assertEqual(1, result["total"])

    def test_changed_cached_text_is_not_authoritative(self):
        index = rebuild_index(self.store)
        with sqlite3.connect(self.root / index["path"]) as connection:
            connection.execute("UPDATE documents SET body='FORGED CONTENT' WHERE part='proof'")
        result = search(self.store, "spectral")
        self.assertTrue(result["index"]["rebuilt"])
        self.assertIn("spectral", result["results"][0]["excerpt"])
        self.assertEqual(0, search(self.store, "FORGED")["total"])

    def test_missing_fts_postings_are_detected_and_rebuilt(self):
        index = rebuild_index(self.store)
        with sqlite3.connect(self.root / index["path"]) as connection:
            connection.execute("INSERT INTO search_fts(search_fts) VALUES ('delete-all')")
        result = search(self.store, "spectral")
        self.assertTrue(result["index"]["rebuilt"])
        self.assertEqual(1, result["total"])

    def test_corrupt_database_is_recoverable(self):
        index = rebuild_index(self.store)
        (self.root / index["path"]).write_bytes(b"This is not a SQLite database")
        result = search(self.store, "spectral")
        self.assertTrue(result["index"]["rebuilt"])
        self.assertEqual(1, result["total"])

    def test_corrupt_snapshot_cannot_be_replaced_by_cached_evidence(self):
        rebuild_index(self.store)
        path = self.store.meta / "snapshots" / (self.snapshot + ".json")
        value = json.loads(path.read_text())
        value["items"][self.upper()]["statement"] = "FORGED SNAPSHOT"
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(ProjectError, "integrity"):
            search(self.store, "spectral")

    def test_unregistered_and_invalid_snapshots_are_rejected(self):
        value = self.store.snapshot(self.snapshot)
        value["git_commit"] = "unrecorded"
        unregistered = self.store.put_snapshot(value)
        with self.assertRaisesRegex(ProjectError, "recorded project history"):
            search(self.store, "ring", snapshot=unregistered)
        with self.assertRaises(ProjectError):
            search(self.store, "ring", snapshot="../outside")

    def test_index_symlinks_are_refused(self):
        index = rebuild_index(self.store)
        path = self.root / index["path"]
        path.unlink()
        target = self.root / "unrelated.txt"
        target.write_text("KEEP")
        path.symlink_to(target)
        with self.assertRaisesRegex(ProjectError, "symlink"):
            search(self.store, "ring")
        self.assertEqual("KEEP", target.read_text())

    def test_concurrent_readers_and_atomic_rebuilds(self):
        rebuild_index(self.store)

        def work(index):
            if index % 3 == 0:
                rebuild_index(self.store, force=True)
            result = search(self.store, "spectral")
            return result["total"], result["results"][0]["revision"]

        with ThreadPoolExecutor(max_workers=4) as workers:
            results = list(workers.map(work, range(16)))
        self.assertEqual(1, len(set(results)))
        self.assertEqual(1, results[0][0])
        self.assertEqual([], list((self.store.meta / "search").glob(".building-search-*")))

    def test_search_argument_validation(self):
        for query, kwargs in [("", {}), ("x\x00", {}), ("ring", {"limit": 0}),
                              ("ring", {"limit": True}), ("ring", {"path": ""})]:
            with self.subTest(query=query, kwargs=kwargs), self.assertRaises(ProjectError):
                search(self.store, query, **kwargs)

    def test_packet_contains_requested_proof_direct_declarations_and_context(self):
        packet = context_packet(self.store, [self.upper()])
        self.assertEqual(self.snapshot, packet["snapshot"])
        self.assertEqual([self.upper(), self.ids["definition-ring"]], [item["id"] for item in packet["items"]])
        self.assertEqual("requested", packet["items"][0]["selection"])
        self.assertEqual("direct_dependency", packet["items"][1]["selection"])
        self.assertEqual(1, len(packet["items"][0]["proofs"]))
        self.assertEqual(1, len(packet["contexts"]))
        self.assertEqual(set(item["id"] for item in packet["items"]), set(packet["contexts"][0]["applies_to"]))
        self.assertEqual("candidate_reference", packet["dependencies"][0]["relation"])
        self.assertTrue(packet["complete_within_scope"])
        self.assertFalse(packet["truncated"])

    def test_packet_stacks_prefix_and_permanent_id_precedence(self):
        packet = context_packet(self.store, ["algebra-lemma-upper"])
        self.assertEqual(self.upper(), packet["items"][0]["id"])
        (self.root / "content" / "conflict.tex").write_text(
            r"\begin{lemma}\label{" + self.upper() + r"}Unrelated item.\end{lemma}")
        ingest(self.store)
        packet = context_packet(self.store, [self.upper()])
        self.assertEqual(self.upper(), packet["items"][0]["id"])

    def test_packet_character_budget_marks_every_truncated_extent(self):
        packet = context_packet(self.store, [self.upper()], max_chars=15)
        pieces = [item["statement"] for item in packet["items"]]
        pieces += [proof for item in packet["items"] for proof in item["proofs"]]
        pieces += packet["contexts"]
        self.assertEqual(15, sum(len(piece["text"]) for piece in pieces))
        self.assertEqual(15, packet["counts"]["included_chars"])
        self.assertTrue(packet["truncated"])
        self.assertFalse(packet["complete"])
        self.assertFalse(packet["complete_within_scope"])
        self.assertFalse(packet["items"][0]["statement"]["complete"])
        for piece in pieces:
            if not piece["complete"]:
                self.assertTrue(any(o.get("evidence_id") == piece["id"] and o["reason"] == "max_chars" for o in packet["omissions"]))

    def test_packet_item_budget_and_zero_budgets_are_explicit(self):
        packet = context_packet(self.store, [self.upper()], max_items=1)
        self.assertEqual(2, packet["counts"]["candidate_items"])
        self.assertEqual(1, packet["counts"]["included_items"])
        self.assertEqual(1, packet["counts"]["omitted_items"])
        self.assertFalse(packet["dependencies"][0]["included"])
        self.assertTrue(any(o["reason"] == "max_items" for o in packet["omissions"]))
        empty = context_packet(self.store, [self.upper()], max_items=0, max_chars=0)
        self.assertEqual([], empty["items"])
        self.assertTrue(empty["truncated"])
        self.assertFalse(empty["complete"])

    def test_packet_uses_snapshot_context_not_live_unimported_changes(self):
        set_context(self.store, "rings", "An unimported convention about ultrafilters.", global_scope=True)
        packet = context_packet(self.store, [self.upper()])
        self.assertIn("multiplicative identity", packet["contexts"][0]["text"])
        self.assertEqual(0, search(self.store, "ultrafilters")["total"])

    def test_packet_explicit_proof_selection_reports_other_alternatives(self):
        self.source.write_text(SOURCE.replace("\\begin{lemma}[Lowercase", "\\begin{proof}[Alternative proof of \\ref{lemma-upper}]A different proof.\\end{proof}\n\\begin{lemma}[Lowercase"))
        ingest(self.store)
        self.refresh_ids()
        proofs = self.state["items"][self.upper()]["proof_ids"]
        self.assertEqual(2, len(proofs))
        packet = context_packet(self.store, [proofs[1]])
        self.assertEqual([proofs[1]], [proof["id"] for proof in packet["items"][0]["proofs"]])
        self.assertTrue(any(o["reason"] == "alternative_proofs_not_requested" for o in packet["omissions"]))
        self.assertTrue(packet["complete_within_scope"])
        self.assertFalse(packet["complete"])

    def test_packet_unresolved_unknown_and_ambiguous_references(self):
        self.source.write_text(SOURCE.replace("a spectral sequence", "\\ref{missing} and a spectral sequence"))
        ingest(self.store)
        packet = context_packet(self.store, [self.upper(), "unknown-item"])
        reasons = {omission["reason"] for omission in packet["omissions"]}
        self.assertIn("unresolved_reference", reasons)
        self.assertIn("unknown_reference", reasons)
        self.assertFalse(packet["complete_within_scope"])
        (self.root / "content" / "other.tex").write_text(r"\begin{lemma}\label{lemma-upper}Different.\end{lemma}")
        ingest(self.store)
        packet = context_packet(self.store, ["lemma-upper"])
        self.assertEqual("ambiguous_reference", packet["omissions"][0]["reason"])
        self.assertEqual([], packet["items"])

    def test_packet_does_not_claim_transitive_dependency_closure(self):
        text = SOURCE + r"""\begin{lemma}\label{third}Third.\end{lemma}
\begin{proof}Apply \ref{lemma-upper}.\end{proof}
"""
        self.source.write_text(text)
        ingest(self.store)
        self.refresh_ids()
        packet = context_packet(self.store, [self.ids["third"]])
        self.assertEqual(1, packet["scope"]["dependency_depth"])
        self.assertEqual({self.ids["third"], self.upper()}, {item["id"] for item in packet["items"]})
        reasons = {o["reason"] for o in packet["omissions"]}
        self.assertIn("dependency_not_expanded", reasons)
        self.assertIn("dependency_proofs_not_requested", reasons)
        self.assertTrue(packet["complete_within_scope"])
        self.assertFalse(packet["complete"])

    def test_context_argument_validation(self):
        for refs, kwargs in [([], {}), ([42], {}), ([self.upper()], {"max_chars": -1}),
                             ([self.upper()], {"max_items": True})]:
            with self.subTest(refs=refs, kwargs=kwargs), self.assertRaises(ProjectError):
                context_packet(self.store, refs, **kwargs)


if __name__ == "__main__":
    unittest.main()
