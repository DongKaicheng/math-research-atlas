"""Real source-edit, exact-baseline, and interrupted-journal regressions."""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.changes import (apply_proposal, create_proposal, inspect_proposal,
                             pending_change, recover_changes, _journal_write)
from mathproj.project import ingest, resolve_item
from mathproj.store import ProjectError, ProjectStore, atomic_json
from mathproj.workflow import freshness


BASE = r"""\begin{lemma}\label{identity}For an integer $n$, $n+0=n$.\end{lemma}
\begin{proof}Use the identity law.\end{proof}
"""
EDIT = BASE.replace("Use the identity law.", "The additive identity law applies to the displayed integer.")


class ChangeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Source changes", "NA")
        self.path = self.root / "content" / "main.tex"
        self.path.write_text(BASE)
        ingest(self.store)

    def tearDown(self):
        self.temp.cleanup()

    def payload(self, text=EDIT):
        return {"title": "Clarify the identity-law proof", "author": "author-agent", "rationale": "Identify the algebraic law explicitly.",
                "base_snapshot": self.store.state()["current_snapshot"], "targets": ["identity"],
                "edits": [{"path": "content/main.tex", "before_sha256": hashlib.sha256(self.path.read_bytes()).hexdigest(), "content": text}]}

    def prepare(self, text=EDIT):
        return create_proposal(self.store, self.payload(text))["proposal"]

    def journal(self, proposal, *, phase="files_written"):
        journal = {"schema_version": 1, "proposal_id": proposal["id"], "phase": phase,
                   "files": [{"path": "content/main.tex", "before_text": BASE,
                              "before_sha256": proposal["edits"][0]["before_sha256"],
                              "after_sha256": proposal["edits"][0]["after_sha256"]}]}
        location = self.store.meta / "changes" / "pending.json"
        _journal_write(location, journal)
        return location

    def test_prepare_is_reviewable_and_does_not_mutate_sources(self):
        before = self.path.read_bytes()
        proposal = self.prepare()
        self.assertEqual(self.path.read_bytes(), before)
        self.assertTrue(proposal["analysis"]["structurally_valid"])
        self.assertIn("proof_text_changed", [e["effect"] for e in proposal["analysis"]["effects"]])
        self.assertNotIn("statement_text_changed", [e["effect"] for e in proposal["analysis"]["effects"]])
        self.assertIn("+The", proposal["edits"][0]["diff"].replace("+\\begin{proof}", "+"))

    def test_apply_imports_and_keeps_stable_item_identity(self):
        iid = resolve_item(self.store.state(), "identity")
        proposal = self.prepare()
        report = apply_proposal(self.store, proposal["id"])
        self.assertEqual(self.path.read_text(), EDIT)
        self.assertEqual(resolve_item(self.store.state(), "identity"), iid)
        self.assertEqual(report["import"]["changed"], [iid])
        self.assertIsNone(pending_change(self.store))
        self.assertEqual(inspect_proposal(self.store, proposal["id"])["status"], "applied")
        self.assertTrue(freshness(self.store)["fresh"])

    def test_second_apply_is_rejected_without_extra_changes(self):
        proposal = self.prepare()
        apply_proposal(self.store, proposal["id"])
        events = len(self.store.history())
        with self.assertRaisesRegex(ProjectError, "prepared"):
            apply_proposal(self.store, proposal["id"])
        self.assertEqual(len(self.store.history()), events)

    def test_rejects_stale_hash_before_creating_record(self):
        payload = self.payload()
        payload["edits"][0]["before_sha256"] = "0"*64
        with self.assertRaisesRegex(ProjectError, "before_sha256"):
            create_proposal(self.store, payload)
        self.assertEqual(self.store.state()["proposals"], {})

    def test_rejects_stale_live_source_without_overwrite(self):
        proposal = self.prepare()
        self.path.write_text(BASE+"% Unrelated author change\n")
        with self.assertRaisesRegex(ProjectError, "Import current"):
            apply_proposal(self.store, proposal["id"])
        self.assertIn("Unrelated", self.path.read_text())

    def test_rejects_changed_snapshot_even_when_target_file_unchanged(self):
        proposal = self.prepare()
        extra = self.root / "content" / "extra.tex"
        extra.write_text(r"\begin{definition}\label{new}A separate object.\end{definition}")
        ingest(self.store)
        with self.assertRaisesRegex(ProjectError, "baseline snapshot"):
            apply_proposal(self.store, proposal["id"])

    def test_parse_error_is_visible_but_cannot_be_applied(self):
        proposal = self.prepare(r"\begin{lemma}\label{broken}Missing end.")
        self.assertFalse(proposal["analysis"]["structurally_valid"])
        with self.assertRaisesRegex(ProjectError, "structural errors"):
            apply_proposal(self.store, proposal["id"])
        self.assertEqual(self.path.read_text(), BASE)

    def test_proposal_cannot_escape_source_roots_or_touch_metadata(self):
        for path in ("../outside.tex", "mpm/evil.tex", "/tmp/evil.tex", "content/evil.py"):
            with self.subTest(path=path):
                payload = self.payload()
                payload["edits"][0].update(path=path, before_sha256=None)
                with self.assertRaises(ProjectError):
                    create_proposal(self.store, payload)

    def test_symlink_path_is_rejected(self):
        (self.root / "content" / "alias.tex").symlink_to(self.path)
        # Remove it from source discovery by using an explicit entrypoint.
        manifest = self.store.manifest()
        manifest["entrypoints"] = ["content/main.tex"]
        atomic_json(self.store.manifest_path, manifest)
        ingest(self.store)
        payload = self.payload()
        payload["edits"][0]["path"] = "content/alias.tex"
        with self.assertRaisesRegex(ProjectError, "symlink"):
            create_proposal(self.store, payload)

    def test_new_file_uses_null_before_hash_and_becomes_imported(self):
        payload = self.payload()
        payload["edits"].append({"path": "content/new.tex", "before_sha256": None,
                                 "content": r"\begin{definition}\label{new-definition}A named element.\end{definition}"})
        proposal = create_proposal(self.store, payload)["proposal"]
        result = apply_proposal(self.store, proposal["id"])
        self.assertEqual(len(result["import"]["added"]), 1)
        self.assertTrue((self.root / "content" / "new.tex").is_file())

    def test_unreachable_new_file_is_reported_for_entrypoint_project(self):
        manifest = self.store.manifest()
        manifest["entrypoints"] = ["content/main.tex"]
        atomic_json(self.store.manifest_path, manifest)
        ingest(self.store)
        payload = self.payload()
        payload["edits"].append({"path": "content/unreferenced.tex", "before_sha256": None,
                                 "content": r"\begin{lemma}\label{x}Unused.\end{lemma}"})
        proposal = create_proposal(self.store, payload)["proposal"]
        self.assertFalse(proposal["analysis"]["structurally_valid"])
        self.assertIn("unreachable_proposed_source", [d["code"] for d in proposal["analysis"]["diagnostics"]])

    def test_uncommitted_crash_restores_old_source_and_keeps_proposal(self):
        proposal = self.prepare()
        self.journal(proposal)
        self.path.write_text(EDIT)
        self.assertFalse(freshness(self.store)["fresh"])
        with self.assertRaisesRegex(ProjectError, "pending"):
            ingest(self.store)
        result = recover_changes(self.store)
        self.assertFalse(result["committed"])
        self.assertEqual(self.path.read_text(), BASE)
        self.assertEqual(inspect_proposal(self.store, proposal["id"])["status"], "prepared")

    def test_committed_crash_finalizes_without_undoing_source(self):
        proposal = self.prepare()
        self.journal(proposal)
        self.path.write_text(EDIT)
        self.store.transact("simulate_committed_source_change", lambda state: state["proposals"][proposal["id"]].update(status="applied"))
        result = recover_changes(self.store)
        self.assertTrue(result["committed"])
        self.assertEqual(self.path.read_text(), EDIT)

    def test_recovery_preserves_unrelated_edits_for_explicit_resolution(self):
        proposal = self.prepare()
        journal = self.journal(proposal)
        self.path.write_text("A different author wrote this.\n")
        with self.assertRaisesRegex(ProjectError, "unrelated edit"):
            recover_changes(self.store)
        self.assertTrue(journal.exists())
        self.assertIn("different author", self.path.read_text())

    def test_partial_multifile_failure_rolls_back_without_ledger_commit(self):
        payload = self.payload()
        payload["edits"].append({"path": "content/new.tex", "before_sha256": None,
                                 "content": r"\begin{lemma}\label{new}An additional claim.\end{lemma}"})
        proposal = create_proposal(self.store, payload)["proposal"]
        from mathproj import changes
        original = changes._atomic_bytes
        def fail_new(path, value):
            if path.name == "new.tex":
                raise OSError("Injected second-file write failure")
            return original(path, value)
        with patch("mathproj.changes._atomic_bytes", side_effect=fail_new):
            with self.assertRaisesRegex(OSError, "second-file"):
                apply_proposal(self.store, proposal["id"])
        self.assertEqual(self.path.read_text(), BASE)
        self.assertFalse((self.root / "content" / "new.tex").exists())
        self.assertIsNone(pending_change(self.store))
        self.assertEqual(inspect_proposal(self.store, proposal["id"])["status"], "prepared")


if __name__ == "__main__":
    unittest.main()
