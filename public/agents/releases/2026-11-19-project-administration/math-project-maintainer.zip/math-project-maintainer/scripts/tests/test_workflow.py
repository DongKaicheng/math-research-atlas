"""Integration tests for review provenance, assumption changes and alternatives."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.project import ingest, resolve_item, set_context, set_foundation
from mathproj.store import ProjectError, ProjectStore
from mathproj.workflow import (application_templates, freshness, prepare_review,
                              record_applications, record_review, resolve_issue,
                              support_report)


SOURCE = r"""\documentclass{article}
\newtheorem{lemma}{Lemma}
\newtheorem{definition}{Definition}
\begin{document}
\begin{lemma}\label{lemma-base}
For every integer $n$, $n+0=n$.
\end{lemma}
\begin{proof}
This is the identity property of zero.
\end{proof}
\begin{lemma}\label{lemma-dependent}
For every integer $n$, $(n+0)+0=n$.
\end{lemma}
\begin{proof}
Apply Lemma~\ref{lemma-base} twice.
\end{proof}
\begin{definition}\label{definition-even}
An integer is even if it is twice an integer.
\end{definition}
\end{document}
"""


class WorkflowCase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Review regression", "NA")
        self.source = self.root / "content" / "algebra.tex"
        self.source.write_text(SOURCE)
        ingest(self.store)
        self.state = self.store.state()
        self.base = resolve_item(self.state, "lemma-base")
        self.child = resolve_item(self.state, "lemma-dependent")
        self.definition = resolve_item(self.state, "definition-even")

    def tearDown(self):
        self.temp.cleanup()

    def accept(self, item, proof=None, independent=True):
        packet = prepare_review(self.store, item, proof)
        report = packet["template"]
        report["reviewer"] = {"id": "reviewer-b", "kind": "agent", "independent": independent,
                              "author_of_change": not independent}
        report["verdict"] = "accept"
        report["summary"] = "The displayed elementary identity follows by the stated additive identity law."
        for check in report["checks"]:
            check.update(status="pass", reason="Checked the displayed integer domain and each identity substitution; no extension of hypotheses is used.")
        return record_review(self.store, report)

    def applications(self, proof=None, relation="uses"):
        pid = proof or self.child+":proof:1"
        rows = application_templates(self.store, pid)["records"]
        for row in rows:
            row.update(relation=relation, substitution="Substitute n and then n+0 for the integer variable.",
                       hypotheses=[{"required": "The substituted term is an integer", "discharge": "Integers are closed under addition and 0 is an integer."}],
                       conclusion="Both occurrences of adding zero can be removed.",
                       justification="The domains and operations are exactly those of the source lemma.",
                       reviewer="reviewer-b")
        return record_applications(self.store, rows)

    def test_support_needs_reviewed_applications_and_grounded_dependencies(self):
        self.assertEqual(support_report(self.store)["grounded"], [])
        with self.assertRaisesRegex(ProjectError, "applications"):
            self.accept(self.child)
        self.applications()
        self.accept(self.child)
        self.assertNotIn(self.child, support_report(self.store)["grounded"])
        self.accept(self.base)
        report = support_report(self.store)
        self.assertIn(self.child, report["grounded"])
        self.assertLess(report["order"].index(self.base), report["order"].index(self.child))

    def test_author_review_is_recorded_but_does_not_meet_independence_policy(self):
        self.accept(self.base, independent=False)
        report = support_report(self.store)
        self.assertNotIn(self.base, report["grounded"])
        self.assertEqual(report["eligibility"][self.base+":proof:1"]["reasons"][0]["kind"], "current_independent_review_missing")

    def test_pending_source_edit_blocks_submission_even_before_ingest(self):
        packet = prepare_review(self.store, self.base)
        self.source.write_text(SOURCE.replace("every integer", "every real number", 1))
        self.assertFalse(freshness(self.store)["fresh"])
        with self.assertRaisesRegex(ProjectError, "Import current"):
            record_review(self.store, packet["template"])

    def test_new_source_file_is_detected_by_freshness(self):
        (self.root / "content" / "extra.tex").write_text(r"\begin{lemma}\label{new}New text.\end{lemma}")
        f = freshness(self.store)
        self.assertFalse(f["fresh"])
        self.assertIn("source_added", [r["kind"] for r in f["reasons"]])

    def test_changed_hypothesis_invalidates_applications_and_review(self):
        self.accept(self.base)
        self.applications()
        self.accept(self.child)
        self.source.write_text(SOURCE.replace("For every integer $n$, $n+0=n$.", "For every positive integer $n$, $n+0=n$."))
        report = ingest(self.store)
        self.assertIn(self.child, report["impact"]["affected"])
        self.assertIn("application_missing_or_stale", [x["kind"] for x in prepare_review(self.store, self.child)["obstacles"]])
        self.assertNotIn(self.child, support_report(self.store)["grounded"])
        tasks = self.store.state()["tasks"]
        self.assertTrue(any(self.child in t["target_ids"] for t in tasks.values()))

    def test_proof_edit_does_not_change_application_of_unchanged_statement(self):
        self.accept(self.base)
        self.applications()
        self.accept(self.child)
        child_binding = prepare_review(self.store, self.child)["template"]["binding"]
        self.source.write_text(SOURCE.replace("This is the identity property of zero.", "Use the additive monoid identity axiom for zero."))
        ingest(self.store)
        self.assertEqual(child_binding, prepare_review(self.store, self.child)["template"]["binding"])
        self.assertNotIn(self.child, support_report(self.store)["grounded"])
        self.accept(self.base)
        self.assertIn(self.child, support_report(self.store)["grounded"])

    def test_alternative_proof_avoids_bad_other_alternative(self):
        self.accept(self.base)
        self.applications()
        self.accept(self.child)
        alternative = r"\begin{proof}The identity axiom gives the conclusion directly.\end{proof}"
        self.source.write_text(SOURCE.replace("This is the identity property of zero.\n\\end{proof}", "This is the identity property of zero.\n\\end{proof}\n"+alternative))
        ingest(self.store)
        result = support_report(self.store)
        self.assertIn(self.base, result["grounded"])
        self.assertIn(self.child, result["grounded"])
        self.assertEqual(result["selected_proofs"][self.base], self.base+":proof:1")

    def test_context_change_invalidates_even_unchanged_tex(self):
        self.accept(self.base)
        set_context(self.store, "ambient", "All integer variables are now interpreted in a fixed quotient ring.", global_scope=True)
        self.assertFalse(freshness(self.store)["fresh"])
        report = ingest(self.store)
        self.assertIn(self.base, report["changed"])
        self.assertNotIn(self.base, support_report(self.store)["grounded"])

    def test_declaration_is_not_an_automatic_root(self):
        self.assertNotIn(self.definition, support_report(self.store)["grounded"])
        self.accept(self.definition)
        self.assertIn(self.definition, support_report(self.store)["grounded"])

    def test_explicit_foundation_is_conditional_and_revision_bound(self):
        admission = set_foundation(self.store, self.base, "Explicit ambient additive-identity axiom for this regression.", "axiom")
        self.assertEqual(admission["status"], "explicitly_admitted_input")
        self.assertIn(self.base, support_report(self.store)["admissions"])
        self.source.write_text(SOURCE.replace("every integer", "every positive integer", 1))
        ingest(self.store)
        self.assertNotIn(self.base, support_report(self.store)["grounded"])

    def test_empty_application_hypotheses_are_not_silently_assumed(self):
        row = application_templates(self.store, self.child+":proof:1")["records"][0]
        row.update(substitution="n", conclusion="n+0=n", justification="Use displayed identity", reviewer="r")
        with self.assertRaisesRegex(ProjectError, "hypotheses"):
            record_applications(self.store, [row])

    def test_mention_is_not_a_proof_support_edge(self):
        self.applications(relation="mention")
        self.accept(self.child)
        result = support_report(self.store)
        self.assertIn(self.child, result["grounded"])
        self.assertEqual(result["eligibility"][self.child+":proof:1"]["dependencies"], [])
        # The tool records a reviewer's classification; it cannot establish that
        # this particular classification is mathematically honest.

    def test_reviewer_identity_cannot_be_both_author_and_independent(self):
        report = prepare_review(self.store, self.base)["template"]
        report["reviewer"].update(id="same-person", independent=True, author_of_change=True)
        with self.assertRaisesRegex(ProjectError, "cannot be independent"):
            record_review(self.store, report)

    def test_concrete_error_blocks_acceptance_until_resolved(self):
        packet = prepare_review(self.store, self.base)
        report = packet["template"]
        report["reviewer"].update(id="reviewer-c")
        report["summary"] = "The ambient additive identity must be identified."
        for c in report["checks"]:
            c.update(status="pass", reason="Checked the integer domain.")
        report["checks"][1].update(status="issue", reason="An ambient axiom is not documented.")
        report["findings"] = [{"severity": "error", "scope": "statement", "title": "Ambient axiom missing", "reason": "The source did not state its arithmetic convention.",
                               "required_action": "Record the intended arithmetic convention."}]
        saved = record_review(self.store, report)
        with self.assertRaisesRegex(ProjectError, "open issues"):
            self.accept(self.base)
        resolve_issue(self.store, saved["issues"][0], reason="The notation explicitly denotes the usual integers with their usual addition.", reviewer="reviewer-c", disposition="invalid")
        self.accept(self.base)
        self.assertIn(self.base, support_report(self.store)["grounded"])

    def test_tampered_binding_is_rejected(self):
        report = prepare_review(self.store, self.base)["template"]
        report["binding"]["context_hash"] = "0"*64
        with self.assertRaisesRegex(ProjectError, "stale"):
            record_review(self.store, report)


if __name__ == "__main__":
    unittest.main()
