"""Persistence and concurrency regressions for authoritative project records."""

from __future__ import annotations

import json
import hashlib
import multiprocessing
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.store import ProjectError, ProjectStore, atomic_json, digest, snapshot_source_bytes


def _allocate_records(root, count, ready, results):
    """Run in a separate process so the test exercises the file lock."""
    try:
        store = ProjectStore(root)
        ready.wait(10)
        allocated = []
        for _ in range(count):
            def change(state):
                number = state["next_id"]
                state["next_id"] += 1
                key = f"TASK-{number:06d}"
                state["tasks"][key] = {"id": key, "number": number}
                return number
            allocated.append(store.transact("allocate-test-record", change))
        results.put({"ids": allocated})
    except Exception as exc:  # Send child exceptions back to the test process.
        results.put({"error": f"{type(exc).__name__}: {exc}"})


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Persistence test", "TEST")

    def add_record(self, key="one"):
        return self.store.transact(
            "add-record", lambda state: state["tasks"].update({key: {"id": key}})
        )

    def test_state_cache_is_disposable_and_recover_rebuilds_it(self):
        self.add_record()
        wanted = self.store.state()
        self.store.state_path.write_text('{"fabricated": true}\n')
        self.assertEqual(self.store.state(), wanted)
        self.store.state_path.unlink()
        self.assertEqual(self.store.state(), wanted)
        result = self.store.recover()
        self.assertTrue(result["recovered"])
        self.assertEqual(json.loads(self.store.state_path.read_text()), wanted)

    def test_callback_failure_leaves_authoritative_state_unchanged(self):
        before_events = self.store.events.read_bytes()
        before = self.store.state()

        def fail(state):
            state["next_id"] += 7
            state["tasks"]["uncommitted"] = {"id": "uncommitted"}
            raise ProjectError("Simulated validation failure")

        with self.assertRaisesRegex(ProjectError, "Simulated"):
            self.store.transact("failing-change", fail)
        self.assertEqual(self.store.events.read_bytes(), before_events)
        self.assertEqual(self.store.state(), before)

    def test_committed_event_survives_cache_write_failure(self):
        # The append is durable before updating the disposable JSON cache.
        with patch("mathproj.store.atomic_json", side_effect=OSError("disk failure after event append")):
            with self.assertRaises(OSError):
                self.add_record("durable")
        reopened = ProjectStore(self.root)
        self.assertIn("durable", reopened.state()["tasks"])
        self.assertEqual(reopened.history()[-1]["operation"], "add-record")
        reopened.recover()
        self.assertIn("durable", json.loads(reopened.state_path.read_text())["tasks"])

    def test_incomplete_tail_is_preserved_then_removed_under_recovery(self):
        self.add_record()
        committed = self.store.events.read_bytes()
        interrupted = b'{"schema_version":1,"seq":3,"patch":['
        with self.store.events.open("ab") as out:
            out.write(interrupted)
        with self.assertRaisesRegex(ProjectError, "Incomplete final event"):
            self.store.state()
        result = self.store.recover()
        self.assertEqual(result["events"], 2)
        self.assertEqual(self.store.events.read_bytes(), committed)
        tails = list(self.store.meta.glob("incomplete-tail-*.bin"))
        self.assertEqual(len(tails), 1)
        self.assertEqual(tails[0].read_bytes(), interrupted)
        self.add_record("after-recovery")
        self.assertEqual(len(self.store.history()), 3)
        self.assertIn("after-recovery", self.store.state()["tasks"])

    def test_complete_corrupt_event_is_not_silently_discarded(self):
        corrupt = self.store.events.read_bytes() + b'{"unfinished":}\n'
        self.store.events.write_bytes(corrupt)
        with self.assertRaisesRegex(ProjectError, "Corrupt complete event"):
            self.store.recover()
        self.assertEqual(self.store.events.read_bytes(), corrupt)

    def test_hash_chain_detects_content_sequence_and_link_changes(self):
        self.add_record()
        original = self.store.events.read_bytes()
        lines = [json.loads(line) for line in original.splitlines()]
        for field, value in (("operation", "tampered"), ("seq", 50), ("previous", "f" * 64)):
            with self.subTest(field=field):
                modified = json.loads(json.dumps(lines))
                modified[-1][field] = value
                # Sequence and chain-link checks remain necessary even when a
                # malformed event has a matching hash of its own payload.
                if field != "operation":
                    payload = {k: v for k, v in modified[-1].items() if k != "hash"}
                    modified[-1]["hash"] = digest(payload)
                self.store.events.write_text("".join(json.dumps(row) + "\n" for row in modified))
                with self.assertRaisesRegex(ProjectError, "chain validation failed"):
                    self.store.state()
                self.store.events.write_bytes(original)

    def test_snapshot_content_hash_is_verified_on_read_and_recovery(self):
        value = {"schema_version": 1, "files": [], "items": {}, "proofs": {}}
        sid = self.store.put_snapshot(value)
        self.store.transact("select-snapshot", lambda state: state.update(
            current_snapshot=sid, snapshot_history=[sid]
        ))
        path = self.store.meta / "snapshots" / f"{sid}.json"
        path.write_text('{"schema_version": 1, "tampered": true}\n')
        with self.assertRaisesRegex(ProjectError, "Snapshot integrity failed"):
            self.store.snapshot(sid)
        with self.assertRaisesRegex(ProjectError, "Snapshot integrity failed"):
            self.store.recover()
        with self.assertRaisesRegex(ProjectError, "Snapshot content mismatch"):
            self.store.put_snapshot(value)

    def test_missing_or_empty_event_log_never_falls_back_to_cache(self):
        self.add_record()
        original = self.store.events.read_bytes()
        self.store.events.unlink()
        with self.assertRaisesRegex(ProjectError, "event log is missing"):
            self.store.state()
        self.store.events.write_bytes(b"")
        with self.assertRaisesRegex(ProjectError, "event log is empty"):
            self.store.state()
        self.store.events.write_bytes(original)
        self.assertIn("one", self.store.state()["tasks"])

    def test_snapshot_source_hash_checks_exact_bom_crlf_and_unicode_bytes(self):
        raw = b"\xef\xbb\xbf" + "\\section{中文}\r\n".encode("utf-8")
        source = {"path": "content/main.tex", "text": raw.decode("utf-8"),
                  "sha256": hashlib.sha256(raw).hexdigest()}
        sid = self.store.put_snapshot({"files": [source]})
        self.assertEqual(self.store.snapshot(sid)["files"][0]["text"].encode("utf-8"), raw)
        for corrupt in (source["text"].lstrip("\ufeff"), source["text"].replace("\r\n", "\n")):
            with self.subTest(text=repr(corrupt)):
                value = {"files": [{**source, "text": corrupt}]}
                with self.assertRaisesRegex(ProjectError, "source byte integrity"):
                    self.store.put_snapshot(value)
                # Even an outer content hash cannot legitimize internally
                # contradictory byte evidence supplied by another producer.
                bad_id = digest(value)
                atomic_json(self.store.meta / "snapshots" / f"{bad_id}.json", value)
                with self.assertRaisesRegex(ProjectError, "source byte integrity"):
                    self.store.snapshot(bad_id)

    def test_snapshot_rejects_duplicate_archived_source_paths(self):
        source = {"path": "content/main.tex", "text": "", "sha256": hashlib.sha256(b"").hexdigest()}
        with self.assertRaisesRegex(ProjectError, "unique"):
            self.store.put_snapshot({"files": [source, source]})

    def legacy_bom_snapshot(self):
        text = "\\section{旧档案}\r\n"
        raw = b"\xef\xbb\xbf" + text.encode("utf-8")
        value = {"schema_version": 1, "files": [{"path": "content/main.tex", "text": text,
                  "sha256": hashlib.sha256(raw).hexdigest()}]}
        return value, raw

    def test_legacy_omitted_bom_reads_and_recovers_without_rewriting_archive(self):
        value, raw = self.legacy_bom_snapshot()
        sid = digest(value)
        archive = self.store.meta / "snapshots" / f"{sid}.json"
        atomic_json(archive, value)
        before = archive.read_bytes()
        self.store.transact("legacy-fixture", lambda state: state["snapshot_history"].append(sid))
        self.assertEqual(self.store.snapshot(sid), value)
        self.assertEqual(snapshot_source_bytes(value["files"][0], legacy_omitted_bom=True), raw)
        self.assertTrue(self.store.recover()["recovered"])
        self.assertEqual(archive.read_bytes(), before)

    def test_new_snapshot_writes_cannot_claim_the_legacy_bom_exception(self):
        value, _ = self.legacy_bom_snapshot()
        with self.assertRaisesRegex(ProjectError, "source byte integrity"):
            self.store.put_snapshot(value)

    def test_current_encoding_or_reader_markers_keep_snapshot_reads_strict(self):
        for marker in ("source_encoding", "source_layout", "reader_fingerprint"):
            with self.subTest(marker=marker):
                value, _ = self.legacy_bom_snapshot()
                value[marker] = None
                sid = digest(value)
                atomic_json(self.store.meta / "snapshots" / f"{sid}.json", value)
                with self.assertRaisesRegex(ProjectError, "source byte integrity"):
                    self.store.snapshot(sid)

    def test_legacy_exception_does_not_normalize_newlines_or_repair_other_text(self):
        for replacement in ("\\section{旧档案}\n", "\\section{另一个档案}\r\n"):
            with self.subTest(replacement=replacement):
                value, _ = self.legacy_bom_snapshot()
                value["files"][0]["text"] = replacement
                sid = digest(value)
                atomic_json(self.store.meta / "snapshots" / f"{sid}.json", value)
                with self.assertRaisesRegex(ProjectError, "source byte integrity"):
                    self.store.snapshot(sid)

    def test_snapshot_refuses_symlink_even_when_target_hash_matches(self):
        value = {"files": []}
        sid = digest(value)
        external = self.root / "external-snapshot.json"
        atomic_json(external, value)
        (self.store.meta / "snapshots" / f"{sid}.json").symlink_to(external)
        with self.assertRaisesRegex(ProjectError, "symlink"):
            self.store.snapshot(sid)

    @unittest.skipUnless("fork" in multiprocessing.get_all_start_methods(), "POSIX process-lock test")
    def test_concurrent_writers_allocate_unique_monotone_ids(self):
        ctx = multiprocessing.get_context("fork")
        ready, results = ctx.Event(), ctx.Queue()
        workers = [ctx.Process(target=_allocate_records, args=(str(self.root), 8, ready, results))
                   for _ in range(4)]
        for worker in workers:
            worker.start()
        try:
            ready.set()
            messages = [results.get(timeout=15) for _ in workers]
            for worker in workers:
                worker.join(timeout=5)
                self.assertEqual(worker.exitcode, 0)
            errors = [m["error"] for m in messages if "error" in m]
            self.assertEqual(errors, [])
            allocated = [number for m in messages for number in m["ids"]]
            self.assertEqual(sorted(allocated), list(range(1, 33)))
            state = self.store.state()
            self.assertEqual(state["next_id"], 33)
            self.assertEqual(len(state["tasks"]), 32)
            self.assertEqual(len(self.store.history()), 33)
        finally:
            for worker in workers:
                if worker.is_alive():
                    worker.terminate()
                worker.join(timeout=2)
            results.close()


if __name__ == "__main__":
    unittest.main()
