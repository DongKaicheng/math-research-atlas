"""Publication-boundary tests for the independently hosted read-only corpus.

Fixtures supply their own source and review assertions; no external mathematics
or actual human review is claimed by these tests.
"""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.project import ingest, resolve_item, set_context, set_foundation
from mathproj.public_api import export_public_api, project_public_corpus, _source_location
from mathproj.publish import create_release
from mathproj.sources import cite_source, register_source
from mathproj.store import ProjectError, ProjectStore, digest
from mathproj.workflow import application_templates, prepare_review, record_applications, record_review


TEX = r"""\section{Public theory}
\begin{lemma}[Public premise]\label{base}
The declared fixture premise holds.
\end{lemma}
\begin{proof}PRIVATE_ADMITTED_SOURCE_PROOF.\end{proof}
\begin{lemma}[Public conclusion]\label{main}
The public conclusion concerns $\Gamma$ and $\gamma$.
\end{lemma}
\begin{proof}
Apply \ref{base}. See also \ref{draft}, mentioned only as future work.
\end{proof}
\begin{proof}PRIVATE_ALTERNATIVE_PROOF uses \ref{draft}.\end{proof}
\begin{lemma}\label{draft}
PRIVATE_DRAFT_STATEMENT
\end{lemma}
\begin{proof}PRIVATE_DRAFT_PROOF.\end{proof}
"""


class PublicCorpusTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.root = self.directory / "project"
        self.store = ProjectStore.create(self.root, "Frozen project title", namespace="PUB")
        self.path = self.root / "content/main.tex"
        self.path.write_text(TEX, encoding="utf-8")
        (self.root / "content/private.tex").write_text(
            r"\begin{lemma}\label{private-file}PRIVATE_WHOLE_SOURCE_FILE\end{lemma}", encoding="utf-8")
        set_context(self.store, "shared", "All displayed variables obey the public fixture convention.", labels=["main", "base"])
        set_context(self.store, "private-context", "PRIVATE_UNBOUND_CONTEXT", labels=["draft"])
        ingest(self.store)
        state = self.store.state()
        self.base, self.main, self.draft = [resolve_item(state, label) for label in ("base", "main", "draft")]
        self.first, self.alternative = state["items"][self.main]["proof_ids"]

    def accept(self, iid, pid=None):
        for subject in [iid + ":statement"] + ([pid] if pid else []):
            records = application_templates(self.store, subject)["records"]
            for row in records:
                row.update(relation="mention" if row["target_id"] == self.draft else "uses",
                           substitution="Use the same displayed fixture objects.", hypotheses=[], no_hypotheses=True,
                           conclusion="The unconditional fixture premise gives the conclusion.",
                           justification="PRIVATE_APPLICATION_REVIEW_NOTE", reviewer="PRIVATE_REVIEWER_ID")
            if records:
                record_applications(self.store, records)
        report = prepare_review(self.store, iid, pid)["template"]
        report.update(reviewer={"id": "PRIVATE_REVIEWER_ID", "kind": "agent", "independent": True, "author_of_change": False},
                      verdict="accept", summary="PRIVATE_REVIEW_SUMMARY")
        for check in report["checks"]:
            check.update(status="pass", reason="PRIVATE_REVIEW_CHECK_REASON")
        record_review(self.store, report)

    def source(self, key, title="Public source title"):
        return register_source(self.store, key, {
            "title": title, "uri": "https://example.invalid/public-source", "version": "fixture-v1",
            "status": "checked", "checked_by": "PRIVATE_SOURCE_CHECKER", "accessed_at": "2026-11-17",
            "notes": "PRIVATE_SOURCE_NOTES"})["source"]

    def citation(self, key, source, pid, **changes):
        state = self.store.state()
        row = {"citation_key": key, "source_revision": source["revision"],
               "declaration_revision": state["items"][self.main]["declaration_revision"],
               "proof_id": pid, "proof_revision": state["proofs"][pid]["revision"] if pid else None,
               "status": "checked", "locator": {"theorem": "Fixture theorem 2", "page": "3"},
               "supporting_statement": "PRIVATE_SUPPORTING_EXCERPT", "no_assumptions": True,
               "assumptions": [], "substitution": "Use the same displayed fixture objects.",
               "conclusion": "The cited conclusion yields the public fixture premise.", "justification": "PRIVATE_CITATION_NOTE",
               "inspected_text": "PRIVATE_INSPECTED_TEXT", "checked_by": "PRIVATE_CITATION_CHECKER",
               "accessed_at": "2026-11-17"}
        row.update(changes)
        return cite_source(self.store, self.main, source["key"], row)["citation"]

    def release(self):
        set_foundation(self.store, self.base, "PRIVATE_ADMISSION_INTERNAL_NOTE", kind="assumption")
        self.accept(self.main, self.first)
        return create_release(self.store, "release-v1", [self.main])

    def public(self, **kwargs):
        return project_public_corpus(self.store, "release-v1", **kwargs)

    def test_scope_whitelist_omits_private_archive_material(self):
        selected = self.source("selected")
        self.citation("selected-citation", selected, self.first)
        alternative = self.source("alternative", "PRIVATE_ALTERNATIVE_SOURCE_TITLE")
        self.citation("alternative-citation", alternative, self.alternative)
        self.source("unrelated", "PRIVATE_UNUSED_SOURCE_TITLE")
        release = self.release()
        internal = Path(release["manifest"]).read_text()
        self.assertIn("PRIVATE_WHOLE_SOURCE_FILE", internal)
        self.assertIn("PRIVATE_SOURCE_NOTES", internal)
        public = self.public()
        encoded = json.dumps(public)
        self.assertNotIn("PRIVATE_", encoded)
        self.assertEqual(set(public["items"]), {self.base, self.main})
        self.assertNotIn("snapshot_data", public)
        self.assertNotIn("reviews", encoded)
        self.assertNotIn(str(self.root), encoded)
        main = public["items"][self.main]
        self.assertEqual(main["proof"]["id"], self.first)
        self.assertEqual(main["dependencies"], [self.base])
        self.assertEqual([x["key"] for x in main["contexts"]], ["shared"])
        self.assertEqual([x["source_key"] for x in main["citations"]], ["selected"])
        self.assertEqual(main["citations"][0]["locator"], {"theorem": "Fixture theorem 2", "page": "3"})
        self.assertIs(main["citations"][0]["no_assumptions"], True)
        self.assertEqual(main["citations"][0]["assumptions"], [])

    def test_admission_is_not_presented_as_a_proved_result(self):
        self.release()
        public = self.public()
        base, main = public["items"][self.base], public["items"][self.main]
        self.assertEqual(base["status"], "admitted")
        self.assertEqual(base["admission"], {"kind": "assumption"})
        self.assertIsNone(base["proof"])
        self.assertEqual(base["dependencies"], [])
        self.assertEqual(main["status"], "reviewed")
        self.assertIsNone(main["admission"])
        self.assertIn("not formal kernel verification", public["release"]["meaning"])

    def test_reviewed_declaration_has_no_synthetic_proof_text(self):
        self.path.write_text(TEX + r"\begin{definition}\label{definition}A public fixture definition.\end{definition}")
        ingest(self.store)
        iid = resolve_item(self.store.state(), "definition")
        self.accept(iid)
        create_release(self.store, "definitions", [iid])
        record = project_public_corpus(self.store, "definitions")["items"][iid]
        self.assertEqual(record["status"], "reviewed")
        self.assertIsNone(record["proof"])

    def test_parsed_mentions_do_not_become_support_dependencies(self):
        self.release()
        main = self.public()["items"][self.main]
        outside = [ref for ref in main["references"] if ref["label"] == "draft"]
        self.assertEqual(len(outside), 1)
        self.assertEqual(outside[0]["relation"], "candidate_reference")
        self.assertIsNone(outside[0]["target_id"])
        self.assertNotIn(self.draft, main["dependencies"])
        self.assertTrue(all(row["target_id"] == self.base for row in main["applications"]))

    def test_frozen_projection_ignores_later_source_context_and_manifest_changes(self):
        self.release()
        before = self.public()
        self.path.write_text(TEX.replace("public conclusion", "edited public conclusion"))
        set_context(self.store, "shared", "Changed current convention.", global_scope=True)
        manifest = json.loads(self.store.manifest_path.read_text())
        manifest["name"] = "New current project title"
        self.store.manifest_path.write_text(json.dumps(manifest))
        ingest(self.store)
        self.assertEqual(before, self.public())

    def test_frozen_projection_keeps_selected_source_revision(self):
        selected = self.source("selected")
        self.citation("selected-citation", selected, self.first)
        self.release()
        before = self.public()
        register_source(self.store, "selected", {
            "title": "Edited current source", "uri": "https://example.invalid/new-version", "version": "fixture-v2",
            "status": "checked", "checked_by": "fixture", "accessed_at": "2026-11-17",
            "previous_revision": selected["revision"]})
        self.assertEqual(before, self.public())

    def test_exact_bibliographic_occurrences_retain_scope_and_locator(self):
        self.path.write_text(TEX.replace("Apply \\ref{base}.",
            "Apply \\ref{base} and \\cite[Theorem 2]{Fixture}. Compare \\cite[Lemma 3]{Fixture}."))
        ingest(self.store)
        selected = self.source("selected")
        slots = self.store.state()["proofs"][self.first]["bibliographic_references"]
        self.assertEqual(len(slots), 2)
        first, second = [row["reference_id"] for row in slots]
        self.citation("first-occurrence", selected, self.first, reference_ids=[first],
                      locator={"theorem": "Theorem 2", "page": "3"})
        self.citation("second-occurrence", selected, self.first, reference_ids=[second],
                      locator={"theorem": "Lemma 3", "page": "4"})
        self.citation("statement-evidence", selected, None)
        self.release()
        citations = self.public()["items"][self.main]["citations"]
        by_reference = {reference: row for row in citations for reference in row["reference_ids"]}
        self.assertEqual(set(by_reference), {first, second})
        self.assertEqual(by_reference[first]["locator"]["theorem"], "Theorem 2")
        self.assertEqual(by_reference[second]["locator"]["theorem"], "Lemma 3")
        self.assertTrue(all(row["scope"] == "proof" for row in by_reference.values()))
        self.assertEqual(len([row for row in citations if row["scope"] == "statement"]), 1)

    def test_hash_only_source_preserves_reproducible_material_and_citation_identity(self):
        source_bytes = b"Synthetic complete source material, version fixed by these bytes.\n"
        source_hash = hashlib.sha256(source_bytes).hexdigest()
        source = register_source(self.store, "hash-only", {
            "title": "Hash-addressed supplied fixture", "uri": "urn:sha256:" + source_hash,
            "version": None, "content_sha256": source_hash, "status": "checked",
            "checked_by": "PRIVATE_CHECKER", "accessed_at": "2026-11-17"})["source"]
        citation = self.citation("hash-citation", source, self.first)
        self.release()
        row = self.public()["items"][self.main]["citations"][0]
        self.assertIsNone(row["version"])
        self.assertEqual(row["content_sha256"], hashlib.sha256(source_bytes).hexdigest())
        self.assertEqual(row["citation_id"], citation["id"])
        self.assertEqual(row["citation_revision"], citation["revision"])
        self.assertEqual(row["source_revision"], source["revision"])
        self.assertNotIn("inspected_text", row)

    def test_external_citation_application_is_public_without_private_source_excerpt(self):
        source = self.source("selected")
        assumptions = [{"required": "The argument x is real.",
                        "discharge": "The displayed fixture quantifies x over the real numbers."}]
        citation = self.citation("explained-use", source, self.first,
                                 assumptions=assumptions, no_assumptions=False,
                                 substitution="Substitute the local real variable x for the source's t.",
                                 conclusion="The source inequality gives x squared nonnegative.")
        self.release()
        row = self.public()["items"][self.main]["citations"][0]
        self.assertEqual(row["assumptions"], assumptions)
        self.assertIs(row["no_assumptions"], False)
        self.assertEqual(row["substitution"], citation["substitution"])
        self.assertEqual(row["conclusion"], citation["conclusion"])
        self.assertEqual(set(row["assumptions"][0]), {"required", "discharge"})
        for forbidden in ("inspected_text", "supporting_statement", "justification", "notes", "checked_by", "reviewer"):
            self.assertNotIn(forbidden, row)
        self.assertNotIn("PRIVATE_", json.dumps(row))

    def test_corpus_identity_and_tex_case_are_exact(self):
        self.release()
        public = self.public()
        self.assertEqual(public["corpus_id"], digest({k: v for k, v in public.items() if k != "corpus_id"}))
        statement = public["items"][self.main]["statement"]["text"]
        self.assertIn(r"\Gamma", statement)
        self.assertIn(r"\gamma", statement)
        self.assertEqual(public, self.public())
        self.assertNotEqual(public["corpus_id"], self.public(title="Different explicit publication title")["corpus_id"])
        self.assertNotEqual(public["corpus_id"], self.public(demo=True)["corpus_id"])

    def test_projection_does_not_mutate_ledger_snapshot_or_release_files(self):
        self.release()
        files = lambda: {str(path.relative_to(self.root)): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        before = files()
        self.public()
        self.assertEqual(before, files())

    def test_no_release_or_unknown_release_is_refused(self):
        for reference in (None, "", "unreviewed", "../../events.jsonl"):
            with self.subTest(reference=reference), self.assertRaises(ProjectError):
                project_public_corpus(self.store, reference)

    def test_export_writes_standalone_corpus_outside_owner_project(self):
        self.release()
        output = self.directory / "published" / "api"
        exported = export_public_api(self.store, output, "release-v1", demo=True)
        self.assertEqual(Path(exported["output"]), output)
        public = json.loads((output / "public-corpus.json").read_text())
        self.assertTrue(public["project"]["demo"])
        self.assertEqual(public["corpus_id"], exported["corpus_id"])
        self.assertFalse((output / "mpm").exists())
        self.assertFalse((output / "content").exists())
        self.assertFalse((output / "release.json").exists())
        self.assertFalse(list(output.parent.glob(".mpm-public-*")))
        for name in ("runtime.mjs", "index.html", "build.mjs", "serve.mjs"):
            asset = Path(__file__).resolve().parents[2] / "assets/readonly-api" / name
            self.assertEqual((output / name).read_bytes(), asset.read_bytes())

    def test_missing_reader_asset_fails_before_creating_incomplete_export(self):
        self.release()
        empty_assets = self.directory / "empty-assets"
        empty_assets.mkdir()
        output = self.directory / "incomplete-export"
        with patch("mathproj.public_api._ASSET_DIRECTORY", empty_assets):
            with self.assertRaisesRegex(ProjectError, "Missing required public reader asset"):
                export_public_api(self.store, output, "release-v1")
        self.assertFalse(output.exists())
        self.assertFalse(list(output.parent.glob(".mpm-public-*")))

    def test_protected_destinations_and_existing_outputs_are_not_replaced(self):
        self.release()
        protected = [self.root, self.directory, self.root / "mpm/new", self.root / "content/new",
                     self.store.manifest_path, self.path, self.root / "content/../escape"]
        for output in protected:
            with self.subTest(output=output), self.assertRaises(ProjectError):
                export_public_api(self.store, output, "release-v1")
        output = self.directory / "existing"
        output.mkdir()
        (output / "keep").write_text("untouched")
        with self.assertRaisesRegex(ProjectError, "already exists"):
            export_public_api(self.store, output, "release-v1")
        self.assertEqual((output / "keep").read_text(), "untouched")

    def test_symlink_destination_and_ancestor_are_refused(self):
        self.release()
        link = self.directory / "link"
        link.symlink_to(self.root / "content", target_is_directory=True)
        for output in (link, link / "new"):
            with self.subTest(output=output), self.assertRaisesRegex(ProjectError, "symlink"):
                export_public_api(self.store, output, "release-v1")
        self.assertFalse((self.root / "content/new").exists())
        dangling = self.directory / "dangling"
        dangling.symlink_to(self.directory / "nonexistent")
        with self.assertRaisesRegex(ProjectError, "symlink"):
            export_public_api(self.store, dangling, "release-v1")

    def test_flat_source_root_can_export_outside_project(self):
        self.release()
        manifest = json.loads(self.store.manifest_path.read_text())
        manifest["source_roots"] = ["."]
        self.store.manifest_path.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(ProjectError, "protected"):
            export_public_api(self.store, self.root / "inside", "release-v1")
        result = export_public_api(self.store, self.directory / "outside", "release-v1")
        self.assertTrue(Path(result["corpus"]).is_file())

    def test_failed_atomic_install_does_not_remove_existing_destination(self):
        self.release()
        output = self.directory / "raced-output"
        def appeared(source, destination, parent_fd):
            output.mkdir()
            (output / "keep").write_text("other writer")
            raise ProjectError("destination appeared")
        with patch("mathproj.public_api._rename_new", side_effect=appeared):
            with self.assertRaisesRegex(ProjectError, "appeared"):
                export_public_api(self.store, output, "release-v1")
        self.assertEqual((output / "keep").read_text(), "other writer")
        self.assertFalse(list(output.parent.glob(".mpm-public-*")))

    def test_source_locations_cannot_disclose_absolute_or_traversing_paths(self):
        for path in ("/private/source.tex", "../../source.tex", "a/../source.tex", r"C:\private\source.tex", "a\\b.tex"):
            with self.subTest(path=path), self.assertRaises(ProjectError):
                _source_location({"path": path, "start_line": 1, "end_line": 3})
        for start, end in ((0, 3), (3, 2), (True, 3), (1, "3")):
            with self.subTest(start=start, end=end), self.assertRaises(ProjectError):
                _source_location({"path": "content/main.tex", "start_line": start, "end_line": end})

    def test_public_metadata_options_are_validated(self):
        self.release()
        for title in ("", " ", 3, "x" * 513):
            with self.subTest(title=title), self.assertRaises(ProjectError):
                self.public(title=title)
        with self.assertRaises(ProjectError):
            self.public(demo="yes")


if __name__ == "__main__":
    unittest.main()
