"""Literal bibliography inventory and precise mathematical ownership."""
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.latex import parse_project


class CitationReaderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def parse(self, text):
        (self.root / 'main.tex').write_bytes(text.encode('utf-8'))
        return parse_project(self.root, ['main.tex'])

    def inventory(self, result):
        return result['files'][0].get('bibliographic_references', [])

    def codes(self, result):
        return {row['code'] for row in result['diagnostics']}

    def test_statement_proof_and_unowned_mentions_have_separate_owners(self):
        result = self.parse(r'''Intro \cite{front}.
\begin{lemma}\label{result}Statement \cite{statement}.\end{lemma}
\begin{proof}Argument \cite{proof}.\end{proof}
''')
        item = result['items'][0]
        self.assertEqual([r['key'] for r in item['bibliographic_references']], ['statement'])
        self.assertEqual([r['key'] for r in item['proofs'][0]['bibliographic_references']], ['proof'])
        rows = self.inventory(result)
        self.assertEqual([r['role'] for r in rows], ['mention', 'statement', 'proof'])
        self.assertIsNone(rows[0]['item_key'])
        self.assertEqual(rows[1]['item_key'], item['key'])
        self.assertNotIn('proof_index', rows[1])
        self.assertEqual(rows[2]['proof_index'], 0)

    def test_optional_prenote_postnote_and_comma_separated_keys_are_preserved(self):
        result = self.parse(r'Compare \cite[see {Appendix [A]}][Theorem~2.1]{Alpha:2020, Beta_2}.')
        rows = self.inventory(result)
        self.assertEqual([r['key'] for r in rows], ['Alpha:2020', 'Beta_2'])
        self.assertEqual(rows[0]['notes'], ['see {Appendix [A]}', 'Theorem~2.1'])
        self.assertEqual(rows[0]['source'], rows[1]['source'])
        self.assertEqual(result['diagnostics'], [])

    def test_common_commands_and_starred_forms_retain_their_exact_spelling(self):
        names = ['cite', 'citep', 'citet', 'citealt', 'citealp', 'parencite', 'textcite',
                 'footcite', 'autocite', 'Citep', 'Textcite', 'citeauthor', 'citeyearpar']
        for name in names:
            for star in ['', '*']:
                with self.subTest(command=name + star):
                    result = self.parse('\\' + name + star + '[p. 4]{Source}')
                    self.assertEqual(self.inventory(result)[0]['command'], name + star)
                    self.assertEqual(self.inventory(result)[0]['notes'], ['p. 4'])
                    self.assertEqual(result['diagnostics'], [])

    def test_spaces_and_comments_before_star_or_arguments_do_not_erase_occurrence(self):
        result = self.parse('\\cite % line break\n * [see] % another\n [p. 8] {Source}')
        row = self.inventory(result)[0]
        self.assertEqual(row['command'], 'cite*')
        self.assertEqual(row['notes'], ['see', 'p. 8'])
        self.assertEqual(row['source']['start_line'], 1)
        self.assertEqual(row['source']['end_line'], 3)

    def test_duplicate_occurrences_and_duplicate_keys_are_not_deduplicated(self):
        result = self.parse(r'\cite{A,A} and \cite[2.3]{A}.')
        rows = self.inventory(result)
        self.assertEqual([r['key'] for r in rows], ['A', 'A', 'A'])
        self.assertEqual(rows[0]['source'], rows[1]['source'])
        self.assertNotEqual(rows[1]['source'], rows[2]['source'])

    def test_nocite_is_an_inventory_listing_even_inside_a_proof(self):
        result = self.parse(r'''\begin{lemma}\label{result}A statement.\end{lemma}
\begin{proof}A direct argument.\nocite{*,Background}\end{proof}''')
        proof = result['items'][0]['proofs'][0]
        self.assertEqual([row['role'] for row in proof['bibliographic_references']], ['bibliography', 'bibliography'])
        self.assertEqual([row['key'] for row in self.inventory(result)], ['*', 'Background'])
        self.assertEqual(result['diagnostics'], [])

    def test_proof_header_citation_is_kept_but_its_target_ref_is_not_a_dependency(self):
        result = self.parse(r'''\begin{lemma}\label{result}A statement.\end{lemma}
\begin{proof}[Proof of Lemma~\ref{result}, following \cite[4.2]{External}]
A direct argument.\end{proof}''')
        item = result['items'][0]
        self.assertEqual(item['proofs'][0]['references'], [])
        row = item['proofs'][0]['bibliographic_references'][0]
        self.assertEqual(row['key'], 'External')
        self.assertEqual(row['role'], 'proof')
        self.assertTrue(row['in_header'])
        self.assertNotIn('bibliographic_references', item)

    def test_nonstandard_nocite_forms_are_diagnostic_instead_of_guessed(self):
        for text in [r'\nocite*{Key}', r'\nocite[Notes]{Key}']:
            with self.subTest(text=text):
                result = self.parse(text)
                self.assertIn('unsupported_citation_arguments', self.codes(result))
                self.assertEqual(self.inventory(result), [])

    def test_alternative_proofs_are_independently_identified_in_file_inventory(self):
        result = self.parse(r'''\begin{lemma}\label{result}A statement.\end{lemma}
\begin{proof}Use \cite{First}.\end{proof}
\begin{proof}[Second argument \cite{Header}]Use \cite{Second}.\end{proof}''')
        rows = self.inventory(result)
        self.assertEqual([r['proof_index'] for r in rows], [0, 1, 1])
        self.assertEqual([r['key'] for r in result['items'][0]['proofs'][1]['bibliographic_references']], ['Header', 'Second'])

    def test_nested_proof_citation_is_not_repeated_in_enclosing_statement(self):
        result = self.parse(r'''\begin{lemma}\label{result}Statement \cite{A}.
\begin{proof}Argument \cite{B}.\end{proof}\end{lemma}''')
        item = result['items'][0]
        self.assertEqual([r['key'] for r in item['bibliographic_references']], ['A'])
        self.assertEqual([r['key'] for r in item['proofs'][0]['bibliographic_references']], ['B'])
        self.assertEqual(len(self.inventory(result)), 2)

    def test_orphan_proof_citation_stays_file_only_with_explicit_structural_error(self):
        result = self.parse(r'''\section{Overview}\label{overview}
\begin{proof}An unattached argument uses \cite{Orphan}.\end{proof}''')
        self.assertIn('orphan_proof', self.codes(result))
        self.assertNotIn('bibliographic_references', result['items'][0])
        row = self.inventory(result)[0]
        self.assertIsNone(row['item_key'])
        self.assertEqual(row['role'], 'proof')

    def test_navigation_and_bare_list_fragments_keep_mentions(self):
        result = self.parse(r'''\section{Overview}\label{overview}
See \cite{Overview}.
\begin{enumerate}\item\label{entry}Related material \cite{ListEntry}.\end{enumerate}''')
        items = {row['label']: row for row in result['items']}
        self.assertEqual(items['overview']['bibliographic_references'][0]['role'], 'mention')
        self.assertEqual(items['entry']['bibliographic_references'][0]['role'], 'mention')
        self.assertEqual(items['entry']['bibliographic_references'][0]['key'], 'ListEntry')
        self.assertEqual(len(self.inventory(result)), 2)

    def test_comments_verbatim_urls_and_macro_definitions_remain_inert(self):
        result = self.parse(r'''% \cite{Comment}
\verb|\cite{Inline}|
\begin{verbatim}\cite{Verbatim}\end{verbatim}
\begin{lstlisting}\cite{Listing}\end{lstlisting}
\url{https://example.invalid/\cite{URL}}
\newcommand{\customcite}[1]{\cite{#1}}
\def\another{\cite{Body}}
\customcite{NotExpanded}
Visible \cite{Actual}.
''')
        self.assertEqual([r['key'] for r in self.inventory(result)], ['Actual'])
        self.assertEqual(result['diagnostics'], [])

    def test_endinput_masks_only_following_lines_like_the_existing_reader(self):
        result = self.parse('Visible \\cite{A}.\n\\endinput\nInvisible \\cite{B}.\n')
        self.assertEqual([r['key'] for r in self.inventory(result)], ['A'])

    def test_unicode_bom_and_crlf_offsets_select_the_original_command_bytes(self):
        text = '\ufeff中文\r\nA \\cite[注]{中文文献} follows.\r\n'
        result = self.parse(text)
        row = self.inventory(result)[0]
        loc = row['source']
        self.assertEqual(text[loc['start_char']:loc['end_char']], '\\cite[注]{中文文献}')
        self.assertEqual((loc['start_line'], loc['end_line']), (2, 2))
        self.assertEqual(result['files'][0]['text'].encode('utf-8'), text.encode('utf-8'))

    def test_dynamic_keys_are_diagnostic_and_not_guessed(self):
        for value in [r'\source', 'A B', 'A\nB', '{Grouped}', '$x$', 'A~B', 'A^B', 'A&B', '#1', '*']:
            with self.subTest(value=value):
                result = self.parse('\\cite{' + value + '}')
                self.assertIn('dynamic_citation', self.codes(result))
                self.assertEqual(self.inventory(result), [])

    def test_literal_siblings_survive_a_bad_key_without_hiding_the_error(self):
        result = self.parse(r'\cite{A,\dynamic,B}')
        self.assertEqual([r['key'] for r in self.inventory(result)], ['A', 'B'])
        self.assertIn('dynamic_citation', self.codes(result))

    def test_empty_missing_and_unclosed_arguments_are_explicit_errors(self):
        for text in [r'\cite{}', r'\cite{A,}', r'\cite', r'\cite[Unclosed', r'\cite{Unclosed']:
            with self.subTest(text=text):
                result = self.parse(text)
                self.assertIn('malformed_citation', self.codes(result))

    def test_more_than_two_optional_arguments_are_not_misread(self):
        result = self.parse(r'\cite[a][b][c]{Key}')
        self.assertIn('unsupported_citation_arguments', self.codes(result))
        self.assertEqual(self.inventory(result), [])

    def test_commands_inside_a_dynamic_key_do_not_create_guessed_citations(self):
        result = self.parse(r'\cite{\cite{Invented}}')
        self.assertIn('dynamic_citation', self.codes(result))
        self.assertEqual(self.inventory(result), [])

    def test_an_actual_nested_citation_in_a_prenote_is_visible(self):
        result = self.parse(r'\cite[compare \cite{Inner}]{Outer}')
        self.assertEqual([r['key'] for r in self.inventory(result)], ['Outer', 'Inner'])
        self.assertEqual(result['diagnostics'], [])

    def test_multicite_commands_are_explicitly_unsupported(self):
        for command in ['cites', 'parencites', 'Textcites', 'autocites']:
            with self.subTest(command=command):
                result = self.parse('\\' + command + '{A}{B}')
                self.assertIn('unsupported_multicite', self.codes(result))
                self.assertEqual(self.inventory(result), [])

    def test_file_without_indexed_math_still_has_complete_literal_inventory(self):
        result = self.parse(r'Background from \cite{One,Two}.')
        self.assertEqual(result['items'], [])
        self.assertEqual([r['key'] for r in self.inventory(result)], ['One', 'Two'])
        self.assertTrue(all(row['item_key'] is None for row in self.inventory(result)))


if __name__ == '__main__':
    unittest.main()
