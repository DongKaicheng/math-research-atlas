"""Original minimal examples for source patterns seen in a large TeX corpus.

No mathematical prose from the reference corpus is copied into these tests.
The tests check syntactic capture and explicit limitations, not proof validity.
"""

from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.latex import parse_project, source_layout


SELECTOR = r"""\IfFileExists{local-style.cls}{%
\documentclass[11pt,oneside]{local-style}
}{%
\documentclass{article}
}
"""
RESULT = r"\begin{lemma}\label{actual}An original sample assertion.\end{lemma}"


class RealPatternReaderCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def write(self, name, text):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")

    def parse(self, text):
        self.write("chapter.tex", text)
        return parse_project(self.root, ["chapter.tex"])

    def codes(self, result):
        return {row["code"] for row in result["diagnostics"]}

    def items(self, result):
        return {item["label"]: item for item in result["items"]}

    def assertNoErrors(self, result):
        self.assertEqual([], [row for row in result["diagnostics"] if row["severity"] == "error"])

    def test_literal_class_selector_is_ignored_without_loading_either_class(self):
        self.write("local-style.cls", r"\begin{lemma}\label{not-loaded}Invisible class content.\end{lemma}")
        result = self.parse(SELECTOR + RESULT)
        self.assertNoErrors(result)
        self.assertEqual(["actual"], [item["label"] for item in result["items"]])
        self.assertEqual(["chapter.tex"], [source["path"] for source in result["files"]])
        diagnostic = next(row for row in result["diagnostics"] if row["code"] == "presentation_class_selector")
        self.assertEqual("info", diagnostic["severity"])
        self.assertIn("class contents are not read or evaluated", diagnostic["message"])
        self.assertIn(SELECTOR, result["files"][0]["text"])
        (self.root / "local-style.cls").unlink()
        absent = parse_project(self.root, ["chapter.tex"])
        self.assertEqual(result, absent)

    def test_extra_commands_or_math_prevent_class_selector_exception(self):
        additions = [r"\relax", r"\input{other}", "$x=x$", r"\customsetup", r"\label{hidden}"]
        self.write("other.tex", "Extra source text.")
        for addition in additions:
            with self.subTest(addition=addition):
                text = r"\IfFileExists{style.cls}{\documentclass{article}" + addition + r"}{\documentclass{book}}" + RESULT
                result = self.parse(text)
                self.assertIn("conditional_tex_not_evaluated", self.codes(result))
                self.assertNotIn("presentation_class_selector", self.codes(result))

    def test_macro_class_names_options_and_filenames_are_not_accepted(self):
        selectors = [
            r"\IfFileExists{\style.cls}{\documentclass{article}}{\documentclass{book}}",
            r"\IfFileExists{style.cls}{\documentclass{\style}}{\documentclass{book}}",
            r"\IfFileExists{style.cls}{\documentclass[\option]{article}}{\documentclass{book}}",
            r"\IfFileExists{style.cls}{\documentclass{article}}{\documentclass{book}\extra}",
            r"\IfFileExists{style.tex}{\documentclass{article}}{\documentclass{book}}",
        ]
        for selector in selectors:
            with self.subTest(selector=selector):
                result = self.parse(selector + RESULT)
                self.assertIn("conditional_tex_not_evaluated", self.codes(result))
                self.assertNotIn("presentation_class_selector", self.codes(result))

    def test_math_and_unknown_conditionals_remain_errors(self):
        for selector in [r"\IfSomething{yes}{no}", r"\ifdraft X.\fi",
                         r"\IfFileExists{style.cls}{" + RESULT + r"}{\documentclass{article}}"]:
            with self.subTest(selector=selector):
                result = self.parse(selector)
                self.assertIn("conditional_tex_not_evaluated", self.codes(result))
                self.assertNotIn("presentation_class_selector", self.codes(result))

    def test_selector_after_document_or_heading_remains_an_error(self):
        for prefix, suffix in [(r"\begin{document}", r"\end{document}"), (r"\section{Body}", "")]:
            with self.subTest(prefix=prefix):
                result = self.parse(prefix + SELECTOR + RESULT + suffix)
                self.assertIn("conditional_tex_not_evaluated", self.codes(result))
                self.assertNotIn("presentation_class_selector", self.codes(result))

    def test_included_preamble_selector_is_allowed_before_document(self):
        self.write("preamble.tex", SELECTOR)
        result = self.parse(r"\input{preamble}\begin{document}" + RESULT + r"\end{document}")
        self.assertNoErrors(result)
        self.assertIn("presentation_class_selector", self.codes(result))

    def test_selector_in_first_include_after_document_is_rejected(self):
        self.write("preamble.tex", SELECTOR)
        result = self.parse(r"\begin{document}\input{preamble}" + RESULT + r"\end{document}")
        self.assertIn("conditional_tex_not_evaluated", self.codes(result))
        self.assertNotIn("presentation_class_selector", self.codes(result))

    def test_reincluded_class_selector_after_document_is_rejected(self):
        self.write("preamble.tex", SELECTOR)
        result = self.parse(r"\input{preamble}\begin{document}\input{preamble}" + RESULT + r"\end{document}")
        self.assertIn("class_selector_after_document_content", self.codes(result))

    def test_document_content_in_prior_include_prevents_later_selector(self):
        self.write("body.tex", RESULT)
        self.write("preamble.tex", SELECTOR)
        result = self.parse(r"\input{body}\input{preamble}")
        self.assertIn("conditional_tex_not_evaluated", self.codes(result))
        self.assertNotIn("presentation_class_selector", self.codes(result))
        result = self.parse(r"\input{body}" + SELECTOR)
        self.assertIn("conditional_tex_not_evaluated", self.codes(result))

    def test_independent_entrypoints_share_a_preamble_without_false_body_error(self):
        self.write("preamble.tex", SELECTOR)
        for name in ("one", "two"):
            self.write(name + ".tex", r"\input{preamble}\begin{document}\begin{lemma}\label{" + name + r"}Sample.\end{lemma}\end{document}")
        result = parse_project(self.root, ["one.tex", "two.tex"])
        self.assertNoErrors(result)
        self.assertEqual({"one", "two"}, set(self.items(result)))

    def test_list_fragments_have_exact_boundaries_and_context_spans(self):
        text = r"""\section{Local vocabulary}\label{section-vocabulary}
Fix a symbol $u$ in this paragraph.
\begin{enumerate}
\item A first piece of original text.\label{item-first}
\item\label{item-second} A second piece citing \ref{item-first}.
\end{enumerate}
\begin{lemma}\label{later}A later assertion.\end{lemma}
\begin{proof}A later argument.\end{proof}
"""
        result = self.parse(text)
        self.assertNoErrors(result)
        items = self.items(result)
        first, second = items["item-first"], items["item-second"]
        self.assertEqual("fragment", first["kind"])
        self.assertEqual("A first piece of original text.", first["statement"])
        self.assertEqual(["Local vocabulary"], first["section"])
        self.assertEqual([], first["proofs"])
        self.assertEqual(1, first["fragment_context"]["item_index"])
        self.assertEqual(2, second["fragment_context"]["item_index"])
        self.assertEqual("enumerate", first["fragment_context"]["environment"])
        start, end = first["source"]["start_char"], first["source"]["end_char"]
        self.assertEqual(text[text.index(r"\item A"):text.index(r"\item\label{item-second}")], text[start:end])
        context = first["fragment_context"]
        list_text = text[context["list_source"]["start_char"]:context["list_source"]["end_char"]]
        self.assertTrue(list_text.startswith(r"\begin{enumerate}"))
        self.assertTrue(list_text.endswith(r"\end{enumerate}"))
        preceding = text[context["preceding_source"]["start_char"]:context["preceding_source"]["end_char"]]
        self.assertIn("Fix a symbol", preceding)
        self.assertNotIn("later assertion", second["statement"])
        self.assertEqual("mention", second["references"][0]["role"])
        self.assertEqual("chapter.tex::item-first", second["references"][0]["target_key"])
        self.assertEqual("A later argument.", items["later"]["proofs"][0]["text"])

    def test_same_line_fragments_remain_distinct(self):
        text = r"\begin{itemize}\item\label{a}Alpha.\item\label{b}Beta.\end{itemize}"
        result = self.parse(text)
        items = self.items(result)
        self.assertEqual("Alpha.", items["a"]["statement"])
        self.assertEqual("Beta.", items["b"]["statement"])
        self.assertEqual(items["a"]["source"]["end_char"], items["b"]["source"]["start_char"])

    def test_nested_list_labels_alias_the_labeled_outer_fragment(self):
        result = self.parse(r"""\begin{enumerate}
\item\label{outer}An outer condition.
\begin{itemize}\item\label{inner}A subsidiary condition.\end{itemize}
Return to the outer entry.
\item\label{next}The next outer entry.
\end{enumerate}
\begin{lemma}\label{consumer}See \ref{inner}.\end{lemma}
""")
        self.assertNoErrors(result)
        items = self.items(result)
        self.assertNotIn("inner", items)
        self.assertEqual(["outer", "inner"], items["outer"]["label_aliases"])
        self.assertIn("Return to the outer entry.", items["outer"]["statement"])
        self.assertNotIn("next outer entry", items["outer"]["statement"])
        self.assertEqual("chapter.tex::outer", items["consumer"]["references"][0]["target_key"])
        self.assertEqual("inner", items["consumer"]["references"][0]["target_clause"])

    def test_unlabeled_outer_scope_is_not_inferred_from_a_nested_label(self):
        result = self.parse(r"\begin{enumerate}\item An unstated scope.\begin{itemize}\item\label{nested}A condition.\end{itemize}\end{enumerate}")
        self.assertEqual([], result["items"])
        self.assertIn("unmanaged_label", self.codes(result))

    def test_description_marker_is_a_title_and_kind_stays_fragment(self):
        result = self.parse(r"\begin{description}\item[Definition-like heading]\label{term}A sample convention.\end{description}")
        item = self.items(result)["term"]
        self.assertEqual("fragment", item["kind"])
        self.assertEqual("Definition-like heading", item["title"])
        self.assertEqual("A sample convention.", item["statement"])
        self.assertEqual([], item["proofs"])

    def test_theorem_and_proof_lists_remain_parent_aliases(self):
        result = self.parse(r"""\begin{lemma}\label{parent}
\begin{enumerate}\item\label{clause}A clause.\end{enumerate}
\end{lemma}
\begin{proof}\begin{itemize}\item\label{proof-clause}An argument.\end{itemize}\end{proof}
""")
        self.assertNoErrors(result)
        self.assertEqual(1, len(result["items"]))
        self.assertEqual("lemma", result["items"][0]["kind"])
        self.assertEqual(["parent", "clause", "proof-clause"], result["items"][0]["label_aliases"])

    def test_complex_list_entry_does_not_consume_an_indexed_result_or_proof(self):
        result = self.parse(r"""\begin{enumerate}\item\label{outer}Some lead-in.
\begin{lemma}\label{inner}A separately declared assertion.\end{lemma}
\begin{proof}Its argument.\end{proof}
\end{enumerate}
""")
        self.assertNotIn("outer", self.items(result))
        self.assertEqual("lemma", self.items(result)["inner"]["kind"])
        self.assertEqual("Its argument.", self.items(result)["inner"]["proofs"][0]["text"])
        self.assertIn("complex_list_item_not_captured", self.codes(result))
        self.assertIn("unmanaged_label", self.codes(result))

    def test_list_entry_with_an_independently_labeled_equation_stays_explicit(self):
        result = self.parse(r"\begin{enumerate}\item\label{outer}Formula: \begin{equation}\label{formula}a=a.\end{equation}\end{enumerate}")
        self.assertNotIn("outer", self.items(result))
        self.assertEqual("equation", self.items(result)["formula"]["kind"])
        self.assertIn("complex_list_item_not_captured", self.codes(result))

    def test_unclosed_or_wrapped_list_does_not_receive_an_inferred_fragment(self):
        for text in [r"\begin{enumerate}\item\label{unclosed}Unfinished.",
                     r"\begin{quote}\begin{enumerate}\item\label{wrapped}Extra scope.\end{enumerate}\end{quote}"]:
            with self.subTest(text=text):
                result = self.parse(text)
                self.assertEqual([], result["items"])
                self.assertIn("unmanaged_label", self.codes(result))

    def test_comments_and_verbatim_cannot_create_item_boundaries(self):
        result = self.parse(r"""\begin{enumerate}
\item\label{a}Start. % \item\label{fake}False boundary.
\verb|\item\label{other-fake}| End.
\item\label{b}Next.
\end{enumerate}
""")
        self.assertNoErrors(result)
        self.assertEqual({"a", "b"}, set(self.items(result)))
        self.assertIn("End.", self.items(result)["a"]["statement"])

    def test_fragment_blocks_implicit_proof_attachment_to_an_earlier_result(self):
        result = self.parse(RESULT + r"\begin{enumerate}\item\label{fragment}A separate fragment.\end{enumerate}\begin{proof}Whose proof?\end{proof}")
        self.assertIn("orphan_proof", self.codes(result))
        self.assertTrue(all(not item["proofs"] for item in result["items"]))

    def test_fragment_cannot_be_an_explicit_proof_target(self):
        result = self.parse(r"\begin{enumerate}\item\label{fragment}Unclassified material.\end{enumerate}\begin{proof}[Proof of \ref{fragment}]A proposed argument.\end{proof}")
        self.assertIn("fragment_is_not_proof_target", self.codes(result))
        self.assertEqual([], self.items(result)["fragment"]["proofs"])

    def test_explicit_prior_theorem_target_can_cross_a_fragment(self):
        result = self.parse(RESULT + r"\begin{enumerate}\item\label{fragment}A separate fragment.\end{enumerate}\begin{proof}[Proof of \ref{actual}]The intended argument.\end{proof}")
        self.assertNoErrors(result)
        self.assertEqual("The intended argument.", self.items(result)["actual"]["proofs"][0]["text"])

    def test_prefixed_fragment_reference_resolves_without_type_inference(self):
        self.write("vocabulary.tex", r"\begin{enumerate}\item\label{item-term}An original term.\end{enumerate}")
        self.write("uses.tex", r"\begin{lemma}\label{use}See \ref{vocabulary-item-term}.\end{lemma}")
        result = parse_project(self.root, ["vocabulary.tex", "uses.tex"])
        self.assertNoErrors(result)
        items = self.items(result)
        self.assertEqual("fragment", items["item-term"]["kind"])
        self.assertEqual("vocabulary.tex::item-term", items["use"]["references"][0]["target_key"])

    def test_phantom_title_anchor_is_navigation_with_exact_span(self):
        text = r"\begin{document}\title{A sample}\maketitle\phantomsection\label{section-phantom}\end{document}"
        result = self.parse(text)
        self.assertNoErrors(result)
        item = self.items(result)["section-phantom"]
        self.assertEqual("document", item["kind"])
        self.assertEqual("A sample", item["title"])
        self.assertEqual([], item["proofs"])
        self.assertNotIn("unmanaged_label", self.codes(result))
        span = item["source"]
        self.assertEqual(r"\phantomsection\label{section-phantom}", text[span["start_char"]:span["end_char"]])

    def test_phantom_anchor_can_have_comments_before_immediate_label(self):
        result = self.parse("\\phantomsection % comment\n\\label{front}\n" + RESULT)
        self.assertNoErrors(result)
        self.assertEqual("chapter", self.items(result)["front"]["title"])

    def test_prefixed_reference_to_document_anchor_resolves(self):
        self.write("front.tex", r"\title{First}\phantomsection\label{front}")
        self.write("other.tex", r"\begin{lemma}\label{use}See \ref{front-front}.\end{lemma}")
        result = parse_project(self.root, ["front.tex", "other.tex"])
        self.assertNoErrors(result)
        self.assertEqual("front.tex::front", self.items(result)["use"]["references"][0]["target_key"])

    def test_phantom_anchor_requires_immediate_label(self):
        for middle in ["Intervening prose.", r"\relax", "{}"]:
            with self.subTest(middle=middle):
                result = self.parse(r"\phantomsection" + middle + r"\label{unmanaged}")
                self.assertEqual([], result["items"])
                self.assertIn("unmanaged_label", self.codes(result))

    def test_phantom_anchor_does_not_claim_grouped_or_local_scope(self):
        for text in [r"\custom{\phantomsection\label{local}}",
                     r"{\phantomsection\label{local}}",
                     r"\begin{quote}\phantomsection\label{local}\end{quote}"]:
            with self.subTest(text=text):
                result = self.parse(text)
                self.assertEqual([], result["items"])
                self.assertIn("unmanaged_label", self.codes(result))

    def test_phantom_after_mathematical_content_is_not_document_front(self):
        result = self.parse(RESULT + r"\phantomsection\label{late}")
        self.assertNotIn("late", self.items(result))
        self.assertIn("unmanaged_label", self.codes(result))

    def test_phantom_after_heading_is_not_a_new_document(self):
        result = self.parse(r"\section{Heading}\label{heading}\phantomsection\label{late}")
        self.assertTrue(all(item["kind"] != "document" for item in result["items"]))

    def test_phantom_after_document_end_is_not_document_front(self):
        result = self.parse(r"\begin{document}\end{document}\phantomsection\label{late}")
        self.assertEqual([], result["items"])
        self.assertIn("unmanaged_label", self.codes(result))

    def test_document_anchor_cannot_receive_implicit_or_explicit_proof(self):
        for title in ["", r"[Proof of \ref{front}]"]:
            with self.subTest(title=title):
                result = self.parse(r"\phantomsection\label{front}\begin{proof}" + title + r"An argument.\end{proof}")
                self.assertEqual([], self.items(result)["front"]["proofs"])
                expected = "navigation_is_not_proof_target" if title else "orphan_proof"
                self.assertIn(expected, self.codes(result))

    def test_layout_matches_parse_and_does_not_read_source_content(self):
        self.write("parts/child.tex", RESULT)
        self.write("main.tex", r"\input{parts/child}")
        parsed = parse_project(self.root, ["main.tex"])
        with patch.object(Path, "read_bytes", side_effect=AssertionError("must not open source")), \
             patch.object(Path, "read_text", side_effect=AssertionError("must not open source")):
            checked = source_layout(self.root, entrypoints=["main.tex"], lookups=parsed["source_layout"]["lookups"])
        self.assertEqual(parsed["source_layout"], checked)
        self.assertEqual({"main.tex", "parts/child.tex"}, {row["selected"] for row in checked["lookups"]})

    def test_layout_detects_new_source_root_file(self):
        self.write("content/a.tex", RESULT)
        initial = parse_project(self.root, source_roots=["content"])["source_layout"]
        self.write("content/b.tex", "A new source.")
        changed = source_layout(self.root, source_roots=["content"], lookups=initial["lookups"])
        self.assertNotEqual(initial, changed)
        self.assertEqual(["content/a.tex", "content/b.tex"], [row["path"] for row in changed["discovered"]])

    def test_entrypoint_layout_ignores_unreachable_new_sources(self):
        self.write("main.tex", RESULT)
        initial = parse_project(self.root, ["main.tex"])["source_layout"]
        self.write("unreachable.tex", r"\input{new-child}")
        self.write("new-child.tex", "An unreachable child.")
        self.assertEqual(initial, source_layout(self.root, entrypoints=["main.tex"], lookups=initial["lookups"]))

    def test_layout_detects_extensionless_include_shadowing(self):
        self.write("main.tex", r"\input{child}")
        self.write("child.tex", RESULT)
        initial = parse_project(self.root, ["main.tex"])["source_layout"]
        self.write("child", "Extensionless source.")
        changed = source_layout(self.root, entrypoints=["main.tex"], lookups=initial["lookups"])
        self.assertNotEqual(initial, changed)
        self.assertEqual("child", next(row["selected"] for row in changed["lookups"] if row["from_path"] == "main.tex"))

    def test_layout_detects_extensionless_entrypoint_shadowing(self):
        self.write("main.tex", RESULT)
        initial = parse_project(self.root, ["main"])["source_layout"]
        self.write("main", "A new entrypoint source.")
        changed = source_layout(self.root, entrypoints=["main"], lookups=initial["lookups"])
        self.assertEqual("main", changed["lookups"][0]["selected"])
        self.assertNotEqual(initial, changed)

    def test_layout_detects_root_relative_shadow_of_sibling_fallback(self):
        self.write("parts/main.tex", r"\input{child}")
        self.write("parts/child.tex", RESULT)
        initial = parse_project(self.root, ["parts/main.tex"])["source_layout"]
        self.write("child.tex", "A root-relative source.")
        changed = source_layout(self.root, entrypoints=["parts/main.tex"], lookups=initial["lookups"])
        child = next(row for row in changed["lookups"] if row["from_path"] == "parts/main.tex")
        self.assertEqual("child.tex", child["selected"])
        self.assertNotEqual(initial, changed)

    def test_layout_detects_symlink_retarget_even_with_identical_bytes(self):
        self.write("main.tex", r"\input{selected}")
        self.write("a.tex", RESULT)
        self.write("b.tex", RESULT)
        link = self.root / "selected.tex"
        link.symlink_to("a.tex")
        initial = parse_project(self.root, ["main.tex"])["source_layout"]
        link.unlink()
        link.symlink_to("b.tex")
        changed = source_layout(self.root, entrypoints=["main.tex"], lookups=initial["lookups"])
        self.assertNotEqual(initial, changed)
        self.assertEqual("b.tex", next(row["selected"] for row in changed["lookups"] if row["from_path"] == "main.tex"))

    def test_layout_detects_symlink_escaping_root(self):
        self.write("main.tex", r"\input{selected}")
        self.write("a.tex", RESULT)
        link = self.root / "selected.tex"
        link.symlink_to("a.tex")
        initial = parse_project(self.root, ["main.tex"])["source_layout"]
        link.unlink()
        with tempfile.TemporaryDirectory() as outside:
            target = Path(outside) / "source.tex"
            target.write_text(RESULT, encoding="utf-8")
            link.symlink_to(target)
            changed = source_layout(self.root, entrypoints=["main.tex"], lookups=initial["lookups"])
        self.assertNotEqual(initial, changed)
        self.assertIsNone(next(row["selected"] for row in changed["lookups"] if row["from_path"] == "main.tex"))

    def test_layout_captures_missing_and_reappearing_includes(self):
        self.write("main.tex", r"\input{absent}")
        parsed = parse_project(self.root, ["main.tex"])
        initial = parsed["source_layout"]
        self.assertIn("missing_include", self.codes(parsed))
        missing = next(row for row in initial["lookups"] if row["from_path"] == "main.tex")
        self.assertEqual("missing", missing["status"])
        self.write("absent.tex", RESULT)
        changed = source_layout(self.root, entrypoints=["main.tex"], lookups=initial["lookups"])
        self.assertNotEqual(initial, changed)
        (self.root / "absent.tex").unlink()
        self.assertEqual(initial, source_layout(self.root, entrypoints=["main.tex"], lookups=initial["lookups"]))

    def test_layout_captures_source_root_symlink_retarget(self):
        self.write("one/a.tex", RESULT)
        self.write("two/a.tex", RESULT)
        link = self.root / "chosen"
        link.symlink_to("one", target_is_directory=True)
        initial = parse_project(self.root, source_roots=["chosen"])["source_layout"]
        link.unlink()
        link.symlink_to("two", target_is_directory=True)
        changed = source_layout(self.root, source_roots=["chosen"], lookups=initial["lookups"])
        self.assertNotEqual(initial, changed)
        self.assertEqual("two", changed["roots"][0]["resolved"])

    def test_layout_captures_symlink_cycle_without_crashing(self):
        (self.root / "cycle.tex").symlink_to("cycle.tex")
        result = source_layout(self.root, entrypoints=["cycle.tex"])
        self.assertEqual("unresolvable", result["lookups"][0]["status"])
        parsed = parse_project(self.root, ["cycle.tex"])
        self.assertEqual(result, parsed["source_layout"])
        self.assertIn("unresolvable_path", self.codes(parsed))

    def test_repeated_lookup_race_is_a_structural_error(self):
        self.write("main.tex", r"\input{selected}\input{selected}")
        self.write("a.tex", RESULT)
        self.write("b.tex", RESULT)
        link = self.root / "selected.tex"
        link.symlink_to("a.tex")
        read_bytes = Path.read_bytes

        def mutating_read(path):
            raw = read_bytes(path)
            if path == self.root / "a.tex":
                link.unlink()
                link.symlink_to("b.tex")
            return raw

        with patch.object(Path, "read_bytes", mutating_read):
            parsed = parse_project(self.root, ["main.tex"])
        self.assertIn("source_layout_changed_during_parse", self.codes(parsed))
        self.assertEqual({"main.tex", "a.tex", "b.tex"}, {row["path"] for row in parsed["files"]})

    def test_invalid_layout_paths_are_diagnostic_data(self):
        for entrypoints in [["bad\x00path"], ["\\macro"], [None], ["/"]]:
            with self.subTest(entrypoints=entrypoints):
                parsed = parse_project(self.root, entrypoints)
                checked = source_layout(self.root, entrypoints=entrypoints,
                                        lookups=parsed["source_layout"]["lookups"])
                self.assertEqual(parsed["source_layout"], checked)
                self.assertTrue(any(row["severity"] == "error" for row in parsed["diagnostics"]))

    def test_layout_ignores_hidden_and_build_directories_consistently(self):
        self.write("content/main.tex", RESULT)
        initial = parse_project(self.root, source_roots=["content"])["source_layout"]
        for name in [".hidden", "build", "mpm"]:
            self.write("content/" + name + "/ignored.tex", "Hidden source.")
        self.assertEqual(initial, source_layout(self.root, source_roots=["content"], lookups=initial["lookups"]))


if __name__ == "__main__":
    unittest.main()
