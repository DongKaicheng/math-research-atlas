"""Check logical gates and exact artifact binding, not mathematical proof truth."""
from __future__ import annotations

import copy
from html.parser import HTMLParser
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

SCRIPTS = Path(__file__).resolve().parents[1]
ROOT = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))
import logic_map as lm
from logicmap_render import render_dot, render_svg, render_html


def example():
    return lm.load_json(ROOT / "assets/logic-map-example.json")


class Markup(HTMLParser):
    def __init__(self, value):
        super().__init__()
        self.ids, self.fragments, self.tags = [], [], []
        self.feed(value)

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        for name in ("href", "xlink:href"):
            if attrs.get(name, "").startswith("#"):
                self.fragments.append(attrs[name][1:])


class LogicMapTests(unittest.TestCase):
    def reject(self, data, message):
        report = lm.audit(data, ROOT / "assets")
        self.assertFalse(report["valid"], report)
        self.assertTrue(any(message in e for e in report["errors"]), report)

    def test_full_scope_and_source_bytes_are_read_only(self):
        data = example()
        before = copy.deepcopy(data)
        result = lm.audit(data, ROOT / "assets")
        self.assertTrue(result["valid"], result)
        self.assertEqual(result["counts"]["local_sources_checked"], 1)
        self.assertEqual(data, before)

    def test_principal_cannot_hide_joint_premise(self):
        data = example()
        data["views"][0]["nodeIds"].remove("surjective")
        self.reject(data, "hides a premise")

    def test_complete_must_include_all_relations(self):
        data = example()
        data["views"][1]["relationIds"].remove("iso-bijective")
        self.reject(data, "complete view must contain every")

    def test_or_cannot_join_proof_inputs_or_open_steps(self):
        for kind in ("proof-dependency", "open-step", "obstruction"):
            with self.subTest(kind=kind):
                data = example()
                data["relations"][2]["kind"] = kind
                self.reject(data, "OR may join only sufficient")

    def test_conditional_gate_requires_exact_conditions(self):
        data = example()
        data["relations"][0]["conditions"] = ["Use this same homomorphism f."]
        self.reject(data, "additional hypotheses require")
        data["relations"][0]["kind"] = "conditional-implication"
        self.assertTrue(lm.audit(data, ROOT / "assets")["valid"])
        data["relations"][0]["conditions"] = []
        self.reject(data, "needs explicit additional hypotheses")

    def test_grounded_alternative_survives_union_cycle(self):
        data = example()
        self.assertTrue(lm.audit(data, ROOT / "assets")["valid"])
        data["support"]["selected"] = ["bijection-route", "iso-bijective"]
        self.reject(data, "cycle or unavailable premise")

    def test_open_root_cannot_be_available_support(self):
        data = example()
        data["nodes"][0]["status"] = "open"
        self.reject(data, "not an available or explicitly admitted premise")

    def test_duplicate_identity_unknown_reference_and_wrong_types_fail(self):
        data = example()
        data["nodes"].append(copy.deepcopy(data["nodes"][0]))
        self.reject(data, "duplicate identifier")
        data = example()
        data["relations"][0]["from"].append("absent")
        self.reject(data, "unknown identifier")
        data = example()
        data["relations"][0].update(kind={}, to={}, **{"from": [[]]})
        self.assertFalse(lm.audit(data)["valid"])
        self.assertFalse(lm.audit([])["valid"])

    def test_active_or_credential_urls_rejected(self):
        for href in ("javascript:alert(1)", "data:text/html,test", "//host/path", "https://user:password@example.org/"):
            with self.subTest(href=href):
                data = example()
                data["sources"][0]["href"] = href
                self.reject(data, "safe HTTP(S)")

    def test_source_change_and_escape_rejected(self):
        data = example()
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp) / "logic-map-example.md"
            shutil.copyfile(ROOT / "assets/logic-map-example.md", target)
            target.write_text(target.read_text() + "\nChanged premise.\n")
            result = lm.audit(data, temp)
            self.assertFalse(result["valid"])
            self.assertIn("source bytes changed", str(result))
        data["sources"][0]["path"] = "../private.md"
        self.reject(data, "within the source root")

    def test_duplicate_json_keys_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "bad.json"
            path.write_text('{"id":"a","id":"b"}')
            with self.assertRaisesRegex(ValueError, "duplicate JSON key"):
                lm.load_json(path)

    @unittest.skipUnless(shutil.which("dot"), "Graphviz unavailable")
    def test_real_svg_four_input_gate_or_and_visible_edges(self):
        data = example()
        for view in data["views"]:
            root = ET.fromstring(render_svg(render_dot(data, view), view["id"]))
            edges = set()
            for group in root.iter():
                if group.get("class") == "edge":
                    title = next((el.text for el in group if el.tag.endswith("}title")), None)
                    edges.add(title)
            relation_map = {r["id"]: r for r in data["relations"]}
            active_routes = set(view["relationIds"]) & set(data["alternatives"][0]["relations"])
            expected = set()
            for rid in view["relationIds"]:
                relation = relation_map[rid]
                for node in relation["from"]:
                    expected.add(f"n-{node}->r-{rid}")
                target = "o-iso-alternatives" if rid in active_routes and len(active_routes) >= 2 else "n-" + relation["to"]
                expected.add(f"r-{rid}->{target}")
            if len(active_routes) >= 2:
                expected.add("o-iso-alternatives->n-isomorphism")
            self.assertEqual(edges, expected)
            self.assertEqual({edge.split("->")[0] for edge in edges if edge.endswith("->r-inverse-route")},
                             {"n-groups", "n-hom", "n-injective", "n-surjective"})
            self.assertNotIn("r-inverse-route->n-isomorphism", edges)

    @unittest.skipUnless(shutil.which("dot"), "Graphviz unavailable")
    def test_html_has_unique_ids_full_conditions_and_safe_literal_text(self):
        data = example()
        condition = 'Work with the fixed map f; retain all original tests <eta> and "both" directions.'
        data["relations"][2].update(kind="conditional-implication", conditions=[condition])
        data["nodes"][0]["label"] = '<img src=x onerror="alert(1)">'
        rendered = [(view, render_svg(render_dot(data, view), view["id"])) for view in data["views"]]
        page = render_html(data, rendered)
        markup = Markup(page)
        self.assertEqual(len(markup.ids), len(set(markup.ids)))
        self.assertTrue(set(markup.fragments) <= set(markup.ids), set(markup.fragments) - set(markup.ids))
        self.assertEqual(markup.tags.count("script"), 1)
        self.assertNotIn("img", markup.tags)
        self.assertIn("retain all original tests &lt;eta&gt;", page)
        for premise in ("groups", "hom", "injective", "surjective"):
            self.assertIn("#node-" + premise, page)

    @unittest.skipUnless(shutil.which("dot"), "Graphviz unavailable")
    def test_render_verify_reject_graph_source_renderer_and_svg_drift(self):
        data = example()
        with tempfile.TemporaryDirectory() as temp:
            temp = Path(temp)
            source = temp / "logic-map-example.md"
            shutil.copyfile(ROOT / "assets/logic-map-example.md", source)
            out = temp / "output"
            lm.render(data, out, temp)
            self.assertTrue(lm.verify(data, out, temp)["verified"])
            self.assertIn('href="index.html#node-groups"', (out / "complete.svg").read_text())
            changed = copy.deepcopy(data)
            changed["relations"][1]["from"].remove("surjective")
            with self.assertRaisesRegex(ValueError, "graph or version changed"):
                lm.verify(changed, out, temp)
            with patch.object(lm, "generator_hash", return_value="0" * 64):
                with self.assertRaisesRegex(ValueError, "renderer or validator changed"):
                    lm.verify(data, out, temp)
            original = source.read_bytes()
            source.write_bytes(original + b"\nDifferent source.")
            with self.assertRaisesRegex(ValueError, "source bytes changed"):
                lm.verify(data, out, temp)
            source.write_bytes(original)
            (out / "complete.svg").write_text("<svg/>")
            with self.assertRaisesRegex(ValueError, "changed artifact: complete.svg"):
                lm.verify(data, out, temp)
            with self.assertRaisesRegex(ValueError, "output already exists"):
                lm.render(data, out, temp)

    def test_cli_failure_code_is_actionable(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "invalid.json"
            data = example()
            data["views"][0]["nodeIds"].remove("surjective")
            path.write_text(json.dumps(data))
            result = subprocess.run([sys.executable, str(SCRIPTS / "logic_map.py"),
                                     "validate", str(path), "--source-root", str(ROOT / "assets")],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 1)
            self.assertIn("hides a premise", result.stdout)


if __name__ == "__main__":
    unittest.main()
