"""Task state, event durability, ownership, and evidence regression tests."""
from copy import deepcopy
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.project import ingest, resolve_item, set_foundation
from mathproj.store import ProjectError, ProjectStore
from mathproj.sources import cite_source, register_source, retire_citation
from mathproj.tasks import (add_task, checkpoint_task, claim_task, list_tasks, resume_task,
                            set_task_dependencies, task_context, transition_task)


SOURCE = r"""\begin{lemma}\label{base}
Base statement.
\end{lemma}
\begin{proof}
Base calculation.
\end{proof}
\begin{lemma}\label{consumer}
Consumer statement.
\end{lemma}
\begin{proof}
Apply \ref{base}.
\end{proof}
\begin{lemma}\label{unrelated}
Unrelated statement.
\end{lemma}
\begin{proof}
An independent calculation.
\end{proof}
"""


def acceptance():
    return {"kind": "acceptance", "outcome": "satisfied",
            "summary": "The requested dependency audit is recorded and its identified cases were examined."}


def evidence():
    return [{"kind": "analysis", "summary": "Examined the target and its imported prerequisites.",
             "findings": ["The references remain explicitly attributable."]}, acceptance()]


def _compete_for_claim(root, task_id, worker, barrier, queue):
    try:
        barrier.wait(timeout=10)
        result = claim_task(ProjectStore(root), task_id, worker, expected_revision=1)
        queue.put(("claimed", result["task"]["assignee"]))
    except ProjectError as exc:
        queue.put(("rejected", str(exc)))


class TaskTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Task test project", namespace="TEST")
        self.source = self.root / "content" / "main.tex"
        self.source.write_text(SOURCE, encoding="utf-8")
        ingest(self.store)
        state = self.store.state()
        self.base = resolve_item(state, "base")
        self.consumer = resolve_item(state, "consumer")
        self.unrelated = resolve_item(state, "unrelated")

    def tearDown(self):
        self.temp.cleanup()

    def add(self, identifier="audit", **kwargs):
        return add_task(self.store, "Audit the dependency use", acceptance="Record the findings and check each cited input.",
                        target_ids=kwargs.pop("target_ids", [self.consumer]), task_id=identifier, **kwargs)

    def checkpoint(self, identifier="audit", **kwargs):
        return checkpoint_task(self.store, identifier, kwargs.pop("assignee", "worker-a"),
                               evidence=kwargs.pop("evidence", evidence()),
                               next_step="Submit the completed audit for acceptance.", **kwargs)

    def prepare(self, identifier="audit", **kwargs):
        self.add(identifier, **kwargs)
        claim_task(self.store, identifier, "worker-a")
        return self.checkpoint(identifier)

    def change_source(self, before, after):
        self.source.write_text(self.source.read_text(encoding="utf-8").replace(before, after), encoding="utf-8")
        return ingest(self.store)

    def register_reference(self, key="reference", *, previous_revision=None, version="1"):
        record = {"title": "Fixture reference", "uri": "https://example.test/reference", "version": version}
        if previous_revision is not None:
            record["previous_revision"] = previous_revision
        return register_source(self.store, key, record)["source"]

    def cite_reference(self, item_id, source, *, proof_id=None):
        state = self.store.state()
        record = {"citation_key": "fixture-use", "source_revision": source["revision"],
                  "declaration_revision": state["items"][item_id]["declaration_revision"]}
        if proof_id is not None:
            record.update(proof_id=proof_id, proof_revision=state["proofs"][proof_id]["revision"])
        return cite_source(self.store, item_id, source["key"], record)["citation"]

    def assert_rejected_without_event(self, callback, pattern=None):
        before = self.store.state()
        events = len(self.store.history())
        with self.assertRaisesRegex(ProjectError, pattern or ".+"):
            callback()
        self.assertEqual(before, self.store.state())
        self.assertEqual(events, len(self.store.history()))

    def test_lifecycle_and_no_automatic_mathematical_certification(self):
        created = self.add()
        self.assertEqual(created["revision"], 1)
        self.assertTrue(created["runnable"])
        claim_task(self.store, "audit", "worker-a", expected_revision=1)
        self.checkpoint()
        transition_task(self.store, "audit", "review", assignee="worker-a")
        before = self.store.state()
        result = transition_task(self.store, "audit", "done", assignee="worker-a")
        self.assertEqual(result["task"]["status"], "done")
        self.assertEqual(result["task"]["completion"]["verification_scope"], "task_acceptance_only")
        after = self.store.state()
        for collection in ("items", "proofs", "reviews", "foundations", "applications"):
            self.assertEqual(before[collection], after[collection])
        self.assert_rejected_without_event(lambda: resume_task(self.store, "audit", "worker-a"), "Closed")

    def test_dependency_completion_atomically_releases_only_dependency_blocks(self):
        self.add("first")
        second = self.add("second", dependencies=["first"])
        self.assertEqual(second["task"]["status"], "blocked")
        self.add("manual")
        transition_task(self.store, "manual", "blocked", reason="A question remains unresolved.")
        set_task_dependencies(self.store, "manual", ["first"])
        self.assert_rejected_without_event(lambda: claim_task(self.store, "second", "worker-a"))
        claim_task(self.store, "first", "worker-a")
        self.checkpoint("first")
        result = transition_task(self.store, "first", "done")
        self.assertEqual(result["released_tasks"], ["second"])
        state, events = self.store.replay()
        self.assertEqual(state["tasks"]["second"]["status"], "ready")
        self.assertEqual(state["tasks"]["manual"]["status"], "blocked")
        changed_tasks = {entry["path"][1] for entry in events[-1]["patch"] if entry["path"][0] == "tasks"}
        self.assertEqual(changed_tasks, {"first", "second"})

    def test_missing_and_cyclic_dependencies_are_rejected_transactionally(self):
        self.assert_rejected_without_event(lambda: self.add(dependencies=["missing"]), "missing")
        self.assert_rejected_without_event(lambda: self.add(dependencies=["audit"]), "Cyclic")
        self.add("first")
        self.add("second", dependencies=["first"])
        self.assert_rejected_without_event(lambda: set_task_dependencies(self.store, "first", ["second"]), "first.*second.*first")
        self.assert_rejected_without_event(lambda: set_task_dependencies(self.store, "first", ["missing"]), "missing")

    def test_long_dependency_cycle_avoids_python_recursion(self):
        count = 10_000
        def seed(state):
            for index in range(count):
                task_id = f"long-{index:05d}"
                state["tasks"][task_id] = {"id": task_id, "status": "ready", "revision": 0,
                    "dependencies": [f"long-{index-1:05d}"] if index else []}
        self.store.transact("test_seed_long_queue", seed)
        with self.assertRaisesRegex(ProjectError, "Cyclic"):
            set_task_dependencies(self.store, "long-00000", [f"long-{count-1:05d}"])
        self.assertEqual(self.store.state()["tasks"]["long-00000"]["dependencies"], [])

    def test_cancelled_prerequisite_remains_unresolved(self):
        self.add("first")
        self.add("second", dependencies=["first"])
        transition_task(self.store, "first", "cancelled", reason="This proposed approach was withdrawn.")
        self.assertEqual(task_context(self.store, "second")["unresolved_dependencies"], [{"id": "first", "status": "cancelled"}])
        self.assert_rejected_without_event(lambda: resume_task(self.store, "second", "worker-a"), "unresolved")

    def test_claim_requires_ownership_and_optimistic_revision(self):
        self.add()
        claim_task(self.store, "audit", "worker-a", expected_revision=1)
        self.assert_rejected_without_event(lambda: self.checkpoint(assignee="worker-b"), "assigned")
        self.assert_rejected_without_event(lambda: self.checkpoint(expected_revision=1), "changed")
        self.assert_rejected_without_event(lambda: claim_task(self.store, "audit", "worker-b"), "not ready")

    def test_two_processes_cannot_both_claim_the_same_revision(self):
        self.add()
        context = multiprocessing.get_context("fork")
        barrier, queue = context.Barrier(2), context.Queue()
        processes = [context.Process(target=_compete_for_claim,
                     args=(str(self.root), "audit", worker, barrier, queue)) for worker in ("worker-a", "worker-b")]
        for process in processes:
            process.start()
        for process in processes:
            process.join(timeout=15)
            if process.is_alive():
                process.terminate()
                process.join()
                self.fail("Concurrent claim process did not finish")
            self.assertEqual(process.exitcode, 0)
        results = [queue.get(timeout=2) for _ in processes]
        self.assertEqual(sorted(result[0] for result in results), ["claimed", "rejected"])
        winner = next(result[1] for result in results if result[0] == "claimed")
        self.assertEqual(self.store.state()["tasks"]["audit"]["assignee"], winner)
        self.assertEqual(sum(event["operation"] == "task_claim" for event in self.store.history()), 1)
        queue.close()

    def test_explicit_handoff_preserves_checkpoint_history(self):
        self.prepare()
        old_checkpoint = deepcopy(self.store.state()["tasks"]["audit"]["checkpoints"])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "ready"), "reason")
        transition_task(self.store, "audit", "ready", assignee="worker-a", reason="The next worker will continue from the checkpoint.")
        resumed = resume_task(self.store, "audit", "worker-b")
        self.assertEqual(resumed["task"]["assignee"], "worker-b")
        self.assertEqual(resumed["task"]["checkpoints"], old_checkpoint)
        self.assertIn("Submit", resumed["next_step"])

    def test_time_or_progress_is_not_completion_evidence(self):
        self.add()
        claim_task(self.store, "audit", "worker-a")
        self.checkpoint(evidence=[{"kind": "elapsed_time", "summary": "Worked for 10800 seconds.", "seconds": 10800}, acceptance()])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "elapsed time")
        self.checkpoint(evidence=[{"kind": "analysis", "summary": "The cases were examined."}])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "acceptance")
        self.checkpoint()
        self.assertEqual(transition_task(self.store, "audit", "done")["task"]["status"], "done")

    def test_no_checkpoint_or_latest_progress_only_cannot_finish(self):
        self.add()
        claim_task(self.store, "audit", "worker-a")
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "checkpoint")
        self.checkpoint()
        self.checkpoint(evidence=[{"kind": "progress", "summary": "Some further work remains."}])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "acceptance")

    def test_evidence_is_structured_finite_and_copied(self):
        self.add()
        claim_task(self.store, "audit", "worker-a")
        for bad in (["narrative"], [{"kind": "test"}], [{"kind": "test", "summary": "NaN", "value": float("nan")}], "text"):
            self.assert_rejected_without_event(lambda bad=bad: self.checkpoint(evidence=bad))
        records = evidence()
        self.checkpoint(evidence=records)
        records[0]["findings"].append("A later mutation must not rewrite the event.")
        self.assertEqual(len(self.store.state()["tasks"]["audit"]["checkpoints"][0]["evidence"][0]["findings"]), 1)

    def test_artifact_hash_and_acceptance_can_support_completion(self):
        self.add()
        claim_task(self.store, "audit", "worker-a")
        artifact = self.root / "audit.txt"
        artifact.write_bytes(b"Concrete dependency audit.\n")
        result = self.checkpoint(evidence=[acceptance()], artifacts=["audit.txt"])
        record = result["latest_checkpoint"]["artifacts"][0]
        self.assertEqual(record, {"path": "audit.txt", "size": 27,
                                 "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest()})
        self.assertEqual(result["artifacts"][0]["status"], "current")
        transition_task(self.store, "audit", "done")

    def test_artifact_modification_and_missing_files_block_completion(self):
        self.add()
        claim_task(self.store, "audit", "worker-a")
        artifact = self.root / "audit.txt"
        artifact.write_text("Original findings.", encoding="utf-8")
        self.checkpoint(artifacts=["audit.txt"])
        artifact.write_text("Revised findings.", encoding="utf-8")
        self.assertEqual(task_context(self.store, "audit")["artifacts"][0]["status"], "changed")
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "artifacts changed")
        artifact.unlink()
        self.assertEqual(task_context(self.store, "audit")["artifacts"][0]["status"], "unavailable")
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "unavailable")
        artifact.write_text("Final findings.", encoding="utf-8")
        self.checkpoint(artifacts=["audit.txt"])
        transition_task(self.store, "audit", "done")

    def test_artifact_paths_cannot_escape_follow_symlinks_or_block_on_special_files(self):
        self.add()
        claim_task(self.store, "audit", "worker-a")
        (self.root / "real.txt").write_text("Evidence", encoding="utf-8")
        (self.root / "link.txt").symlink_to("real.txt")
        (self.root / "linked-content").symlink_to("content", target_is_directory=True)
        os.mkfifo(self.root / "pipe")
        unsafe = ["../outside", str(self.root / "real.txt"), "link.txt", "linked-content/main.tex", "pipe", "content", "."]
        for path in unsafe:
            with self.subTest(path=path):
                self.assert_rejected_without_event(lambda path=path: self.checkpoint(artifacts=[path]))

    def test_recovery_rebuilds_queue_and_preserves_interrupted_tail(self):
        self.prepare()
        expected = self.store.state()["tasks"]
        self.store.state_path.write_text('{"tasks":{}}', encoding="utf-8")
        self.assertEqual(self.store.state()["tasks"], expected)
        self.store.state_path.unlink()
        with self.store.events.open("ab") as output:
            output.write(b'{"interrupted":')
        recovered = self.store.recover()
        self.assertTrue(recovered["recovered"])
        self.assertEqual(self.store.state()["tasks"], expected)
        preserved = list(self.store.meta.glob("incomplete-tail-*.bin"))
        self.assertEqual(len(preserved), 1)
        self.assertEqual(preserved[0].read_bytes(), b'{"interrupted":')
        resumed = resume_task(self.store, "audit", "worker-a")
        self.assertEqual(resumed["latest_checkpoint"]["evidence"], evidence())

    def test_resume_reports_stale_upstream_without_discarding_work(self):
        self.prepare()
        checkpoints = deepcopy(self.store.state()["tasks"]["audit"]["checkpoints"])
        self.change_source("Base statement.", "Changed base statement.")
        resumed = resume_task(self.store, "audit", "worker-a")
        self.assertTrue(resumed["basis"]["snapshot_changed"])
        self.assertIn(self.base, resumed["basis"]["changed_inputs"])
        self.assertIn(self.consumer, resumed["basis"]["impacted_targets"])
        self.assertEqual(resumed["task"]["checkpoints"], checkpoints)
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "changed relevant inputs")
        self.checkpoint()
        self.assertFalse(task_context(self.store, "audit")["basis"]["relevant_changes"])
        transition_task(self.store, "audit", "done")

    def test_unrelated_import_warns_but_does_not_invalidate_target_evidence(self):
        self.prepare()
        self.change_source("Unrelated statement.", "Changed unrelated statement.")
        report = task_context(self.store, "audit")
        self.assertTrue(report["basis"]["snapshot_changed"])
        self.assertFalse(report["basis"]["relevant_changes"])
        self.assertEqual(report["basis"]["impacted_targets"], [])
        transition_task(self.store, "audit", "done")

    def test_unimported_changes_warn_on_resume_and_block_completion(self):
        self.prepare()
        self.source.write_text(SOURCE.replace("Base statement.", "An unimported edit."), encoding="utf-8")
        result = resume_task(self.store, "audit", "worker-a")
        self.assertFalse(result["source_freshness"]["fresh"])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "Import current")

    def test_explicit_acknowledgment_requires_exact_inputs_and_reason(self):
        self.prepare()
        self.change_source("Base statement.", "Changed base statement.")
        required = task_context(self.store, "audit")["basis"]["required_acknowledgments"]
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done", acknowledge_changes=required), "reason")
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done", acknowledge_changes=["unknown"], reason="Examined the edits."), "Unknown")
        result = transition_task(self.store, "audit", "done", acknowledge_changes=required,
                                 reason="Compared the revised premise with each recorded application; the audit conclusions remain applicable.")
        self.assertEqual(result["task"]["completion"]["acknowledged_changes"], required)
        self.assertTrue(result["basis"]["relevant_changes"])  # Preserve the stale historical basis.

    def test_metadata_changes_are_detected_without_a_new_snapshot(self):
        self.prepare()
        set_foundation(self.store, self.base, "Admitted solely as an explicit input in this fixture.", kind="assumption")
        context = task_context(self.store, "audit")
        self.assertFalse(context["basis"]["snapshot_changed"])
        self.assertIn(self.base, context["basis"]["changed_inputs"])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "changed relevant inputs")
        self.checkpoint()
        transition_task(self.store, "audit", "done")

    def test_nested_review_bindings_are_part_of_checkpoint_inputs(self):
        self.prepare()
        self.store.transact("test_record_review", lambda state: state["reviews"].update({
            "fixture-review": {"id": "fixture-review", "binding": {"item_id": self.base},
                               "verdict": "changes_required", "summary": "A premise needs another examination."}}))
        report = task_context(self.store, "audit")
        self.assertIn(self.base, report["basis"]["changed_inputs"])
        self.assertIn(self.consumer, report["basis"]["impacted_targets"])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "changed relevant inputs")

    def test_source_update_invalidates_upstream_item_citation_without_rewriting_it(self):
        source = self.register_reference()
        citation = self.cite_reference(self.base, source)
        self.prepare()
        self.register_reference(previous_revision=source["revision"], version="2")
        self.assertEqual(self.store.state()["citations"][citation["id"]], citation)
        report = task_context(self.store, "audit")
        self.assertFalse(report["basis"]["snapshot_changed"])
        self.assertIn(self.base, report["basis"]["changed_inputs"])
        self.assertIn(self.consumer, report["basis"]["impacted_targets"])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "changed relevant inputs")

    def test_source_update_invalidates_proof_specific_citation(self):
        source = self.register_reference()
        proof_id = self.store.state()["items"][self.consumer]["proof_ids"][0]
        citation = self.cite_reference(self.consumer, source, proof_id=proof_id)
        self.prepare()
        self.register_reference(previous_revision=source["revision"], version="2")
        self.assertEqual(self.store.state()["citations"][citation["id"]], citation)
        self.assertIn(self.consumer, task_context(self.store, "audit")["basis"]["changed_inputs"])

    def test_uncited_and_out_of_scope_cited_sources_do_not_invalidate_checkpoint(self):
        uncited = self.register_reference("uncited")
        unrelated = self.register_reference("unrelated-reference")
        self.cite_reference(self.unrelated, unrelated)
        self.prepare()
        self.register_reference("uncited", previous_revision=uncited["revision"], version="2")
        self.register_reference("unrelated-reference", previous_revision=unrelated["revision"], version="2")
        self.register_reference("new-uncited-reference")
        report = task_context(self.store, "audit")
        self.assertFalse(report["basis"]["relevant_changes"])
        transition_task(self.store, "audit", "done")

    def test_retiring_a_citation_changes_inputs_but_detaches_future_source_updates(self):
        source = self.register_reference()
        citation = self.cite_reference(self.base, source)
        self.prepare()
        retire_citation(self.store, citation["id"], expected_revision=citation["revision"],
                        reason="This use is no longer part of the audit's source evidence.", reviewer="fixture-reviewer")
        self.assertIn(self.base, task_context(self.store, "audit")["basis"]["changed_inputs"])
        self.checkpoint()
        self.register_reference(previous_revision=source["revision"], version="2")
        self.assertFalse(task_context(self.store, "audit")["basis"]["relevant_changes"])
        transition_task(self.store, "audit", "done")

    def test_adding_a_citation_after_checkpoint_changes_relevant_inputs(self):
        source = self.register_reference()
        self.prepare()
        self.cite_reference(self.base, source)
        report = task_context(self.store, "audit")
        self.assertIn(self.base, report["basis"]["changed_inputs"])
        self.assertIn(self.consumer, report["basis"]["impacted_targets"])

    def test_manifest_change_requires_import_and_explicit_current_evidence(self):
        self.prepare()
        manifest = self.store.manifest()
        manifest["policy"]["require_independent_review"] = False
        self.store.manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        report = task_context(self.store, "audit")
        self.assertTrue(report["basis"]["manifest_changed"])
        self.assertIn("metadata:manifest", report["basis"]["required_acknowledgments"])
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "Import current")
        ingest(self.store)
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "metadata:manifest")
        self.checkpoint()
        transition_task(self.store, "audit", "done")

    def test_removed_edges_keep_the_historical_impact_basis(self):
        self.prepare()
        prior_edges = deepcopy(self.store.state()["tasks"]["audit"]["checkpoints"][-1]["basis"]["edges"])
        self.change_source(r"Apply \ref{base}.", "Use the independent argument instead.")
        context = task_context(self.store, "audit")
        self.assertIn(self.base, context["basis"]["changed_inputs"])
        self.assertIn(self.consumer, context["basis"]["impacted_targets"])
        self.assertEqual(context["latest_checkpoint"]["basis"]["edges"], prior_edges)

    def test_auto_created_recheck_tasks_have_compatible_revision_and_basis(self):
        self.change_source("Base statement.", "A revised base statement.")
        tasks = list_tasks(self.store)
        task = next(entry for entry in tasks if entry["kind"] == "recheck" and self.consumer in entry["target_ids"])
        self.assertEqual(task["revision"], 0)
        result = claim_task(self.store, task["id"], "worker-a", expected_revision=0)
        self.assertEqual(result["revision"], 1)
        self.assertFalse(result["basis"]["relevant_changes"])
        self.checkpoint(task["id"])
        transition_task(self.store, task["id"], "done")

    def test_project_wide_task_detects_any_item_change(self):
        self.prepare(target_ids=[])
        self.change_source("Unrelated statement.", "Changed unrelated statement.")
        report = task_context(self.store, "audit")
        self.assertIn(self.unrelated, report["basis"]["changed_inputs"])

    def test_listing_filters_and_closed_tasks(self):
        self.prepare("completed")
        transition_task(self.store, "completed", "done")
        self.add("ready")
        self.add("assigned")
        claim_task(self.store, "assigned", "worker-b")
        self.assertEqual([entry["id"] for entry in list_tasks(self.store)], ["assigned", "ready"])
        self.assertEqual([entry["id"] for entry in list_tasks(self.store, status="done")], ["completed"])
        self.assertEqual([entry["id"] for entry in list_tasks(self.store, assignee="worker-b")], ["assigned"])
        self.assertEqual(len(list_tasks(self.store, include_closed=True)), 3)

    def test_invalid_inputs_are_not_written(self):
        self.assert_rejected_without_event(lambda: self.add(target_ids=["unknown"]), "Unknown")
        self.assert_rejected_without_event(lambda: add_task(self.store, "", acceptance="Check it."))
        self.add()
        self.assert_rejected_without_event(lambda: self.add(), "already exists")
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "done"), "not allowed")
        self.assert_rejected_without_event(lambda: transition_task(self.store, "audit", "blocked", reason=""), "reason")
        self.assert_rejected_without_event(lambda: self.checkpoint(), "Claim")


if __name__ == "__main__":
    unittest.main()
