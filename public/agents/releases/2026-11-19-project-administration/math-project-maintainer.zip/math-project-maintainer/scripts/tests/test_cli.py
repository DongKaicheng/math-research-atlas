"""Public command-line journeys, including revisions and frozen publication."""
from copy import deepcopy
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.cli import main


TOOL = Path(__file__).resolve().parents[1] / "math_project.py"
TEXT = r"""\begin{lemma}\label{identity}
For every integer $n$, $n+0=n$.
\end{lemma}
\begin{proof}
Zero is the additive identity in the integers.
\end{proof}
"""


class CliJourneys(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "project"
        self.call("init", "--name", "维护实验", "--namespace", "NA")
        self.source = self.root / "content" / "algebra.tex"
        self.source.write_text(TEXT, encoding="utf-8")
        imported = self.call("ingest")
        self.item = imported["added"][0]

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, *arguments, output=None, code=0):
        command = [sys.executable, str(TOOL), "--project", str(self.root)]
        if output:
            command += ["--output", str(output)]
        result = subprocess.run(command+list(arguments), text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, code, result.stdout+result.stderr)
        return json.loads(result.stdout if code == 0 else result.stderr)

    def test_doctor_works_without_project_and_does_not_initialize_one(self):
        absent = Path(self.tmp.name) / "not-a-project"
        command = [sys.executable, str(TOOL), "--project", str(absent), "doctor"]
        result = subprocess.run(command, text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertIsInstance(report["core_ready"], bool)
        self.assertIn("sqlite_fts5", {row["name"] for row in report["checks"]})
        self.assertFalse(absent.exists())

    def test_report_cannot_replace_extensionless_entrypoint_before_a_mutation(self):
        entry = self.root / "entry"
        entry.write_text(TEXT)
        manifest = json.loads((self.root / "mathproject.json").read_text())
        manifest["entrypoints"] = ["entry"]
        (self.root / "mathproject.json").write_text(json.dumps(manifest))
        self.call("ingest")
        before = (self.root / "mpm/events.jsonl").read_bytes()
        self.call("context", "set", "blocked", "--global", "--text", "Must not be recorded", output=entry, code=2)
        self.assertEqual(entry.read_text(), TEXT)
        self.assertEqual((self.root / "mpm/events.jsonl").read_bytes(), before)

    def test_report_cannot_replace_an_imported_non_tex_include(self):
        entry = self.root / "entry"
        entry.write_text("\\input{aux.part}\n")
        auxiliary = self.root / "aux.part"
        auxiliary.write_text(TEXT)
        manifest = json.loads((self.root / "mathproject.json").read_text())
        manifest["entrypoints"] = ["entry"]
        (self.root / "mathproject.json").write_text(json.dumps(manifest))
        self.call("ingest")
        result = self.call("status", output=auxiliary, code=2)
        self.assertIn("imported mathematical source", result["error"])
        self.assertEqual(auxiliary.read_text(), TEXT)

    def test_report_destination_inside_declared_sources_is_rejected(self):
        destination = self.root / "content" / "report.json"
        self.call("status", output=destination, code=2)
        self.assertFalse(destination.exists())

    def payload(self, name, value):
        path = Path(self.tmp.name) / name
        path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
        return str(path)

    def accepted_review(self):
        report = self.call("review", "prepare", self.item)["template"]
        report["reviewer"] = {"id": "CLI-regression-reviewer", "kind": "agent", "independent": True, "author_of_change": False}
        report["verdict"] = "accept"
        report["summary"] = "The standard integer addition law gives the displayed identity for each integer."
        reasoning = {"hypotheses": "The variable is explicitly an integer and the argument uses its ordinary additive group.",
                     "inference": "The defining right identity property is n+0=n, exactly the conclusion.",
                     "scope": "The claim quantifies over every integer and uses no finiteness or positivity restriction.",
                     "constructions": "No new construction or representative choice is introduced.",
                     "citations": "There are no source references; this fixture uses the stated elementary identity axiom directly."}
        for check in report["checks"]:
            check.update(status="pass", reason=reasoning[check["name"]])
        return report

    def test_review_release_context_change_and_historical_export(self):
        report = self.accepted_review()
        saved = self.call("review", "record", "--file", self.payload("review.json", report))
        self.assertEqual(saved["review"]["verdict"], "accept")
        self.assertEqual(self.call("support", self.item)["requested_supported"], [self.item])
        release = self.call("release", "create", "v1", "--target", self.item)
        self.assertEqual(release["included"], [self.item])
        first = self.call("export", "--destination", "exports/first", "--mode", "reviewed", "--release", "v1")
        self.assertTrue(Path(first["index"]).is_file())
        self.call("context", "set", "integers", "--global", "--text", "All integer symbols denote the ordinary additive group Z.")
        self.assertFalse(self.call("status")["freshness"]["fresh"])
        self.call("ingest")
        self.assertEqual(self.call("support", self.item)["requested_blocked"], [self.item])
        second = self.call("export", "--destination", "exports/second", "--mode", "reviewed", "--release", "v1")
        self.assertEqual(Path(first["index"]).read_bytes(), Path(second["index"]).read_bytes())

    def test_task_claim_checkpoint_completion_with_integer_revision(self):
        created = self.call("task", "add", "--title", "Inspect the identity", "--target", self.item,
                            "--acceptance", "Inspect the exact statement and provide a recorded explanation.")
        task = created["task"]
        claimed = self.call("task", "claim", task["id"], "--assignee", "worker", "--expected-revision", str(task["revision"]))
        checkpoint = {"summary": "Inspected the exact identity statement.", "next_step": "Record that the inspection task is complete.",
                      "artifacts": ["content/algebra.tex"], "evidence": [
                          {"kind": "analysis", "summary": "The conclusion is the right identity axiom for integer addition."},
                          {"kind": "acceptance", "outcome": "satisfied", "summary": "The displayed statement and its elementary justification have been inspected."}]}
        checked = self.call("task", "checkpoint", task["id"], "--assignee", "worker", "--file", self.payload("checkpoint.json", checkpoint),
                            "--expected-revision", str(claimed["revision"]))
        finished = self.call("task", "transition", task["id"], "done", "--assignee", "worker", "--expected-revision", str(checked["revision"]))
        self.assertEqual(finished["task"]["status"], "done")
        self.assertEqual(self.call("support", self.item)["grounded"], [])

    def test_source_change_roundtrip_and_stale_packet(self):
        review = self.accepted_review()
        status = self.call("status")
        new_text = TEXT.replace("Zero is the additive identity in the integers.", "The additive group axiom for the usual integers gives $n+0=n$.")
        proposal = {"title": "写明所用公理", "author": "作者", "rationale": "Make the exact identity axiom visible in the proof.",
                    "base_snapshot": status["snapshot"], "targets": [self.item], "edits": [
                        {"path": "content/algebra.tex", "before_sha256": hashlib.sha256(self.source.read_bytes()).hexdigest(), "content": new_text}]}
        prepared = self.call("change", "prepare", "--file", self.payload("proposal.json", proposal))["proposal"]
        self.assertEqual(self.source.read_text(), TEXT)
        applied = self.call("change", "apply", prepared["id"])
        self.assertEqual(applied["import"]["changed"], [self.item])
        self.assertEqual(self.source.read_text(), new_text)
        error = self.call("review", "record", "--file", self.payload("old-review.json", review), code=2)
        self.assertIn("stale", error["error"])

    def test_json_output_guard_happens_before_mutating_command(self):
        original = (self.root / "mathproject.json").read_bytes()
        error = self.call("context", "set", "bad-output", "--global", "--text", "An attempted context.",
                          output=self.root / "mathproject.json", code=2)
        self.assertIn("must not replace", error["error"])
        self.assertEqual((self.root / "mathproject.json").read_bytes(), original)
        self.assertEqual(self.call("context", "list"), {})

    def test_search_packet_and_cache_recovery_commands(self):
        search = self.call("search", "additive identity")
        self.assertTrue(search["results"])
        packet = self.call("packet", self.item, "--max-chars", "100")
        self.assertEqual(packet["snapshot"], self.call("status")["snapshot"])
        result = self.call("reindex")
        self.assertTrue(result)
        recovered = self.call("recover")
        self.assertTrue(recovered["records"]["recovered"])
        self.assertFalse(recovered["source_changes"]["pending"])

    def test_application_empty_batch_fails_without_state_mutation(self):
        history = self.call("history", "--limit", "100")
        error = self.call("application", "record", "--file", self.payload("empty-apps.json", []), code=2)
        self.assertIn("nonempty", error["error"])
        self.assertEqual(self.call("history", "--limit", "100"), history)

    def test_source_commands_record_candidates_without_claiming_inspection(self):
        content = "Offline regression note about the integer identity."
        source = {"title": "Local identity note", "uri": "urn:sha256:"+hashlib.sha256(content.encode()).hexdigest()}
        saved = self.call("source", "add", "identity-note", "--file", self.payload("source.json", source))
        self.assertEqual(saved["source"]["status"], "candidate")
        self.assertIsNone(saved["source"]["checked_by"])
        self.assertEqual(len(self.call("source", "list")["sources"]), 1)
        self.assertEqual(self.call("source", "audit")["citations"], [])

    def test_stacks_tag_lookup_and_audit_are_read_only_and_do_not_ignore_tags(self):
        registry = Path(self.tmp.name) / "tags"
        registry.write_text("0001,algebra-identity\n0002,missing-result\n")
        before = (self.root / "mpm/events.jsonl").read_bytes()
        found = self.call("stacks-tag", "0001", "--registry", str(registry))
        self.assertEqual(found["results"][0]["item_id"], self.item)
        self.assertFalse(found["provenance"]["mathematical_review_performed"])
        audit = self.call("stacks-tag", "--registry", str(registry), "--audit")
        self.assertEqual(audit["counts"], {"mapped": 1, "unmapped": 1, "ambiguous": 0})
        error = self.call("stacks-tag", "0001", "--registry", str(registry), "--audit", code=2)
        self.assertIn("either", error["error"])
        self.assertEqual((self.root / "mpm/events.jsonl").read_bytes(), before)


class CliReportDestinations(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / "project"
        self.root.mkdir()
        self.entry = self.write("entry.tex", "\\input{notes.part}\n")
        self.source = self.write("notes.part", TEXT)
        self.call("init", "--name", "Report destination regression", "--namespace", "TEST",
                  "--entrypoint", "entry.tex")

    def write(self, path, text):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        return target

    def call(self, *arguments, output=None, code=0):
        command = [sys.executable, str(TOOL), "--project", str(self.root)]
        if output is not None:
            command += ["--output", str(output)]
        result = subprocess.run(command + list(arguments), text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, code, result.stdout + result.stderr)
        return json.loads(result.stdout if code == 0 else result.stderr)

    def assert_report_blocked(self, output, *arguments):
        before_output = output.read_bytes() if output.is_file() else None
        metadata = self.root / "mpm"
        before_records = {path: path.read_bytes() for path in metadata.rglob("*") if path.is_file()}
        before_manifest = (self.root / "mathproject.json").read_bytes()
        result = self.call(*(arguments or ("status",)), output=output, code=2)
        if before_output is None:
            self.assertFalse(output.exists())
        else:
            self.assertEqual(output.read_bytes(), before_output)
        self.assertEqual({path: path.read_bytes() for path in metadata.rglob("*") if path.is_file()}, before_records)
        self.assertEqual((self.root / "mathproject.json").read_bytes(), before_manifest)
        return result

    def assert_fast_status_report(self):
        destination = self.root / "reports/status.json"
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch("mathproj.latex.parse_project", side_effect=AssertionError("Unneeded source parse")), \
             patch("mathproj.store.ProjectStore.snapshot", side_effect=AssertionError("Unneeded snapshot decode")), \
             redirect_stdout(stdout), redirect_stderr(stderr):
            code = main(["--project", str(self.root), "--output", str(destination), "status"])
        self.assertEqual(code, 0, stderr.getvalue())
        result = json.loads(stdout.getvalue())
        self.assertEqual(json.loads(destination.read_text()), result)
        return result

    def interrupt_ledger(self):
        events = self.root / "mpm/events.jsonl"
        before = events.read_bytes()
        fragment = b'{"schema_version":1,"patch":['
        with events.open("ab") as out:
            out.write(fragment)
        return before, fragment

    def test_status_cannot_overwrite_a_preimport_include_without_a_snapshot(self):
        self.assertEqual(list((self.root / "mpm/snapshots").glob("*.json")), [])
        self.assert_report_blocked(self.source, "status")

    def test_ingest_cannot_overwrite_the_source_it_is_about_to_import(self):
        self.assert_report_blocked(self.source, "ingest")

    def test_status_cannot_overwrite_a_newly_reachable_unimported_include(self):
        self.entry.write_text(TEXT)
        self.call("ingest")
        self.entry.write_text("\\input{notes.part}\n")
        cache = json.loads((self.root / "mpm/state.json").read_text())
        self.assertNotIn("notes.part", [source["path"] for source in cache["source_basis"]["files"]])
        self.assert_report_blocked(self.source, "status")

    def test_report_cannot_create_a_missing_literal_include_before_a_mutation(self):
        self.entry.write_text("\\input{missing.part}\n")
        self.assert_report_blocked(self.root / "missing.part", "context", "set", "blocked",
                                   "--global", "--text", "Must not be recorded")

    def test_report_cannot_create_a_missing_including_relative_lookup(self):
        self.entry.write_text("\\input{chapters/entry.tex}\n")
        self.write("chapters/entry.tex", "\\input{missing.part}\n")
        self.assert_report_blocked(self.root / "chapters/missing.part", "context", "set", "blocked",
                                   "--global", "--text", "Must not be recorded")

    def test_report_cannot_create_a_root_first_shadow_of_an_imported_include(self):
        self.entry.write_text("\\input{chapters/entry.tex}\n")
        self.write("chapters/entry.tex", "\\input{notes.part}\n")
        local_source = self.write("chapters/notes.part", TEXT)
        self.source.unlink()
        self.call("ingest")
        self.assert_report_blocked(self.source, "context", "set", "blocked",
                                   "--global", "--text", "Must not be recorded")
        self.assertEqual(local_source.read_text(), TEXT)

    def test_report_cannot_shadow_tex_fallback_with_an_extensionless_file(self):
        self.entry.write_text("\\input{chapters/entry.tex}\n")
        self.write("chapters/entry.tex", "\\input{lemma}\n")
        source = self.write("chapters/lemma.tex", TEXT)
        self.call("ingest")
        for path in ("lemma", "chapters/lemma", "lemma.tex", "chapters/lemma.tex"):
            with self.subTest(path=path):
                self.assert_report_blocked(self.root / path, "context", "set", "blocked",
                                           "--global", "--text", "Must not be recorded")
        self.assertEqual(source.read_text(), TEXT)

    def test_report_reparses_after_manifest_entrypoints_change(self):
        self.call("ingest")
        self.write("other/entry.tex", "\\input{new.part}\n")
        source = self.write("other/new.part", TEXT.replace("identity", "new-identity"))
        manifest_path = self.root / "mathproject.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["entrypoints"] = ["other/entry.tex"]
        manifest_path.write_text(json.dumps(manifest))
        self.assert_report_blocked(source, "context", "set", "blocked", "--global", "--text", "Blocked")

    def test_report_cannot_replace_an_imported_source_after_its_include_is_removed(self):
        self.call("ingest")
        self.entry.write_text(TEXT)
        self.assert_report_blocked(self.source, "context", "set", "blocked", "--global", "--text", "Blocked")

    def test_report_does_not_trust_disposable_state_cache_for_source_membership(self):
        self.call("ingest")
        cache_path = self.root / "mpm/state.json"
        cache = json.loads(cache_path.read_text())
        cache["source_basis"]["files"] = []
        cache["source_basis"]["source_layout"]["lookups"] = []
        cache["current_snapshot"] = None
        cache_path.write_text(json.dumps(cache))
        self.assert_report_blocked(self.source, "context", "set", "blocked", "--global", "--text", "Blocked")

    def test_preimport_status_report_succeeds_outside_source_lookup_paths(self):
        destination = self.root / "reports/status.json"
        result = self.call("status", output=destination)
        self.assertEqual(json.loads(destination.read_text()), result)
        self.assertIsNone(result["snapshot"])
        self.assertEqual(self.source.read_text(), TEXT)

    def test_clean_status_report_reuses_validated_import_without_reparsing(self):
        self.call("ingest")
        self.assertTrue(self.assert_fast_status_report()["freshness"]["fresh"])

    def test_context_only_changes_do_not_force_report_reparse(self):
        self.call("ingest")
        self.call("context", "set", "integers", "--global", "--text", "Integers have their usual addition.")
        result = self.assert_fast_status_report()
        self.assertEqual(result["freshness"]["reasons"], [{"kind": "contexts_changed"}])

    def test_existing_parse_errors_do_not_force_report_reparse(self):
        self.source.write_text("\\begin{proof}Unattached proof.\\end{proof}\n")
        self.call("ingest", "--allow-incomplete")
        result = self.assert_fast_status_report()
        self.assertTrue(any(reason["kind"] == "parse_error" for reason in result["freshness"]["reasons"]))

    def test_report_checks_lookup_paths_in_an_unchanged_incomplete_import(self):
        self.entry.write_text("\\input{notes.part}\n\\input{missing.part}\n")
        self.call("ingest", "--allow-incomplete")
        self.assert_report_blocked(self.root / "missing.part", "context", "set", "blocked",
                                   "--global", "--text", "Must not be recorded")

    def test_report_reparses_when_a_previously_unreadable_include_becomes_readable(self):
        self.source.write_bytes(b"\xff")
        self.call("ingest", "--allow-incomplete")
        self.source.write_text("\\input{new.part}\n")
        source = self.write("new.part", TEXT)
        self.assert_report_blocked(source, "context", "set", "blocked", "--global", "--text", "Blocked")

    def test_report_reparses_when_an_unreadable_source_root_file_becomes_readable(self):
        manifest_path = self.root / "mathproject.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["entrypoints"] = []
        manifest_path.write_text(json.dumps(manifest))
        discovered = self.root / "content/unreadable.tex"
        discovered.write_bytes(b"\xff")
        self.call("ingest", "--allow-incomplete")
        discovered.write_text("\\input{new.part}\n")
        source = self.write("new.part", TEXT)
        self.assert_report_blocked(source, "context", "set", "blocked", "--global", "--text", "Blocked")

    def test_report_cannot_create_the_project_root_or_metadata_before_init(self):
        for name, suffix in (("absent-root", ""), ("absent-metadata", "mpm")):
            with self.subTest(destination=name):
                self.root = Path(self.tmp.name) / name
                destination = self.root / suffix
                self.call("init", "--name", "Must not initialize", output=destination, code=2)
                self.assertFalse(self.root.exists())

    def test_recover_can_write_a_report_after_preserving_an_interrupted_tail(self):
        self.call("ingest")
        before, fragment = self.interrupt_ledger()
        destination = self.root / "reports/recovery.json"
        result = self.call("recover", output=destination)
        self.assertTrue(result["records"]["recovered"])
        self.assertEqual(json.loads(destination.read_text()), result)
        self.assertEqual((self.root / "mpm/events.jsonl").read_bytes(), before)
        tails = list((self.root / "mpm").glob("incomplete-tail-*.bin"))
        self.assertEqual(len(tails), 1)
        self.assertEqual(tails[0].read_bytes(), fragment)
        self.assertEqual(self.source.read_text(), TEXT)

    def test_recover_report_cannot_replace_current_source_before_any_repair(self):
        self.interrupt_ledger()
        self.assert_report_blocked(self.source, "recover")

    def test_recover_report_cannot_replace_historical_source_before_any_repair(self):
        self.call("ingest")
        self.entry.write_text(TEXT)
        self.interrupt_ledger()
        self.assert_report_blocked(self.source, "recover")

    def test_recover_report_does_not_bypass_a_corrupt_complete_event(self):
        self.call("ingest")
        with (self.root / "mpm/events.jsonl").open("ab") as out:
            out.write(b'{"schema_version":1,"patch":[]}\n')
        result = self.assert_report_blocked(self.root / "reports/recovery.json", "recover")
        self.assertIn("event", result["error"].lower())


if __name__ == "__main__":
    unittest.main()
