"""Behavioral tests of the non-executing mathematical LaTeX reader."""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.latex import parse_project


FIXTURES = Path(__file__).parent / "fixtures" / "reader"


class ReaderCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def write(self, name, text):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(text, bytes):
            path.write_bytes(text)
        else:
            path.write_text(text, encoding="utf-8")
        return path

    def parse(self, text, **kwargs):
        self.write("chapter.tex", text)
        return parse_project(self.root, **kwargs)

    def by_label(self, result):
        return {item["label"]: item for item in result["items"]}

    def codes(self, result):
        return {diagnostic["code"] for diagnostic in result["diagnostics"]}

    def assertNoErrors(self, result):
        self.assertEqual([], [d for d in result["diagnostics"] if d["severity"] == "error"])

    def test_mini_stacks_fixture(self):
        result = parse_project(FIXTURES / "mini_stacks", ["main.tex"])
        self.assertNoErrors(result)
        self.assertEqual([], result["diagnostics"])
        self.assertEqual(["main.tex", "algebra.tex", "geometry.tex"], [f["path"] for f in result["files"]])
        items = self.by_label(result)
        self.assertEqual(7, len(items))
        self.assertEqual("DEFMODULE", items["definition-module"]["explicit_id"])
        self.assertEqual(["Modules"], items["lemma-identity"]["section"])
        self.assertEqual("Identity", items["lemma-identity"]["title"])
        self.assertNotIn(r"\label", items["lemma-identity"]["statement"])
        refs = items["lemma-application"]["proofs"][0]["references"]
        self.assertEqual(["algebra.tex::lemma-identity", "algebra.tex::lemma-identity", "algebra.tex::equation-addition"], [ref["target_key"] for ref in refs])
        self.assertEqual("item-identity", refs[1]["target_clause"])
        self.assertTrue(all(ref["role"] == "proof" for ref in refs))
        self.assertEqual("section", items["section-modules"]["kind"])
        self.assertEqual("equation", items["equation-addition"]["kind"])
        json.dumps(result)

    def test_original_source_hash_and_tex_preserved(self):
        text = "\\begin{lemma}\n\\label{a}\n未知 \\mymacro{\\alpha}_{i} % a comment\n\\end{lemma}\n"
        result = self.parse(text)
        self.assertEqual(text, result["files"][0]["text"])
        self.assertEqual(sha256(text.encode()).hexdigest(), result["files"][0]["sha256"])
        self.assertEqual("未知 \\mymacro{\\alpha}_{i} % a comment", result["items"][0]["statement"])
        self.assertEqual({"path": "chapter.tex", "start_line": 1, "end_line": 4}, result["items"][0]["source"])

    def test_explicit_id_comes_only_from_comments(self):
        result = self.parse(r"""\begin{lemma}\label{a}
mpm:id=NOTMETADATA. \% mpm:id=ALSONOT.
% mpm:id=REAL-ID_1
Text. % ordinary comment
\end{lemma}
""")
        item = result["items"][0]
        self.assertEqual("REAL-ID_1", item["explicit_id"])
        self.assertIn("NOTMETADATA", item["statement"])
        self.assertIn("ALSONOT", item["statement"])
        self.assertNotIn("REAL-ID_1", item["statement"])
        self.assertIn("ordinary comment", item["statement"])

    def test_conflicting_permanent_ids(self):
        result = self.parse("\\begin{lemma}\\label{a}\n% mpm:id=A\n% mpm:id=B\nX.\\end{lemma}")
        self.assertIn("conflicting_explicit_ids", self.codes(result))
        self.assertIsNone(result["items"][0]["explicit_id"])

    def test_comments_cannot_create_items_or_references(self):
        result = self.parse(r"""% \begin{lemma}\label{fake}\end{lemma}
\begin{lemma}\label{a}
Text. % \ref{missing}
\end{lemma}
% \input{missing}
""")
        self.assertEqual(["a"], [i["label"] for i in result["items"]])
        self.assertEqual([], result["items"][0]["references"])
        self.assertEqual([], result["diagnostics"])

    def test_escaped_percent_and_linebreak_before_comment(self):
        result = self.parse(r"""\begin{lemma}\label{a}
10\% and \ref{a}.\\% \ref{missing}
\end{lemma}
""")
        self.assertEqual(["a"], [r["label"] for r in result["items"][0]["references"]])
        self.assertNotIn("unresolved_reference", self.codes(result))

    def test_verbatim_regions_and_literal_arguments_are_not_scanned(self):
        result = self.parse(r"""\begin{verbatim}
\begin{lemma}\label{fake}\end{lemma}
\input{missing}
\end{verbatim}
\begin{minted}{latex}
\begin{lemma}\label{fake2}\end{lemma}
\end{minted}
\verb|\begin{lemma}\label{fake3}\end{lemma}|
\begin{lemma}\label{a}
\verb*+\ref{missing}+ \url{https://site/\ref{missing}}
\href{https://site/\ref{missing}}{visible \ref{a}}
\detokenize{\label{not-a-label}}
\end{lemma}
""")
        self.assertEqual(["a"], [i["label"] for i in result["items"]])
        self.assertEqual(["a"], [r["label"] for r in result["items"][0]["references"]])
        self.assertEqual([], result["diagnostics"])

    def test_unterminated_verbatim_is_explicit(self):
        result = self.parse("\\verb|unfinished\n\\begin{lemma}\\label{a}X.\\end{lemma}")
        self.assertIn("unterminated_verbatim", self.codes(result))
        self.assertEqual(["a"], [i["label"] for i in result["items"]])
        result = self.parse("\\begin{verbatim}\n\\begin{lemma}\\label{fake}X.\\end{lemma}")
        self.assertIn("unterminated_literal_environment", self.codes(result))
        self.assertEqual([], result["items"])

    def test_declared_theorem_environments_and_nested_title_braces(self):
        result = self.parse(r"""\newtheorem{axiom}{Assumption}
\newtheorem{mylemma}[axiom]{Lemma}
\newtheorem*{myremark}{Remark}
\begin{axiom}\label{a}Given.\end{axiom}
\begin{mylemma}[A title with {$[0,1]$} and {\bf text}]\label{b}Then.\end{mylemma}
\begin{myremark}\label{c}Note.\end{myremark}
""")
        self.assertNoErrors(result)
        self.assertEqual(["assumption", "lemma", "remark"], [i["kind"] for i in result["items"]])
        self.assertEqual(r"A title with {$[0,1]$} and {\bf text}", self.by_label(result)["b"]["title"])

    def test_builtin_starred_results(self):
        result = self.parse(r"\begin{lemma*}\label{a}A.\end{lemma*}")
        self.assertEqual("lemma", result["items"][0]["kind"])

    def test_macro_bodies_do_not_create_fake_results_or_dependencies(self):
        result = self.parse(r"""\newcommand{\sample}[1]{\ref{#1}}
\def\evil#1{\begin{lemma}\label{fake}#1\end{lemma}}
\newenvironment{sketch}{\begin{proof}}{\end{proof}}
\NewDocumentCommand{\another}{m}{\ref{#1}}
\begin{lemma}\label{a}Actual text.\end{lemma}
""")
        self.assertEqual(["a"], [i["label"] for i in result["items"]])
        self.assertEqual([], result["items"][0]["references"])
        self.assertIn("structural_macro_not_expanded", self.codes(result))

    def test_incomplete_macro_does_not_import_replacement_body(self):
        result = self.parse(r"\newcommand{\evil}{\begin{lemma}\label{fake}X.\end{lemma}")
        self.assertEqual([], result["items"])
        self.assertIn("malformed_macro_definition", self.codes(result))

    def test_following_and_enclosed_proofs_are_attached(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{proof}A direct proof.\end{proof}
\begin{lemma}\label{b}B.
\begin{proof}An enclosed proof uses \ref{a}.\end{proof}
\end{lemma}
""")
        self.assertNoErrors(result)
        items = self.by_label(result)
        self.assertEqual("A direct proof.", items["a"]["proofs"][0]["text"])
        self.assertEqual("B.", items["b"]["statement"])
        self.assertEqual([], items["b"]["references"])
        self.assertEqual("chapter.tex::a", items["b"]["proofs"][0]["references"][0]["target_key"])

    def test_explicit_proof_heading_selects_earlier_item_without_self_dependency(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{lemma}\label{b}B.\end{lemma}
\begin{proof}[Proof of Lemma \ref{a}]
Use \ref{b}.
\end{proof}
\begin{proof}[Another proof of \ref{a}]
Direct.
\end{proof}
""")
        self.assertNoErrors(result)
        items = self.by_label(result)
        self.assertEqual(2, len(items["a"]["proofs"]))
        self.assertEqual([], items["b"]["proofs"])
        self.assertEqual(["b"], [r["label"] for r in items["a"]["proofs"][0]["references"]])
        self.assertEqual([], items["a"]["proofs"][1]["references"])

    def test_heading_boundary_prevents_implicit_proof_attachment(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\section{Different material}
\begin{proof}Unattached.\end{proof}
""")
        self.assertEqual([], result["items"][0]["proofs"])
        self.assertIn("orphan_proof", self.codes(result))

    def test_ambiguous_and_conflicting_proof_headers(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{lemma}\label{b}B.
\begin{proof}[Proof of \ref{a}]Mismatch.\end{proof}
\end{lemma}
\begin{proof}[Proof of \cref{a,b}]Ambiguous.\end{proof}
""")
        self.assertIn("conflicting_proof_target", self.codes(result))
        self.assertIn("ambiguous_proof_target", self.codes(result))
        self.assertTrue(all(not i["proofs"] for i in result["items"]))

    def test_clauses_and_equations_inside_a_result_alias_the_parent(self):
        result = self.parse(r"""\begin{lemma}\label{a}
\begin{enumerate}\item\label{a-i} First.\end{enumerate}
\begin{equation}\label{a-eq} x=x.\end{equation}
\end{lemma}
\begin{lemma}\label{b}B.\end{lemma}
\begin{proof}\eqref{a-eq}; \ref{a-i}.\end{proof}
""")
        self.assertNoErrors(result)
        self.assertEqual(2, len(result["items"]))
        items = self.by_label(result)
        self.assertEqual(["a", "a-i", "a-eq"], items["a"]["label_aliases"])
        refs = items["b"]["proofs"][0]["references"]
        self.assertEqual(["chapter.tex::a"] * 2, [r["target_key"] for r in refs])
        self.assertEqual(["a-eq", "a-i"], [r["target_clause"] for r in refs])

    def test_labels_inside_a_proof_are_addressable_aliases(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{proof}\begin{equation}\label{proof-eq}x=x.\end{equation}\end{proof}
\begin{lemma}\label{b}By \eqref{proof-eq}.\end{lemma}
""")
        self.assertNoErrors(result)
        items = self.by_label(result)
        self.assertEqual("chapter.tex::a", items["b"]["references"][0]["target_key"])
        self.assertEqual("proof-eq", items["b"]["references"][0]["target_clause"])
        self.assertNotIn(r"\label", items["a"]["proofs"][0]["text"])

    def test_sections_are_navigation_and_can_have_references(self):
        result = self.parse(r"""\chapter{Algebra}
\section[Short]{Long title}\label{sec:a}
Overview uses \ref{a}.
\subsection{Details}
\begin{lemma}\label{a}A.\end{lemma}
\section*{Appendix}
\begin{example}\label{b}B.\end{example}
""")
        self.assertNoErrors(result)
        items = self.by_label(result)
        self.assertEqual(["Algebra", "Long title", "Details"], items["a"]["section"])
        self.assertEqual(["Algebra", "Appendix"], items["b"]["section"])
        self.assertEqual("mention", items["sec:a"]["references"][0]["role"])
        self.assertEqual("Long title", items["sec:a"]["statement"])

    def test_top_level_equation_is_addressable(self):
        result = self.parse(r"""\begin{align}\label{eq:a}
a&=b\\ \label{eq:b}b&=c.
\end{align}
\begin{lemma}\label{a}By \eqref{eq:b}.\end{lemma}
""")
        self.assertNoErrors(result)
        items = self.by_label(result)
        self.assertEqual("equation", items["eq:a"]["kind"])
        self.assertEqual("chapter.tex::eq:a", items["a"]["references"][0]["target_key"])
        self.assertEqual("eq:b", items["a"]["references"][0]["target_clause"])

    def test_reference_commands_lists_and_ranges(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{lemma}\label{b}B.\end{lemma}
\begin{lemma}\label{c}
\cref{a,b}; \Crefrange{a}{b}; \ref*{a}; \hyperref[b]{name}.
\end{lemma}
""")
        self.assertNoErrors(result)
        refs = self.by_label(result)["c"]["references"]
        self.assertEqual(["a", "b", "a", "b", "a", "b"], [r["label"] for r in refs])
        self.assertEqual(["cref", "cref", "Crefrange", "Crefrange", "ref", "hyperref"], [r["command"] for r in refs])

    def test_local_label_precedes_ambiguous_global_labels(self):
        self.write("a.tex", r"\begin{lemma}\label{x}A. \ref{x}.\end{lemma}")
        self.write("b.tex", r"\begin{lemma}\label{x}B. \ref{x}.\end{lemma}")
        self.write("c.tex", r"\begin{lemma}\label{y}\ref{x}; \ref{a-x}; \ref{b-x}.\end{lemma}")
        result = parse_project(self.root)
        items = {i["key"]: i for i in result["items"]}
        self.assertEqual("a.tex::x", items["a.tex::x"]["references"][0]["target_key"])
        self.assertEqual("b.tex::x", items["b.tex::x"]["references"][0]["target_key"])
        self.assertEqual([None, "a.tex::x", "b.tex::x"], [r["target_key"] for r in items["c.tex::y"]["references"]])
        self.assertIn("ambiguous_reference", self.codes(result))

    def test_full_relative_filename_prefix_disambiguates_duplicate_stems(self):
        self.write("one/a.tex", r"\begin{lemma}\label{x}A.\end{lemma}")
        self.write("two/a.tex", r"\begin{lemma}\label{x}A.\end{lemma}")
        self.write("consumer.tex", r"\begin{lemma}\label{y}\ref{a-x}; \ref{one-a-x}.\end{lemma}")
        result = parse_project(self.root)
        refs = self.by_label(result)["y"]["references"]
        self.assertIsNone(refs[0]["target_key"])
        self.assertEqual("one/a.tex::x", refs[1]["target_key"])
        self.assertIn("ambiguous_reference", self.codes(result))

    def test_duplicate_labels_and_unknown_references_are_diagnosed(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{lemma}\label{a}B. \ref{absent}.\end{lemma}
""")
        self.assertIn("duplicate_label", self.codes(result))
        self.assertIn("unresolved_reference", self.codes(result))
        self.assertIsNone(result["items"][1]["references"][0]["target_key"])

    def test_missing_label_has_provisional_identity(self):
        result = self.parse("\\begin{lemma}\nA.\n\\end{lemma}")
        item = result["items"][0]
        self.assertIsNone(item["label"])
        self.assertTrue(item["key"].startswith("chapter.tex::@unlabelled-"))
        self.assertIn("missing_label", self.codes(result))

    def test_unlabelled_results_on_same_line_have_distinct_provisional_keys(self):
        result = self.parse(r"\begin{lemma}A.\end{lemma}\begin{lemma}B.\end{lemma}")
        self.assertEqual(2, len({i["key"] for i in result["items"]}))

    def test_nested_proof_is_not_mistaken_for_an_alternative_proof(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.\end{lemma}
\begin{proof}Outer.\begin{proof}Inner.\end{proof}\end{proof}
""")
        self.assertIn("nested_proof", self.codes(result))
        self.assertEqual(1, len(result["items"][0]["proofs"]))
        self.assertIn("Inner.", result["items"][0]["proofs"][0]["text"])

    def test_reference_hidden_in_macro_has_a_structural_diagnostic(self):
        result = self.parse(r"""\newcommand{\shortcut}{\ref{a}}
\begin{lemma}\label{a}A.\end{lemma}
\begin{lemma}\label{b}\shortcut.\end{lemma}
""")
        self.assertIn("structural_macro_not_expanded", self.codes(result))
        self.assertEqual([], self.by_label(result)["b"]["references"])

    def test_include_inside_result_reports_lost_scope(self):
        self.write("body.tex", "Body.")
        result = self.parse(r"\begin{lemma}\label{a}\input{body}\end{lemma}", entrypoints=["chapter.tex"])
        self.assertIn("include_inside_environment", self.codes(result))
        self.assertEqual(2, len(result["files"]))

    def test_custom_conditionals_are_diagnosed_but_math_iff_is_not(self):
        result = self.parse(r"\ifdraft\begin{lemma}\label{a}A $\iff$ B.\end{lemma}\fi")
        self.assertEqual(1, len([d for d in result["diagnostics"] if d["code"] == "conditional_tex_not_evaluated"]))

    def test_endinput_excludes_later_lines_but_retains_buffered_line(self):
        result = self.parse(r"""\endinput \begin{lemma}\label{a}A.\end{lemma}
\input{absent}
\begin{lemma}\label{inactive}Inactive.\end{lemma}
""")
        self.assertNoErrors(result)
        self.assertEqual(["a"], [i["label"] for i in result["items"]])
        self.assertIn("inactive", result["files"][0]["text"])

    def test_two_ids_in_one_comment_are_conflicting(self):
        result = self.parse("\\begin{lemma}\\label{a}\n% mpm:id=A mpm:id=B\nX.\\end{lemma}")
        self.assertIn("conflicting_explicit_ids", self.codes(result))
        self.assertIsNone(result["items"][0]["explicit_id"])

    def test_null_path_and_symlink_cycles_produce_diagnostics(self):
        result = parse_project(self.root, ["bad\x00name"])
        self.assertIn("invalid_entrypoint", self.codes(result))
        (self.root / "loop.tex").symlink_to("loop.tex")
        result = parse_project(self.root, ["loop.tex"])
        self.assertIn("unresolvable_path", self.codes(result))

    def test_invalid_dynamic_label_is_not_indexed(self):
        result = self.parse(r"\begin{lemma}\label{#1}A.\end{lemma}")
        self.assertIn("malformed_label", self.codes(result))
        self.assertIsNone(result["items"][0]["label"])

    def test_malformed_and_nested_structures_do_not_look_verified(self):
        result = self.parse(r"""\begin{lemma}\label{a}A.
\begin{claim}\label{local}Local.\end{claim}
\begin{enumerate}\item Unfinished.
\end{lemma}
\end{proof}
\begin{definition}\label{d}Unclosed.
""")
        self.assertEqual(["a", "d"], [i["label"] for i in result["items"]])
        self.assertIn("nested_result_requires_context", self.codes(result))
        self.assertIn("mismatched_environment_end", self.codes(result))
        self.assertIn("unmatched_environment_end", self.codes(result))
        self.assertIn("unclosed_environment", self.codes(result))

    def test_conditional_and_dynamic_tex_are_not_executed(self):
        result = self.parse(r"""\iftrue
\begin{lemma}\label{a}A.\end{lemma}
\fi
\directlua{os.execute('touch should-not-exist')}
\immediate\write18{touch should-not-exist}
\includeonly{chapter}
""")
        self.assertIn("conditional_tex_not_evaluated", self.codes(result))
        self.assertIn("dynamic_tex_not_evaluated", self.codes(result))
        self.assertIn("includeonly_not_evaluated", self.codes(result))
        self.assertFalse((self.root / "should-not-exist").exists())

    def test_literal_includes_root_relative_then_sibling_fallback(self):
        self.write("main.tex", "\\input{chapters/one}\n\\include{two}")
        self.write("chapters/one.tex", "\\input sibling.tex\n\\begin{lemma}\\label{a}A.\\end{lemma}")
        self.write("chapters/sibling.tex", r"\begin{lemma}\label{s}S.\end{lemma}")
        self.write("two.tex", r"\begin{lemma}\label{b}B.\end{lemma}")
        self.write("unreachable.tex", r"\begin{lemma}\label{unreachable}X.\end{lemma}")
        result = parse_project(self.root, ["main"])
        self.assertNoErrors(result)
        self.assertEqual({"a", "b", "s"}, {i["label"] for i in result["items"]})
        self.assertEqual(["main.tex", "chapters/one.tex", "chapters/sibling.tex", "two.tex"], [f["path"] for f in result["files"]])

    def test_missing_dynamic_repeated_and_cyclic_includes(self):
        self.write("main.tex", "\\input{child}\n\\input{child}\n\\input{absent}\n\\input{\\dynamic}")
        self.write("child.tex", "\\input{main}\n\\begin{lemma}\\label{a}A.\\end{lemma}")
        result = parse_project(self.root, ["main"])
        self.assertEqual({"include_cycle", "repeated_include", "missing_include", "dynamic_include"}, self.codes(result))
        self.assertEqual(2, len(result["files"]))

    def test_include_path_cannot_escape_project_root(self):
        with tempfile.TemporaryDirectory() as outside:
            secret = Path(outside) / "outside.tex"
            secret.write_text(r"\begin{lemma}\label{outside}SECRET.\end{lemma}")
            self.write("main.tex", "\\input{" + str(secret) + "}")
            result = parse_project(self.root, ["main"])
            self.assertEqual([], result["items"])
            self.assertEqual(1, len(result["files"]))
            self.assertIn("path_outside_root", self.codes(result))
            self.assertNotIn("SECRET", json.dumps(result))

    def test_symlink_sources_cannot_escape_project_root(self):
        with tempfile.TemporaryDirectory() as outside:
            secret = Path(outside) / "outside.tex"
            secret.write_text(r"\begin{lemma}\label{outside}SECRET.\end{lemma}")
            (self.root / "escape.tex").symlink_to(secret)
            result = parse_project(self.root)
            self.assertEqual([], result["files"])
            self.assertIn("path_outside_root", self.codes(result))

    def test_source_roots_and_default_content_directory(self):
        self.write("content/a.tex", r"\begin{lemma}\label{a}A.\end{lemma}")
        self.write("elsewhere/b.tex", r"\begin{lemma}\label{b}B.\end{lemma}")
        self.write("content/build/generated.tex", r"\begin{lemma}\label{generated}G.\end{lemma}")
        default = parse_project(self.root)
        explicit = parse_project(self.root, source_roots=["elsewhere"])
        self.assertEqual(["a"], [i["label"] for i in default["items"]])
        self.assertEqual(["b"], [i["label"] for i in explicit["items"]])

    def test_invalid_root_source_roots_and_entrypoints(self):
        result = parse_project(self.root / "absent")
        self.assertIn("invalid_root", self.codes(result))
        result = parse_project(self.root, ["absent", 42])
        self.assertIn("missing_entrypoint", self.codes(result))
        self.assertIn("invalid_entrypoint", self.codes(result))
        result = parse_project(self.root, source_roots=["missing", "../", 42])
        self.assertIn("missing_source_root", self.codes(result))
        self.assertIn("path_outside_root", self.codes(result))
        self.assertIn("invalid_source_root", self.codes(result))

    def test_utf8_bom_is_accepted_and_bytes_are_hashed(self):
        raw = b"\xef\xbb\xbf" + b"\\begin{lemma}\r\n\\label{a}A.\r\n\\end{lemma}\r\n"
        self.write("chapter.tex", raw)
        result = parse_project(self.root)
        self.assertNoErrors(result)
        self.assertEqual("a", result["items"][0]["label"])
        self.assertEqual(sha256(raw).hexdigest(), result["files"][0]["sha256"])
        self.assertTrue(result["files"][0]["text"].startswith("\ufeff"))
        self.assertEqual(raw, result["files"][0]["text"].encode("utf-8"))

    def test_invalid_utf8_and_binary_files_are_diagnosed(self):
        self.write("a.tex", b"\xff\xfe")
        self.write("b.tex", b"plain\x00binary")
        result = parse_project(self.root)
        self.assertEqual([], result["files"])
        self.assertIn("unreadable_source", self.codes(result))
        self.assertIn("binary_source", self.codes(result))

    def test_crlf_source_line_locations(self):
        self.write("chapter.tex", b"Intro.\r\n\\begin{lemma}\r\n\\label{a}A.\r\n\\end{lemma}\r\n")
        result = parse_project(self.root)
        self.assertEqual({"path": "chapter.tex", "start_line": 2, "end_line": 4}, result["items"][0]["source"])
        self.assertIn("\r\n", result["files"][0]["text"])

    def test_deterministic_output(self):
        self.write("b.tex", r"\begin{lemma}\label{x}B.\end{lemma}")
        self.write("a.tex", r"\begin{lemma}\label{x}A.\ref{absent}\end{lemma}")
        first = parse_project(self.root)
        second = parse_project(self.root)
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()
