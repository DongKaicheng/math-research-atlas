"""Independent source-change audit with real subprocess crash boundaries.

These tests assert conservation of authoritative source bytes and ledger
history, rather than only checking a successful return value.
"""

from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))

from mathproj import changes
from mathproj.changes import (apply_proposal, create_proposal, inspect_proposal,
                             pending_change, recover_changes, _journal_write)
from mathproj.project import ingest
from mathproj.store import ProjectError, ProjectStore, atomic_json
from mathproj.tasks import (add_task, checkpoint_task, claim_task, task_context,
                            transition_task)
from mathproj.workflow import freshness


A = "\\begin{lemma}\\label{a}An old statement A.\\end{lemma}\n\\begin{proof}Old proof A.\\end{proof}\n"
B = "\\begin{lemma}\\label{b}An old statement B.\\end{lemma}\n\\begin{proof}Old proof B.\\end{proof}\n"
NEW_A = A.replace("Old proof A.", "The new argument for A is explicit.")
NEW_B = B.replace("Old proof B.", "The new argument for B is explicit.")
C = "\\begin{definition}\\label{c}A newly introduced definition.\\end{definition}\n"


CRASH_WORKER = r'''
import os, sys
from pathlib import Path
from unittest.mock import patch
from mathproj import changes, store as storage
from mathproj.store import ProjectStore
store = ProjectStore(sys.argv[1])
proposal_id, mode = sys.argv[2:4]
if mode == 'after_first_source':
    original = changes._atomic_bytes
    count = [0]
    def interrupted(path, value):
        original(path, value)
        count[0] += 1
        if count[0] == 1:
            os._exit(71)
    with patch('mathproj.changes._atomic_bytes', side_effect=interrupted):
        changes.apply_proposal(store, proposal_id)
elif mode == 'before_ledger_append':
    original = storage.canonical
    def interrupted(value):
        if isinstance(value, dict) and value.get('operation') == 'apply_source_change' and 'hash' in value:
            os._exit(72)
        return original(value)
    with patch('mathproj.store.canonical', side_effect=interrupted):
        changes.apply_proposal(store, proposal_id)
elif mode == 'after_ledger_commit':
    original = storage.atomic_json
    def interrupted(path, value):
        if path == store.state_path and value.get('proposals', {}).get(proposal_id, {}).get('status') == 'applied':
            os._exit(73)
        return original(path, value)
    with patch('mathproj.store.atomic_json', side_effect=interrupted):
        changes.apply_proposal(store, proposal_id)
elif mode == 'partial_ledger_append':
    original = Path.open
    class InterruptedWriter:
        def __init__(self, handle):
            self.handle = handle
        def __enter__(self):
            return self
        def __exit__(self, *args):
            self.handle.close()
        def write(self, value):
            self.handle.write(value[:len(value)//2])
            self.handle.flush()
            os.fsync(self.handle.fileno())
            os._exit(74)
    def interrupted(path, mode='r', *args, **kwargs):
        handle = original(path, mode, *args, **kwargs)
        return InterruptedWriter(handle) if path == store.events and mode == 'ab' else handle
    with patch.object(Path, 'open', interrupted):
        changes.apply_proposal(store, proposal_id)
else:
    raise RuntimeError('unknown crash boundary')
raise RuntimeError('injected crash did not run')
'''


class ChangeAuditCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.store = ProjectStore.create(self.root, "Independent change audit", "AUDIT")
        self.a = self.root / "content" / "a.tex"
        self.b = self.root / "content" / "b.tex"
        self.a.write_text(A)
        self.b.write_text(B)
        ingest(self.store)

    def edit(self, path, content=None, operation="write"):
        file = self.root / path
        before = hashlib.sha256(file.read_bytes()).hexdigest() if file.exists() else None
        result = {"path": path, "before_sha256": before, "operation": operation}
        if operation == "write":
            result["content"] = content
        return result

    def prepare(self, edits=None):
        payload = {"title": "Audit a source revision", "rationale": "Expose exact failure boundaries.",
                   "author": "audit-agent", "base_snapshot": self.store.state()["current_snapshot"],
                   "edits": edits or [self.edit("content/a.tex", NEW_A), self.edit("content/b.tex", NEW_B)]}
        return create_proposal(self.store, payload)["proposal"]

    def journal(self, proposal, *, phase="files_written"):
        rows = []
        for edit in proposal["edits"]:
            path = self.root / edit["path"]
            rows.append({"path": edit["path"], "before_text": path.read_text() if path.exists() else None,
                         "before_sha256": edit["before_sha256"], "after_sha256": edit["after_sha256"]})
        value = {"schema_version": 1, "proposal_id": proposal["id"], "phase": phase, "files": rows}
        _journal_write(self.store.meta / "changes" / "pending.json", value)
        return value

    def write_journal(self, value):
        _journal_write(self.store.meta / "changes" / "pending.json", value)

    def crash(self, proposal, mode, code):
        environment = dict(os.environ)
        environment["PYTHONPATH"] = str(SCRIPTS) + os.pathsep + environment.get("PYTHONPATH", "")
        child = subprocess.run([sys.executable, "-c", CRASH_WORKER, str(self.root), proposal["id"], mode],
                               capture_output=True, text=True, env=environment, timeout=15)
        self.assertEqual(code, child.returncode, child.stdout + child.stderr)

    def test_crash_after_first_file_restores_mixed_old_and_new_sources(self):
        proposal = self.prepare()
        ledger = self.store.events.read_bytes()
        self.crash(proposal, "after_first_source", 71)
        self.assertEqual(NEW_A, self.a.read_text())
        self.assertEqual(B, self.b.read_text())
        self.assertEqual("prepared", pending_change(self.store)["phase"])
        result = recover_changes(self.store)
        self.assertFalse(result["committed"])
        self.assertEqual(A, self.a.read_text())
        self.assertEqual(B, self.b.read_text())
        self.assertEqual(ledger, self.store.events.read_bytes())
        self.assertEqual("prepared", inspect_proposal(self.store, proposal["id"])["status"])

    def test_crash_before_ledger_commit_restores_created_and_deleted_files(self):
        proposal = self.prepare([self.edit("content/a.tex", NEW_A),
                                 self.edit("content/b.tex", operation="delete"), self.edit("content/c.tex", C)])
        self.crash(proposal, "before_ledger_append", 72)
        self.assertFalse(self.b.exists())
        self.assertEqual(C, (self.root / "content" / "c.tex").read_text())
        self.assertEqual("files_written", pending_change(self.store)["phase"])
        result = recover_changes(self.store)
        self.assertFalse(result["committed"])
        self.assertEqual(A, self.a.read_text())
        self.assertEqual(B, self.b.read_text())
        self.assertFalse((self.root / "content" / "c.tex").exists())

    def test_crash_after_ledger_commit_keeps_new_bytes_and_rebuilds_cache(self):
        proposal = self.prepare()
        old_cache = self.store.state_path.read_bytes()
        self.crash(proposal, "after_ledger_commit", 73)
        self.assertEqual(old_cache, self.store.state_path.read_bytes())
        self.assertEqual("applied", inspect_proposal(self.store, proposal["id"])["status"])
        self.assertFalse(freshness(self.store)["fresh"])
        with self.assertRaisesRegex(ProjectError, "pending"):
            ingest(self.store)
        result = recover_changes(self.store)
        self.assertTrue(result["committed"])
        self.assertEqual(NEW_A, self.a.read_text())
        self.assertEqual(NEW_B, self.b.read_text())
        self.store.recover()
        self.assertNotEqual(old_cache, self.store.state_path.read_bytes())
        imported = ingest(self.store)
        self.assertEqual(2, len(imported["changed"]))
        self.assertTrue(freshness(self.store)["fresh"])

    def test_partial_ledger_tail_requires_replay_repair_before_source_recovery(self):
        proposal = self.prepare()
        ledger = self.store.events.read_bytes()
        self.crash(proposal, "partial_ledger_append", 74)
        tail = self.store.events.read_bytes()[len(ledger):]
        self.assertTrue(tail)
        self.assertFalse(tail.endswith(b"\n"))
        with self.assertRaisesRegex(ProjectError, "Incomplete final event"):
            recover_changes(self.store)
        self.assertEqual(NEW_A, self.a.read_text())
        self.assertIsNotNone(pending_change(self.store))
        self.store.recover()
        backups = list(self.store.meta.glob("incomplete-tail-*.bin"))
        self.assertEqual([tail], [path.read_bytes() for path in backups])
        self.assertEqual(ledger, self.store.events.read_bytes())
        recover_changes(self.store)
        self.assertEqual(A, self.a.read_text())
        self.assertEqual(B, self.b.read_text())

    def test_precommit_exception_rolls_back_but_postcommit_cache_failure_does_not(self):
        proposal = self.prepare()
        from mathproj import store as storage
        original = storage.canonical
        def fail_before_append(value):
            if isinstance(value, dict) and value.get("operation") == "apply_source_change" and "hash" in value:
                raise OSError("before ledger append")
            return original(value)
        with patch("mathproj.store.canonical", side_effect=fail_before_append):
            with self.assertRaisesRegex(OSError, "before ledger"):
                apply_proposal(self.store, proposal["id"])
        self.assertEqual(A, self.a.read_text())
        self.assertEqual(B, self.b.read_text())
        self.assertEqual("prepared", inspect_proposal(self.store, proposal["id"])["status"])
        self.assertIsNone(pending_change(self.store))
        original_json = storage.atomic_json
        def fail_cache(path, value):
            if path == self.store.state_path and value.get("proposals", {}).get(proposal["id"], {}).get("status") == "applied":
                raise OSError("after ledger commit")
            return original_json(path, value)
        with patch("mathproj.store.atomic_json", side_effect=fail_cache):
            with self.assertRaisesRegex(OSError, "after ledger"):
                apply_proposal(self.store, proposal["id"])
        self.assertEqual(NEW_A, self.a.read_text())
        self.assertEqual(NEW_B, self.b.read_text())
        self.assertEqual("applied", inspect_proposal(self.store, proposal["id"])["status"])
        self.assertIsNone(pending_change(self.store))

    def test_recovery_does_not_trust_applied_status_in_state_cache(self):
        proposal = self.prepare()
        self.journal(proposal)
        self.a.write_text(NEW_A)
        self.b.write_text(NEW_B)
        cache = self.store.state()
        cache["proposals"][proposal["id"]]["status"] = "applied"
        atomic_json(self.store.state_path, cache)
        result = recover_changes(self.store)
        self.assertFalse(result["committed"])
        self.assertEqual(A, self.a.read_text())

    def test_corrupt_complete_ledger_prevents_any_source_recovery_write(self):
        proposal = self.prepare()
        self.journal(proposal)
        self.a.write_text(NEW_A)
        original = self.store.events.read_bytes()
        lines = original.splitlines(keepends=True)
        event = json.loads(lines[-1])
        event["hash"] = "0" * 64
        lines[-1] = json.dumps(event).encode() + b"\n"
        self.store.events.write_bytes(b"".join(lines))
        with self.assertRaisesRegex(ProjectError, "chain validation"):
            recover_changes(self.store)
        self.assertEqual(NEW_A, self.a.read_text())
        self.assertIsNotNone(pending_change(self.store))

    def test_incomplete_tail_repair_refuses_a_conflicting_backup(self):
        tail = b'{"incomplete_audit_event":'
        self.store.events.write_bytes(self.store.events.read_bytes() + tail)
        before = self.store.events.read_bytes()
        backup = self.store.meta / ("incomplete-tail-" + hashlib.sha256(tail).hexdigest()[:16] + ".bin")
        backup.write_bytes(b"A different interrupted transaction")
        with self.assertRaises(ProjectError):
            self.store.recover()
        self.assertEqual(before, self.store.events.read_bytes())
        self.assertEqual(b"A different interrupted transaction", backup.read_bytes())

    def test_incomplete_tail_repair_never_follows_a_backup_symlink(self):
        tail = b'{"incomplete_audit_event":'
        self.store.events.write_bytes(self.store.events.read_bytes() + tail)
        before = self.store.events.read_bytes()
        backup = self.store.meta / ("incomplete-tail-" + hashlib.sha256(tail).hexdigest()[:16] + ".bin")
        outside = self.root / "not-metadata" / "unexpected-write.bin"
        outside.parent.mkdir()
        backup.symlink_to(outside)
        with self.assertRaises(ProjectError):
            self.store.recover()
        self.assertEqual(before, self.store.events.read_bytes())
        self.assertFalse(outside.exists())

    def test_rollback_checks_all_files_before_overwriting_any(self):
        proposal = self.prepare()
        self.journal(proposal)
        self.a.write_text(NEW_A)
        self.b.write_text("Independent work that must survive.\n")
        with self.assertRaisesRegex(ProjectError, "unrelated edit"):
            recover_changes(self.store)
        self.assertEqual(NEW_A, self.a.read_text())
        self.assertEqual("Independent work that must survive.\n", self.b.read_text())
        self.assertIsNotNone(pending_change(self.store))

    def test_malformed_journal_cannot_change_restoration_bytes(self):
        proposal = self.prepare()
        journal = self.journal(proposal)
        journal["files"][0]["before_text"] = "Forged restoration content.\n"
        self.write_journal(journal)
        with self.assertRaises(ProjectError):
            recover_changes(self.store)
        self.assertEqual(A, self.a.read_text())
        self.assertEqual(B, self.b.read_text())

    def test_malformed_journal_cannot_delete_an_existing_baseline_file(self):
        proposal = self.prepare()
        journal = self.journal(proposal)
        journal["files"][0]["before_text"] = None
        self.write_journal(journal)
        with self.assertRaises(ProjectError):
            recover_changes(self.store)
        self.assertTrue(self.a.exists())
        self.assertEqual(A, self.a.read_text())

    def test_journal_file_set_must_match_authoritative_proposal(self):
        proposal = self.prepare([self.edit("content/a.tex", NEW_A)])
        journal = self.journal(proposal)
        journal["files"].append({"path": "content/b.tex", "before_text": None,
                                 "before_sha256": hashlib.sha256(self.b.read_bytes()).hexdigest(),
                                 "after_sha256": None})
        self.write_journal(journal)
        with self.assertRaises(ProjectError):
            recover_changes(self.store)
        self.assertEqual(B, self.b.read_text())

    def test_unknown_journal_schema_is_rejected_without_source_writes(self):
        proposal = self.prepare()
        journal = self.journal(proposal)
        journal["schema_version"] = 999
        self.write_journal(journal)
        with self.assertRaises(ProjectError):
            recover_changes(self.store)
        self.assertEqual(A, self.a.read_text())

    def test_import_rechecks_pending_journal_after_parsing(self):
        proposal = self.prepare()
        from mathproj import latex
        original = latex.parse_project
        def concurrent_source_change(*args, **kwargs):
            parsed = original(*args, **kwargs)
            self.journal(proposal, phase="prepared")
            self.a.write_text(NEW_A)
            return parsed
        ledger = self.store.events.read_bytes()
        with patch("mathproj.latex.parse_project", side_effect=concurrent_source_change):
            with self.assertRaisesRegex(ProjectError, "pending"):
                ingest(self.store)
        self.assertEqual(ledger, self.store.events.read_bytes())
        self.assertIsNotNone(pending_change(self.store))

    def test_valid_entrypoint_without_tex_suffix_can_be_edited(self):
        main = self.root / "main.tex"
        main.write_text(A)
        manifest = self.store.manifest()
        manifest["entrypoints"] = ["main"]
        atomic_json(self.store.manifest_path, manifest)
        ingest(self.store)
        proposal = self.prepare([self.edit("main.tex", NEW_A)])
        self.assertTrue(proposal["analysis"]["structurally_valid"])
        apply_proposal(self.store, proposal["id"])
        self.assertEqual(NEW_A, main.read_text())

    def test_new_include_and_deletion_are_checked_in_the_proposed_graph(self):
        main = self.root / "content" / "main.tex"
        main.write_text("\\input{content/a}\n\\input{content/b}\n")
        manifest = self.store.manifest()
        manifest["entrypoints"] = ["content/main.tex"]
        atomic_json(self.store.manifest_path, manifest)
        ingest(self.store)
        broken = self.prepare([self.edit("content/b.tex", operation="delete")])
        self.assertFalse(broken["analysis"]["structurally_valid"])
        self.assertIn("missing_include", {row["code"] for row in broken["analysis"]["diagnostics"]})
        valid = self.prepare([self.edit("content/main.tex", "\\input{content/a}\n\\input{content/c}\n"),
                              self.edit("content/b.tex", operation="delete"), self.edit("content/c.tex", C)])
        self.assertTrue(valid["analysis"]["structurally_valid"])
        result = apply_proposal(self.store, valid["id"])
        self.assertEqual(1, len(result["import"]["added"]))
        self.assertEqual(1, len(result["import"]["missing"]))
        self.assertFalse(self.b.exists())
        self.assertTrue((self.root / "content" / "c.tex").exists())

    def test_recovery_refuses_symlink_parent_even_for_an_in_root_target(self):
        proposal = self.prepare()
        self.journal(proposal)
        original_directory = self.root / "content"
        replacement = self.root / "original-content"
        original_directory.rename(replacement)
        original_directory.symlink_to(replacement, target_is_directory=True)
        with self.assertRaisesRegex(ProjectError, "symlink"):
            recover_changes(self.store)
        self.assertEqual(A, self.a.read_text())

    def test_broken_journal_symlink_is_not_treated_as_no_pending_change(self):
        folder = self.store.meta / "changes"
        folder.mkdir(exist_ok=True)
        (folder / "pending.json").symlink_to(folder / "missing-target.json")
        with self.assertRaisesRegex(ProjectError, "symlink"):
            pending_change(self.store)

    def test_task_checkpoints_survive_crash_and_record_pending_recovery(self):
        task_id = add_task(self.store, "Audit interrupted edits", acceptance="Recover sources and inspect their current bytes.",
                           target_ids=["a"])["task"]["id"]
        claim_task(self.store, task_id, "worker")
        checkpoint_task(self.store, task_id, "worker", evidence=[{"kind": "inspection", "summary": "Baseline source inspected."}],
                        next_step="Apply the prepared source proposal.")
        proposal = self.prepare()
        self.crash(proposal, "after_first_source", 71)
        before = task_context(self.store, task_id)
        self.assertEqual(1, len(before["task"]["checkpoints"]))
        self.assertFalse(before["source_freshness"]["fresh"])
        evidence = [{"kind": "inspection", "summary": "Observed a source-write interruption."},
                    {"kind": "acceptance", "summary": "Recovery work recorded.", "outcome": "satisfied"}]
        during = checkpoint_task(self.store, task_id, "worker", evidence=evidence,
                                 next_step="Recover the pending journal before completion.")
        self.assertFalse(during["latest_checkpoint"]["source_freshness"]["fresh"])
        with self.assertRaisesRegex(ProjectError, "recovery_pending"):
            transition_task(self.store, task_id, "done", assignee="worker")
        recover_changes(self.store)
        checkpoint_task(self.store, task_id, "worker", evidence=[
            {"kind": "inspection", "summary": "Both exact baseline source byte strings were restored."},
            {"kind": "acceptance", "summary": "Source recovery and inspection are complete.", "outcome": "satisfied"}],
            next_step="Continue mathematical editing from the intact proposal.")
        finished = transition_task(self.store, task_id, "done", assignee="worker")
        self.assertEqual("done", finished["task"]["status"])
        self.assertEqual(3, len(finished["task"]["checkpoints"]))


if __name__ == "__main__":
    unittest.main()
