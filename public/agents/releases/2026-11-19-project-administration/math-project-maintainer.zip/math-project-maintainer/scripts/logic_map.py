#!/usr/bin/env python3
"""Validate and draw source-bound mathematical logic maps; never certify a proof."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import sys
import tempfile
from urllib.parse import urlsplit

SCHEMA = "math-logic-map/v1"
STATUSES = {"established", "conditional", "open", "hypothesis", "model-case",
            "obstruction", "definition", "external", "withdrawn"}
KINDS = {"implication", "conditional-implication", "proof-dependency",
         "open-step", "obstruction"}
SUFFICIENT = {"implication", "conditional-implication"}
IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")
SLUG = re.compile(r"^[a-z][a-z0-9-]{0,63}$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(content):
    return hashlib.sha256(content).hexdigest()


def load_json(path):
    path = Path(path)
    if path.stat().st_size > 10 * 1024 * 1024:
        raise ValueError("input exceeds 10 MiB")

    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    def reject(value):
        raise ValueError(f"non-finite JSON number: {value}")

    def finite_float(value):
        number = float(value)
        if not math.isfinite(number):
            reject(value)
        return number

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique,
                      parse_constant=reject, parse_float=finite_float)


def safe_href(value):
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        return False
    if any(ord(c) < 32 for c in value) or "\\" in value or value.startswith("//"):
        return False
    try:
        parsed = urlsplit(value)
        if parsed.scheme and parsed.scheme not in {"https", "http"}:
            return False
        if parsed.scheme and (not parsed.netloc or parsed.username or parsed.password):
            return False
    except ValueError:
        return False
    return True


def audit(data, source_root=None):
    errors, warnings = [], []

    def text(value, at):
        if not isinstance(value, str) or not value.strip():
            errors.append(f"{at}: expected nonempty text")
            return False
        return True

    def strings(value, at):
        if not isinstance(value, list):
            errors.append(f"{at}: expected an array")
            return []
        valid = [v for i, v in enumerate(value) if text(v, f"{at}[{i}]")]
        if len(set(valid)) != len(valid):
            errors.append(f"{at}: duplicate value")
        return valid

    def rows(value, at, slug=False):
        if not isinstance(value, list):
            errors.append(f"{at}: expected an array of objects")
            return {}
        result = {}
        for i, row in enumerate(value):
            if not isinstance(row, dict):
                errors.append(f"{at}[{i}]: expected an object")
                continue
            key = row.get("id")
            pattern = SLUG if slug else IDENTIFIER
            if not isinstance(key, str) or not pattern.fullmatch(key):
                errors.append(f"{at}[{i}].id: invalid identifier")
                continue
            if key in result:
                errors.append(f"{at}: duplicate identifier {key}")
            result[key] = row
        return result

    def links(row, at, required=False):
        if required or "href" in row:
            if not safe_href(row.get("href")):
                errors.append(f"{at}.href: expected a safe HTTP(S), relative or fragment link")

    def members(value, known, at, nonempty=False):
        selected = strings(value, at)
        if nonempty and not selected:
            errors.append(f"{at}: at least one reference is required")
        for key in selected:
            if key not in known:
                errors.append(f"{at}: unknown identifier {key}")
        return selected

    if not isinstance(data, dict):
        return {"valid": False, "errors": ["map: expected an object"], "warnings": []}
    if data.get("schema") != SCHEMA:
        errors.append(f"schema: expected {SCHEMA}")
    if not isinstance(data.get("id"), str) or not SLUG.fullmatch(data["id"]):
        errors.append("id: expected a lowercase slug")
    for field in ("title", "version", "scope"):
        text(data.get(field), field)
    sources = rows(data.get("sources"), "sources")
    nodes = rows(data.get("nodes"), "nodes")
    relations = rows(data.get("relations"), "relations")
    alternatives = rows(data.get("alternatives"), "alternatives")
    views = rows(data.get("views"), "views", slug=True)
    if not sources or not nodes or not relations or not views:
        errors.append("sources, nodes, relations and views must all be nonempty")
    if len(nodes) > 1000 or len(relations) > 2000:
        errors.append("scope exceeds 1000 nodes or 2000 relations; split into linked maps")
    identities = list(nodes) + list(relations) + list(alternatives)
    if len(identities) != len(set(identities)):
        errors.append("node, relation and alternative identities must be globally distinct")

    root = Path(source_root).resolve() if source_root is not None else None
    checked_sources = 0
    for key, row in sources.items():
        at = f"sources.{key}"
        text(row.get("label"), at + ".label")
        links(row, at, required=True)
        if "path" in row or "sha256" in row:
            path, expected = row.get("path"), row.get("sha256")
            safe_path = (isinstance(path, str) and bool(path) and
                         not Path(path).is_absolute() and ".." not in Path(path).parts
                         and "\\" not in path)
            if not safe_path:
                errors.append(at + ".path: expected a relative path within the source root")
            if not isinstance(expected, str) or not SHA256.fullmatch(expected):
                errors.append(at + ".sha256: expected an exact lowercase SHA-256 hash")
            if safe_path and root is not None:
                actual = (root / path).resolve()
                if not actual.is_relative_to(root) or not actual.is_file():
                    errors.append(at + ": source is missing or escapes its root")
                elif digest(actual.read_bytes()) != expected:
                    errors.append(at + ": source bytes changed; inspect the source and map before rebinding")
                else:
                    checked_sources += 1
            elif root is None:
                warnings.append(at + ": local source hash declared but source root not supplied")
        else:
            warnings.append(at + ": link/version provenance only; remote bytes were not fetched or verified")

    for key, row in nodes.items():
        at = f"nodes.{key}"
        for field in ("label", "statement", "scope"):
            text(row.get(field), at + "." + field)
        if not isinstance(row.get("status"), str) or row["status"] not in STATUSES:
            errors.append(at + ".status: unknown mathematical status")
        members(row.get("sourceIds"), sources, at + ".sourceIds", nonempty=True)
        links(row, at)

    for key, row in relations.items():
        at = f"relations.{key}"
        for field in ("label", "explanation"):
            text(row.get(field), at + "." + field)
        kind = row.get("kind")
        if not isinstance(kind, str) or kind not in KINDS:
            errors.append(at + ".kind: unknown logical relation type")
        premises = members(row.get("from"), nodes, at + ".from", nonempty=True)
        target = row.get("to")
        if not isinstance(target, str) or target not in nodes:
            errors.append(at + ".to: unknown conclusion")
        if target in premises:
            errors.append(at + ": conclusion cannot be its own premise")
        conditions = strings(row.get("conditions"), at + ".conditions")
        if kind == "implication" and conditions:
            errors.append(at + ": additional hypotheses require conditional-implication")
        if kind == "conditional-implication" and not conditions:
            errors.append(at + ": conditional-implication needs explicit additional hypotheses")
        members(row.get("sourceIds"), sources, at + ".sourceIds", nonempty=True)
        links(row, at)

    grouped_relations = set()
    for key, row in alternatives.items():
        at = f"alternatives.{key}"
        text(row.get("label"), at + ".label")
        text(row.get("explanation"), at + ".explanation")
        routes = members(row.get("relations"), relations, at + ".relations", nonempty=True)
        if len(routes) < 2:
            errors.append(at + ": OR requires at least two separately sufficient routes")
        target = row.get("to")
        if not isinstance(target, str) or target not in nodes:
            errors.append(at + ".to: unknown conclusion")
        for route in routes:
            relation = relations.get(route, {})
            if not isinstance(relation.get("kind"), str) or relation.get("kind") not in SUFFICIENT or relation.get("to") != target:
                errors.append(at + ": OR may join only sufficient routes to the same conclusion")
            if route in grouped_relations:
                errors.append(at + f": relation {route} belongs to more than one OR group")
            grouped_relations.add(route)

    complete_views = 0
    for key, row in views.items():
        at = f"views.{key}"
        text(row.get("title"), at + ".title")
        text(row.get("description"), at + ".description")
        selected_nodes = set(members(row.get("nodeIds"), nodes, at + ".nodeIds", nonempty=True))
        selected_relations = set(members(row.get("relationIds"), relations, at + ".relationIds", nonempty=True))
        if type(row.get("complete")) is not bool:
            errors.append(at + ".complete: expected true or false")
        if row.get("complete") is True:
            complete_views += 1
            if selected_nodes != set(nodes) or selected_relations != set(relations):
                errors.append(at + ": complete view must contain every canonical node and relation")
        for relation_id in selected_relations:
            relation = relations.get(relation_id, {})
            endpoints = relation.get("from", [])
            if not isinstance(endpoints, list):
                continue
            endpoints = [p for p in endpoints if isinstance(p, str)] + [relation.get("to")]
            if any(not isinstance(p, str) or p not in selected_nodes for p in endpoints):
                errors.append(at + f": relation {relation_id} hides a premise or conclusion")
    if not complete_views:
        errors.append("views: at least one complete projection of the declared scope is required")

    # A union of alternative arguments can have cycles or genuine equivalences.
    # Only a chosen sufficient support plan is checked for grounded derivation.
    support = data.get("support")
    if support is not None:
        if not isinstance(support, dict):
            errors.append("support: expected an object")
        else:
            roots = members(support.get("roots"), nodes, "support.roots")
            selected = members(support.get("selected"), relations, "support.selected")
            for key in roots:
                if nodes.get(key, {}).get("status") in ("open", "withdrawn", "obstruction"):
                    errors.append(f"support.roots: {key} is not an available or explicitly admitted premise")
            conclusions = []
            candidates = []
            for key in selected:
                row = relations.get(key, {})
                if not isinstance(row.get("kind"), str) or row.get("kind") not in SUFFICIENT:
                    errors.append(f"support.selected: {key} is not a sufficient deduction")
                    continue
                if not isinstance(row.get("to"), str) or not isinstance(row.get("from"), list) or not all(isinstance(x, str) for x in row["from"]):
                    continue
                conclusions.append(row.get("to"))
                candidates.append((key, row))
            if len(set(conclusions)) != len(conclusions):
                errors.append("support.selected: choose only one sufficient route for each conclusion")
            if any(key in roots for key in conclusions):
                errors.append("support: a selected conclusion cannot also be an admitted root")
            reached = set(roots)
            while candidates:
                ready = [(key, row) for key, row in candidates if set(row["from"]) <= reached]
                if not ready:
                    errors.append("support: selected plan has a cycle or unavailable premise: " +
                                  ", ".join(key for key, _ in candidates))
                    break
                for key, row in ready:
                    reached.add(row.get("to"))
                    candidates.remove((key, row))

    return {"valid": not errors, "errors": sorted(set(errors)),
            "warnings": sorted(set(warnings)),
            "counts": {"nodes": len(nodes), "relations": len(relations),
                       "alternatives": len(alternatives), "views": len(views),
                       "local_sources_checked": checked_sources},
            "meaning": "Structural and source-byte checks only; no proof acceptance or status promotion."}


def generator_hash():
    from logicmap_render import renderer_dependencies
    paths = {Path(__file__).resolve(), *(Path(p).resolve() for p in renderer_dependencies())}
    return digest(canonical({str(p.relative_to(Path(__file__).resolve().parents[1])):
                             digest(p.read_bytes()) for p in sorted(paths)}))


def require_valid(data, source_root=None, require_sources=False):
    report = audit(data, source_root)
    if not report["valid"]:
        raise ValueError(json.dumps(report, ensure_ascii=False, indent=2))
    if require_sources and source_root is None and any("path" in s for s in data.get("sources", [])):
        report["valid"] = False
        report["errors"].append("supply --source-root to bind the declared local source files")
    if not report["valid"]:
        raise ValueError(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def render(data, destination, source_root=None):
    from logicmap_render import render_dot, render_svg, render_html
    report = require_valid(data, source_root, require_sources=True)
    destination = Path(destination).absolute()
    if destination.exists():
        raise ValueError("output already exists; use a new directory to preserve the prior artifact")
    destination.parent.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix=".logic-map-", dir=destination.parent))
    try:
        rendered = []
        for view in data["views"]:
            dot = render_dot(data, view)
            svg = render_svg(dot, view["id"])
            (work / (view["id"] + ".dot")).write_text(dot, encoding="utf-8")
            # A downloaded SVG needs the adjacent HTML record reader; inline
            # SVG keeps same-document fragments for accessible disclosure.
            standalone = svg.replace('href="#', 'href="index.html#')
            (work / (view["id"] + ".svg")).write_text(standalone, encoding="utf-8")
            rendered.append((view, svg))
        (work / "index.html").write_text(render_html(data, rendered), encoding="utf-8")
        (work / "graph.json").write_bytes(canonical(data) + b"\n")
        files = {p.name: digest(p.read_bytes()) for p in sorted(work.iterdir()) if p.is_file()}
        manifest = {"schema": "math-logic-map-artifacts/v1", "version": data["version"],
                    "graphHash": digest(canonical(data)), "generatorHash": generator_hash(),
                    "files": files, "counts": report["counts"],
                    "sourceChecks": report["counts"]["local_sources_checked"],
                    "warnings": report["warnings"]}
        (work / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        work.rename(destination)
    except BaseException:
        shutil.rmtree(work, ignore_errors=True)
        raise
    return {"output": str(destination), "manifest": manifest, "validation": report}


def verify(data, destination, source_root=None):
    report = require_valid(data, source_root, require_sources=True)
    destination = Path(destination).resolve()
    manifest = load_json(destination / "manifest.json")
    if not isinstance(manifest, dict) or manifest.get("schema") != "math-logic-map-artifacts/v1":
        raise ValueError("unknown artifact manifest")
    if manifest.get("graphHash") != digest(canonical(data)) or manifest.get("version") != data["version"]:
        raise ValueError("graph or version changed; inspect the change and regenerate")
    if manifest.get("generatorHash") != generator_hash():
        raise ValueError("renderer or validator changed; regenerate the derived artifacts")
    expected = {"index.html", "graph.json"} | {
        view["id"] + extension for view in data["views"] for extension in (".dot", ".svg")}
    if not isinstance(manifest.get("files"), dict) or set(manifest["files"]) != expected:
        raise ValueError("artifact inventory differs from the complete declared view set")
    for name, checksum in manifest["files"].items():
        path = (destination / name).resolve()
        if not path.is_relative_to(destination) or not path.is_file() or digest(path.read_bytes()) != checksum:
            raise ValueError(f"missing or changed artifact: {name}")
    return {"verified": True, "output": str(destination), "validation": report,
            "meaning": "Exact derived artifact binding; not a mathematical proof certificate."}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("validate", "render", "verify"):
        part = sub.add_parser(command)
        part.add_argument("input", type=Path)
        part.add_argument("--source-root", type=Path)
        if command != "validate":
            part.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        data = load_json(args.input)
        if args.command == "validate":
            result = audit(data, args.source_root)
        elif args.command == "render":
            result = render(data, args.output, args.source_root)
        else:
            result = verify(data, args.output, args.source_root)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result.get("valid", True) else 1
    except (OSError, ValueError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
