"""Render a validated mathematical logic map without changing its records.

The caller owns schema/source validation and artifact manifests. All strings
are literal text; the renderer does not execute TeX, Markdown, or source HTML.
"""

from __future__ import annotations

import html
import json
from pathlib import Path
import re
import shutil
import subprocess
import textwrap
import xml.etree.ElementTree as ET


_ROOT = Path(__file__).resolve().parents[1]
_SVG = "http://www.w3.org/2000/svg"
_XLINK = "http://www.w3.org/1999/xlink"
ET.register_namespace("", _SVG)
ET.register_namespace("xlink", _XLINK)

STATUSES = {
    "established": ("Established in source", "#edf4ee", "#587b65"),
    "conditional": ("Conditional result", "#f7f1e5", "#96703b"),
    "open": ("Open", "#f1edf8", "#7b6495"),
    "hypothesis": ("Hypothesis", "#fbf4e7", "#94794b"),
    "model-case": ("Model case", "#ebf2fa", "#5b7c98"),
    "obstruction": ("Obstruction", "#faefeb", "#a56b55"),
    "definition": ("Definition", "#edf2f3", "#667f87"),
    "external": ("External input", "#f2f2ec", "#7f8060"),
    "withdrawn": ("Withdrawn", "#efefef", "#777777"),
}
KINDS = {
    "implication": ("Deduction", "#345f4c", "solid"),
    "conditional-implication": ("Conditional deduction", "#7c6239", "solid"),
    "proof-dependency": ("Proof input", "#607781", "dashed"),
    "open-step": ("Open step", "#7e6296", "dashed"),
    "obstruction": ("Blocked shortcut", "#a26049", "solid"),
}


def renderer_dependencies():
    """Files whose bytes affect generated diagrams or the HTML reader."""
    return [Path(__file__).resolve(), _ROOT / "assets/logic-map.css",
            _ROOT / "assets/logic-map.js"]


def _q(value):
    return json.dumps(str(value), ensure_ascii=False)


def _h(value):
    return html.escape(str(value), quote=True)


def _lines(value, width=30):
    return textwrap.wrap(str(value), width=width, break_long_words=False,
                         break_on_hyphens=False) or [""]


def _dot_text(value, width=30):
    return '<BR/>'.join(_h(line) for line in _lines(value, width))


def _selection(data, view):
    nodes = {n["id"]: n for n in data["nodes"]}
    relations = {r["id"]: r for r in data["relations"]}
    selected = set(view["relationIds"])
    groups = []
    owners = {}
    for group in data.get("alternatives", []):
        route_ids = [r for r in group["relations"] if r in selected]
        if len(route_ids) >= 2:
            groups.append((group, route_ids))
            for relation_id in route_ids:
                owners[relation_id] = group["id"]
    return nodes, relations, groups, owners


def _edges(data, view):
    """Typed visible edges; invisible layout constraints are added separately."""
    _, relations, groups, owners = _selection(data, view)
    edges = []
    for relation_id in view["relationIds"]:
        relation = relations[relation_id]
        kind = relation["kind"]
        for i, premise in enumerate(relation["from"]):
            edges.append(("n-" + premise, "r-" + relation_id, kind,
                          "normal", f"input-{relation_id}-{i}"))
        target = ("o-" + owners[relation_id] if relation_id in owners
                  else "n-" + relation["to"])
        edges.append(("r-" + relation_id, target, kind,
                      "tee" if kind == "obstruction" else "normal",
                      "output-" + relation_id))
    for group, _ in groups:
        edges.append(("o-" + group["id"], "n-" + group["to"],
                      "implication", "normal", "alternative-" + group["id"]))
    return edges


def _layout_constraints(vertices, edges):
    """Bound DAG rank width without adding visible mathematical relationships.

    Cyclic graphs (for example an explicitly recorded equivalence) retain
    Graphviz's ordinary layout. Their union is not judged as a proof plan here.
    """
    incoming = {v: 0 for v in vertices}
    outgoing = {v: [] for v in vertices}
    for left, right, *_ in edges:
        incoming[right] += 1
        outgoing[left].append(right)
    queue = [v for v in vertices if not incoming[v]]
    levels = {v: 0 for v in queue}
    visited = []
    while queue:
        node = queue.pop(0)
        visited.append(node)
        for target in outgoing[node]:
            levels[target] = max(levels.get(target, 0), levels[node] + 1)
            incoming[target] -= 1
            if incoming[target] == 0:
                queue.append(target)
    if len(visited) != len(vertices):
        return []
    ranks = {}
    for vertex in vertices:
        ranks.setdefault(levels[vertex], []).append(vertex)
    result = []
    for level in sorted(ranks):
        nodes = ranks[level]
        chunks = [nodes[i:i + 4] for i in range(0, len(nodes), 4)]
        for chunk in chunks:
            result.append("  { rank=same; " + "; ".join(map(_q, chunk)) + "; }")
        for previous, following in zip(chunks, chunks[1:]):
            result.append(f"  {_q(previous[-1])} -> {_q(following[0])} "
                          '[style=invis, weight=2, minlen=2];')
    return result


def render_dot(data, view):
    """Produce deterministic Graphviz DOT with explicit AND/OR gates."""
    nodes, relations, groups, owners = _selection(data, view)
    lines = ["digraph LogicMap {",
             '  graph [rankdir=TB, bgcolor="transparent", pad=0.22, nodesep=0.35, '
             'ranksep=0.55, splines=polyline, outputorder=edgesfirst, fontname="Arial"];',
             '  node [shape=box, style="rounded,filled", fontname="Arial", '
             'fontsize=17, margin="0.15,0.12", penwidth=1.1];',
             '  edge [arrowsize=0.65, penwidth=1.15, color="#607781"];']
    for node_id in view["nodeIds"]:
        node = nodes[node_id]
        status, fill, stroke = STATUSES[node["status"]]
        label = ('<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0">'
                 f'<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="10" COLOR="{stroke}">'
                 f'{_h(status.upper())}</FONT></TD></TR>'
                 '<TR><TD HEIGHT="5"></TD></TR>'
                 f'<TR><TD><B>{_dot_text(node["label"])}</B></TD></TR>'
                 '</TABLE>>')
        lines.append(f'  {_q("n-" + node_id)} [id={_q("node-" + node_id)}, '
                     f'fillcolor={_q(fill)}, color={_q(stroke)}, label={label}, '
                     f'URL={_q("#node-" + node_id)}, target="_top", '
                     f'tooltip={_q(node["statement"])}];')
    for relation_id in view["relationIds"]:
        relation = relations[relation_id]
        kind, color, style = KINDS[relation["kind"]]
        heading = ("AND · " if len(relation["from"]) > 1 else "") + kind
        conditions = relation["conditions"]
        condition_text = (f'{len(conditions)} additional '
                          f'{"hypothesis applies" if len(conditions) == 1 else "hypotheses apply"}'
                          if conditions else "Full scope at the linked argument")
        label = ('<<TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0">'
                 f'<TR><TD><FONT POINT-SIZE="12" COLOR="{color}">{_h(heading)}</FONT></TD></TR>'
                 f'<TR><TD><FONT POINT-SIZE="16">{_dot_text(relation["label"], 33)}</FONT></TD></TR>'
                 f'<TR><TD><FONT POINT-SIZE="10">{_h(condition_text)}</FONT></TD></TR>'
                 '</TABLE>>')
        tooltip = relation["explanation"]
        if conditions:
            tooltip += " Additional hypotheses: " + " ".join(conditions)
        lines.append(f'  {_q("r-" + relation_id)} [id={_q("relation-" + relation_id)}, '
                     f'fillcolor="#ffffff", color={_q(color)}, '
                     f'style={_q("rounded,filled," + style)}, label={label}, '
                     f'URL={_q("#relation-" + relation_id)}, target="_top", tooltip={_q(tooltip)}];')
    for group, route_ids in groups:
        label = f'OR\n{group["label"]}\n{len(route_ids)} sufficient routes'
        lines.append(f'  {_q("o-" + group["id"])} [id={_q("alternative-" + group["id"])}, '
                     f'shape=diamond, fillcolor="#f3f5eb", color="#6a7750", '
                     f'fontsize=15, label={_q(label)}, '
                     f'URL={_q("#alternative-" + group["id"])}, target="_top", '
                     f'tooltip={_q(group["explanation"])}];')
    edges = _edges(data, view)
    for left, right, kind, arrow, edge_id in edges:
        _, color, style = KINDS[kind]
        lines.append(f'  {_q(left)} -> {_q(right)} [id={_q("edge-" + edge_id)}, '
                     f'color={_q(color)}, style={_q(style)}, arrowhead={_q(arrow)}];')
    vertices = (["n-" + x for x in view["nodeIds"]]
                + ["r-" + x for x in view["relationIds"]]
                + ["o-" + group["id"] for group, _ in groups])
    lines.extend(_layout_constraints(vertices, edges))
    lines.append("}")
    return "\n".join(lines) + "\n"


def render_svg(dot, view_id):
    """Run Graphviz and give every internal SVG identity a unique view prefix."""
    executable = shutil.which("dot")
    if executable is None:
        raise RuntimeError("Graphviz dot is unavailable; install Graphviz or export DOT/text only.")
    try:
        result = subprocess.run([executable, "-Tsvg"], input=dot, text=True,
                                capture_output=True, timeout=60, check=True)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Graphviz rendering exceeded 60 seconds.") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError("Graphviz could not render this graph: " + exc.stderr[:1500]) from exc
    root = ET.fromstring(result.stdout)
    # Length-prefix the view component: e.g. views a and a-node cannot collide
    # when record IDs themselves contain hyphens or namespace-like words.
    prefix = "lm-v" + str(len(view_id)) + "-" + view_id + "-"
    identities = {el.attrib["id"]: prefix + el.attrib["id"]
                  for el in root.iter() if "id" in el.attrib}
    for el in root.iter():
        old_id = el.attrib.get("id", "")
        if old_id:
            el.set("id", identities[old_id])
        if el.attrib.get("class") == "node":
            for marker, attribute in (("node-", "data-logic-node"),
                                      ("relation-", "data-logic-relation"),
                                      ("alternative-", "data-logic-alternative")):
                if old_id.startswith(marker):
                    el.set(attribute, old_id[len(marker):])
                    break
        elif el.attrib.get("class") == "edge":
            el.set("data-logic-edge", old_id.removeprefix("edge-"))
        for name, value in list(el.attrib.items()):
            # The href fragments intentionally address canonical HTML records,
            # not the internal SVG groups whose IDs have just been namespaced.
            if "url(#" in value:
                el.set(name, re.sub(r"url\(#([^)]*)\)",
                                   lambda m: "url(#" + identities.get(m[1], m[1]) + ")", value))
            if name in ("aria-labelledby", "aria-describedby"):
                el.set(name, " ".join(identities.get(x, x) for x in value.split()))
    view_box = root.attrib.get("viewBox", "0 0 100 100").split()
    root.set("width", view_box[2])
    root.set("height", view_box[3])
    root.set("data-natural-width", view_box[2])
    root.set("data-natural-height", view_box[3])
    root.set("role", "group")
    root.set("aria-label", "Logical diagram; use its linked nodes and argument gates")
    return ET.tostring(root, encoding="unicode")


def _source_links(source_ids, sources):
    return '<ul class="lm-sources">' + ''.join(
        f'<li><a href="{_h(sources[s]["href"])}">{_h(sources[s]["label"])}</a></li>'
        for s in source_ids) + '</ul>'


def _badge(node):
    return (f'<span class="lm-status lm-status-{_h(node["status"])}">'
            f'{_h(STATUSES[node["status"]][0])}</span>')


def _node_link(node):
    return (_badge(node) + f'<a href="#node-{_h(node["id"])}">'
            f'{_h(node["label"])}</a>')


def _conditions(relation):
    if not relation["conditions"]:
        return '<p class="lm-condition-note">No additional hypotheses are recorded for this connection.</p>'
    return ('<h5>Additional hypotheses</h5><ul class="lm-conditions">'
            + ''.join(f'<li>{_h(x)}</li>' for x in relation["conditions"]) + '</ul>')


def _flow(relation, nodes, prefix):
    kind = relation["kind"]
    destination = {
        "implication": "Conclusion",
        "conditional-implication": "Conclusion under these hypotheses",
        "proof-dependency": "Proof receiving these inputs",
        "open-step": "Target still requiring an argument",
        "obstruction": "Target of the blocked shortcut",
    }[kind]
    gate = ("AND · " if len(relation["from"]) > 1 else "") + KINDS[kind][0]
    return (f'<article class="lm-flow lm-kind-{_h(kind)}" '
            f'id="flow-{_h(prefix)}-{_h(relation["id"])}">'
            f'<h4>{_h(relation["label"])}</h4>'
            '<h5>Joint premises</h5><ul class="lm-premises">'
            + ''.join(f'<li>{_node_link(nodes[x])}</li>' for x in relation["from"])
            + '</ul><div class="lm-flow-connector" aria-hidden="true">↓</div>'
            + f'<p class="lm-gate"><a href="#relation-{_h(relation["id"])}">{_h(gate)}</a></p>'
            + _conditions(relation)
            + '<div class="lm-flow-connector" aria-hidden="true">↓</div>'
            + f'<h5>{destination}</h5><p class="lm-target">{_node_link(nodes[relation["to"]])}</p>'
            + f'<p class="lm-prose">{_h(relation["explanation"])}</p>'
            + f'<a class="lm-detail-link" href="#relation-{_h(relation["id"])}">Full argument and sources →</a>'
            + '</article>')


def _view_html(data, view, svg, first):
    nodes, relations, groups, owners = _selection(data, view)
    group_index = {group["id"]: (group, routes) for group, routes in groups}
    flow_blocks, done_groups = [], set()
    for relation_id in view["relationIds"]:
        group_id = owners.get(relation_id)
        if group_id and group_id in done_groups:
            continue
        if group_id:
            done_groups.add(group_id)
            group, routes = group_index[group_id]
            flow_blocks.append(
                f'<section class="lm-alternative-flow"><h4>OR · {_h(group["label"])}</h4>'
                f'<p>{_h(group["explanation"])}</p>'
                '<p>Each route below is sufficient under its own full premises and hypotheses.</p>'
                + ''.join(_flow(relations[r], nodes, "view-" + str(len(view["id"])) + "-" + view["id"]) for r in routes)
                + f'<a href="#alternative-{_h(group_id)}">Compare these sufficient routes →</a></section>')
        else:
            flow_blocks.append(_flow(relations[relation_id], nodes, "view-" + str(len(view["id"])) + "-" + view["id"]))
    related = {n for r in view["relationIds"] for n in relations[r]["from"] + [relations[r]["to"]]}
    isolated = [nodes[x] for x in view["nodeIds"] if x not in related]
    if isolated:
        flow_blocks.append('<section class="lm-independent"><h4>Other recorded assertions in this view</h4>'
                           '<p>No connection is asserted for these records in this view.</p><ul>'
                           + ''.join(f'<li>{_node_link(n)}</li>' for n in isolated) + '</ul></section>')
    node_options = ''.join(f'<option value="{_h(n)}">{_h(nodes[n]["label"])} · '
                           f'{_h(STATUSES[nodes[n]["status"]][0])}</option>' for n in view["nodeIds"])
    step_options = ''.join(f'<option value="flow-view-{len(view["id"])}-{_h(view["id"])}-{_h(r)}">'
                          f'{_h(relations[r]["label"])}</option>' for r in view["relationIds"])
    view_id = _h(view["id"])
    full = ' · Complete declared graph' if view.get("complete") else ' · Selected reading view'
    diagram = (f'<div class="lm-svg-zone"><figure class="lm-figure" data-logic-view="{view_id}">'
               '<figcaption>Read arrows from top to bottom. Click a record for its scope, or a gate for the full argument.</figcaption>'
               f'<div class="lm-locator"><label for="find-{view_id}">Find a result</label>'
               f'<select id="find-{view_id}" class="lm-node-find"><option value="">Choose an assertion…</option>'
               + node_options + '</select><button type="button" data-action="clear">Clear highlight</button></div>'
               '<div class="lm-toolbar">'
               '<button type="button" data-action="minus" aria-label="Reduce diagram scale">−</button>'
               '<output class="lm-scale" aria-live="polite">100%</output>'
               '<button type="button" data-action="plus" aria-label="Enlarge diagram scale">+</button>'
               '<button type="button" data-action="fit">Fit whole width</button>'
               '<button type="button" data-action="reset">Readable size</button>'
               '<button type="button" data-action="height" aria-pressed="false">Show full height</button>'
               '</div>'
               f'<div class="lm-canvas" tabindex="0" role="region" aria-label="{_h(view["title"])} — scrollable logical diagram">'
               + svg + '</div></figure></div>') if svg else (
                   '<p class="lm-render-note">Graphviz SVG is not included in this text/DOT export. '
                   'The complete connected reading view follows.</p>')
    return (f'<details class="lm-view" name="logic-map-views" id="view-{view_id}"'
            + (' open' if first else '') + '><summary><span>'
            + _h(view["title"]) + f'</span><small>{len(view["nodeIds"])} nodes · '
            + f'{len(view["relationIds"])} connections{full}</small></summary>'
            + f'<p class="lm-view-description">{_h(view["description"])}</p>' + diagram
            + '<details class="lm-text-view" open><summary>Read the connected text version</summary>'
            + f'<label class="lm-step-label" for="step-{view_id}">Find a logical step</label>'
            + f'<select class="lm-step-find" id="step-{view_id}"><option value="">Choose a connection…</option>'
            + step_options + '</select><div class="lm-flows">' + ''.join(flow_blocks)
            + '</div></details></details>')


def render_html(data, views_with_svg):
    """Return an offline HTML reader with source-bound graphs and text flows."""
    nodes = {n["id"]: n for n in data["nodes"]}
    relations = {r["id"]: r for r in data["relations"]}
    sources = {s["id"]: s for s in data["sources"]}
    css = (_ROOT / "assets/logic-map.css").read_text(encoding="utf-8")
    javascript = (_ROOT / "assets/logic-map.js").read_text(encoding="utf-8")
    views_with_svg = list(views_with_svg)
    view_nav = ''.join(f'<a href="#view-{_h(v["id"])}">{_h(v["title"])}</a>'
                       for v, _ in views_with_svg)
    views = ''.join(_view_html(data, view, svg, i == 0)
                    for i, (view, svg) in enumerate(views_with_svg))
    node_details = []
    for node in data["nodes"]:
        node_details.append(
            f'<details class="lm-record" id="node-{_h(node["id"])}" tabindex="-1">'
            f'<summary>{_badge(node)}<strong>{_h(node["label"])}</strong></summary>'
            f'<h4>Statement</h4><p class="lm-prose">{_h(node["statement"])}</p>'
            f'<h4>Scope</h4><p class="lm-prose">{_h(node["scope"])}</p>'
            + (f'<p><a href="{_h(node["href"])}">Canonical result or problem →</a></p>' if node.get("href") else '')
            + '<h4>Sources</h4>' + _source_links(node["sourceIds"], sources)
            + f'<p><a href="#node-{_h(node["id"])}">Link to this record</a></p></details>')
    relation_details = []
    for relation in data["relations"]:
        kind = relation["kind"]
        relation_details.append(
            f'<details class="lm-record lm-kind-{_h(kind)}" id="relation-{_h(relation["id"])}" tabindex="-1">'
            f'<summary><span class="lm-relation-kind">{_h(KINDS[kind][0])}</span>'
            f'<strong>{_h(relation["label"])}</strong></summary>'
            + _flow(relation, nodes, "canonical")
            + (f'<p><a href="{_h(relation["href"])}">Canonical argument →</a></p>' if relation.get("href") else '')
            + '<h4>Sources</h4>' + _source_links(relation["sourceIds"], sources)
            + f'<p><a href="#relation-{_h(relation["id"])}">Link to this logical connection</a></p></details>')
    alternatives = []
    for group in data.get("alternatives", []):
        alternatives.append(
            f'<details class="lm-record" id="alternative-{_h(group["id"])}" tabindex="-1">'
            f'<summary><span class="lm-relation-kind">OR · Sufficient alternatives</span>'
            f'<strong>{_h(group["label"])}</strong></summary>'
            f'<p class="lm-prose">{_h(group["explanation"])}</p>'
            '<p>Each listed argument supplies the target under its own premises and additional hypotheses.</p><ul>'
            + ''.join(f'<li><a href="#relation-{_h(r)}">{_h(relations[r]["label"])}</a></li>' for r in group["relations"])
            + f'</ul><p>Common target: {_node_link(nodes[group["to"]])}</p></details>')
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<meta name="description" content="{_h(data["scope"])}">'
            f'<title>{_h(data["title"])}</title><style>{css}</style></head><body>'
            '<a class="lm-skip" href="#main">Skip to the logical map</a>'
            '<main id="main"><header class="lm-header"><p class="lm-eyebrow">Mathematical logical map</p>'
            f'<h1>{_h(data["title"])}</h1><p>{_h(data["scope"])}</p>'
            f'<p class="lm-meta">Source version: {_h(data["version"])} · '
            f'{len(data["nodes"])} nodes · {len(data["relations"])} connections</p>'
            '</header><nav class="lm-view-nav" aria-label="Reading views">' + view_nav
            + '<a href="#records">Precise records and sources</a></nav>'
            '<section class="lm-legend" aria-label="How to read this map">'
            '<p><strong>AND</strong> retains every joint premise and every additional hypothesis. '
            '<strong>OR</strong> joins separately sufficient arguments.</p>'
            '<ul><li><span class="lm-line deduction"></span>Deduction under its stated hypotheses</li>'
            '<li><span class="lm-line input"></span>Input to the linked proof</li>'
            '<li><span class="lm-line open"></span>Open mathematical step</li>'
            '<li><span class="lm-line obstruction"></span>Obstructed shortcut</li></ul>'
            '</section>' + views
            + '<section id="records" class="lm-records"><h2>Precise records and sources</h2>'
            '<p>Source statuses are retained as recorded; drawing a connection is not an independent proof review.</p>'
            '<h3>Assertions and problems</h3>' + ''.join(node_details)
            + '<h3>Logical connections</h3>' + ''.join(relation_details)
            + ('<h3>Alternative sufficient arguments</h3>' + ''.join(alternatives) if alternatives else '')
            + '</section><footer><a href="#main">Back to the map</a></footer></main>'
            f'<script>{javascript}</script></body></html>')


def render_mermaid(data, view):
    """Export a compact logical figure; HTML remains the full conditions reader.

    Full hypotheses are included in gate labels. Larger graphs must use SVG
    or be split into semantically complete views, never omit a premise.
    """
    if len(view["nodeIds"]) > 12 or len(view["relationIds"]) > 10:
        raise ValueError("Mermaid export is limited to 12 nodes and 10 connections; split the view or use SVG.")
    nodes, relations, groups, owners = _selection(data, view)
    vertices = (["n-" + x for x in view["nodeIds"]]
                + ["r-" + x for x in view["relationIds"]]
                + ["o-" + g["id"] for g, _ in groups])
    names = {vertex: f"m{i}" for i, vertex in enumerate(vertices)}

    def label(value):
        value = " ".join(str(value).split())
        return value.replace("&", "#amp;").replace('"', "#quot;").replace("<", "#lt;").replace(">", "#gt;")

    lines = ["flowchart TD"]
    for node_id in view["nodeIds"]:
        node = nodes[node_id]
        lines.append(f'  {names["n-" + node_id]}["{label(STATUSES[node["status"]][0] + ": " + node["label"])}"]')
    for relation_id in view["relationIds"]:
        relation = relations[relation_id]
        heading = ("AND · " if len(relation["from"]) > 1 else "") + KINDS[relation["kind"]][0]
        heading += ": " + relation["label"]
        if relation["conditions"]:
            heading += ". Additional hypotheses: " + "; ".join(relation["conditions"])
        lines.append(f'  {names["r-" + relation_id]}{{"{label(heading)}"}}')
    for group, routes in groups:
        lines.append(f'  {names["o-" + group["id"]]}{{"OR · {label(group["label"])}"}}')
    for left, right, kind, arrow, _ in _edges(data, view):
        connector = "--x" if arrow == "tee" else ("-.->" if KINDS[kind][2] == "dashed" else "-->")
        lines.append(f"  {names[left]} {connector} {names[right]}")
    return "\n".join(lines) + "\n"
