# math-project-maintainer

Public, fixed-date distribution of the mathematical skill.
Extract the single top-level folder into your agent's skills directory, then follow its SKILL.md. The public publisher package omits the owner-specific Site binding. No background service, mathematical proof certification, or automatic synchronization is included.
For interactive logical maps use Python 3.10+ and Graphviz (`dot`).
