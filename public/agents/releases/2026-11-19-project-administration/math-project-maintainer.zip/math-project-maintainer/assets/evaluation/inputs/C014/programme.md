# A synthetic local-to-global programme

Let V and W be Q-vector spaces, N⊂V and M⊂W subspaces, and I a countable index set. For each i∈I, a local construction is intended to provide a set Gi of choices and numbers li(g;v,w)∈R, with g∈Gi, v∈V, w∈W.

The only current assertion is Conjecture L: every Gi is nonempty. There are no current assertions of additivity, choice independence or summability. A proposed route uses compatible local linear operators; an alternative proposed route uses local variational constructions. Neither route has a supplied proof.

The first target is a canonical Q-bilinear pairing h:(V/N)×(W/M)→R obtained by summing li over i. The definition is required to be independent of local choices and representatives and of the ordering of I. No reference pairing has yet been chosen for a comparison.

For a later stage set W=V and M=N, and assume that V/N embeds in a finite-dimensional real vector space E. The second target is a symmetric positive definite extension H on E. The third target, as currently written, is: for every real B, only finitely many x∈V/N satisfy H(x,x)≤B. One proposed variant replaces V/N by a specified lattice Λ⊂E; the relationship of such a lattice to the original arithmetic objects has not been established.

The draft plan is “local existence ⇒ global pairing ⇒ positivity ⇒ finiteness”. It lists “local machinery”, “global machine”, “positive engine” and “final finiteness” as headings. It presents the two local routes as consecutive required stages.
