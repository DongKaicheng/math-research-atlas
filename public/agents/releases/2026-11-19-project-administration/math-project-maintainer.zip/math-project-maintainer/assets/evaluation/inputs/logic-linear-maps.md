# Supplied source: two routes to invertibility

Fix a field k, finite-dimensional k-vector spaces V,W, and a k-linear map
T:V→W. The conclusions refer to this fixed map. This excerpt is the full source
for the requested diagram; it is a demonstration, not a new research result.

## Route through injectivity

Suppose dim(V)=dim(W) and T is injective. Rank-nullity gives
rank(T)=dim(V)=dim(W), hence surjectivity. An injective and surjective linear map
has a linear inverse: write w_i=T(v_i); uniqueness of inverse images gives
T^{-1}(a w_1+b w_2)=a v_1+b v_2. Thus T is an isomorphism.

## Route through a determinant

Suppose dim(V)=dim(W)=n≥1 and fix bases of V and W. Let A be the matrix of T
in these bases. If det(A)≠0, then adj(A)/det(A) is its inverse. It defines a
linear inverse of T. This is another sufficient route to the same isomorphism
conclusion; injectivity does not also have to be assumed for this route.

## A failed shortcut

Without the dimension equality, injectivity is insufficient: k→k²,
x↦(x,0), is injective and linear but not surjective. This blocks the inference
from bare injectivity to an isomorphism; it does not refute either route above.

## A boundary of this excerpt

The excerpt does not supply a theorem about topological vector spaces or
continuity of the inverse. An extension in that direction would have to state
the topology and the necessary completeness or other hypotheses, then justify
inverse continuity. Keep that extension unproved in this excerpt; do not claim
that it is an unresolved problem in the literature.
