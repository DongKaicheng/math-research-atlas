# A group isomorphism diagram example

This supplied demonstration is independent of any research project. Let G and H
be groups and f:G→H a homomorphism. All properties below refer to this same map.

## Arguments

1. If ker(f)={1}, then f is injective: f(x)=f(y) implies f(y⁻¹x)=1, so y⁻¹x=1.
2. If f is injective and surjective, it has an inverse as a set map. For b,c in H,
   choose their unique inverse images x,y. Since f(xy)=bc, the inverse of bc is
   xy. Thus the inverse map is a homomorphism and f is a group isomorphism.
3. If ker(f)={1} and f is surjective, apply Arguments 1 and 2.
4. A group isomorphism is bijective, because it has a two-sided inverse.
5. A bijective homomorphism is a group isomorphism by Argument 2.

Arguments 2, 3 and 5 are alternative sufficient routes under their respective
premises. Arguments 4 and 5 create reciprocal implications in the complete
graph. They are not circular support when the chosen proof uses Arguments 1,
2 and 4 from the declared hypotheses.
