(() => {
  'use strict';
  const narrow = window.matchMedia('(max-width: 800px)');
  const textViews = [...document.querySelectorAll('.lm-text-view')];
  function setReadingMode() {
    for (const details of textViews) {
      const hasSvg = !!details.closest('.lm-view').querySelector('svg');
      details.open = narrow.matches || !hasSvg;
    }
  }
  setReadingMode();
  if (narrow.addEventListener) narrow.addEventListener('change', setReadingMode);
  function reveal(id, scroll = true) {
    const target = document.getElementById(id);
    if (!target) return;
    const ancestors = [];
    for (let el = target; el; el = el.parentElement) {
      if (el.tagName === 'DETAILS') ancestors.push(el);
    }
    for (const el of ancestors.reverse()) el.open = true;
    if (scroll) requestAnimationFrame(() => target.scrollIntoView({ block: 'start' }));
  }
  function revealHash() {
    try { reveal(decodeURIComponent(location.hash.slice(1))); } catch (_) { /* Invalid fragment has no target. */ }
  }
  window.addEventListener('hashchange', revealHash);
  document.addEventListener('click', event => {
    const link = event.target.closest('a');
    const href = link?.getAttribute('href') || link?.getAttribute('xlink:href');
    if (href?.startsWith('#')) {
      try { reveal(decodeURIComponent(href.slice(1)), false); } catch (_) { /* Leave native link handling intact. */ }
    }
  });
  for (const select of document.querySelectorAll('.lm-step-find')) {
    select.addEventListener('change', () => {
      if (select.value) location.hash = select.value;
    });
  }
  for (const figure of document.querySelectorAll('[data-logic-view]')) {
    const canvas = figure.querySelector('.lm-canvas');
    const svg = canvas.querySelector('svg');
    if (!svg) continue;
    const width = Number(svg.dataset.naturalWidth);
    const height = Number(svg.dataset.naturalHeight);
    const output = figure.querySelector('.lm-scale');
    const find = figure.querySelector('.lm-node-find');
    let scale = 1;
    function resize(value) {
      scale = Math.max(0.001, Math.min(4, value));
      svg.style.width = `${width * scale}px`;
      svg.style.height = `${height * scale}px`;
      output.value = `${Math.round(scale * 1000) / 10}%`;
      output.textContent = output.value;
    }
    function clear() {
      for (const node of svg.querySelectorAll('.lm-highlight')) node.classList.remove('lm-highlight');
    }
    function locate() {
      clear();
      if (!find.value) return;
      const node = [...svg.querySelectorAll('[data-logic-node]')].find(el => el.dataset.logicNode === find.value);
      if (!node) return;
      if (scale < 0.7) resize(1);
      node.classList.add('lm-highlight');
      requestAnimationFrame(() => {
        const box = node.getBoundingClientRect();
        const frame = canvas.getBoundingClientRect();
        canvas.scrollTo({left: canvas.scrollLeft + box.left - frame.left - (canvas.clientWidth - box.width) / 2,
                         top: canvas.scrollTop + box.top - frame.top - (canvas.clientHeight - box.height) / 2});
      });
    }
    find.addEventListener('change', locate);
    figure.addEventListener('click', event => {
      const button = event.target.closest('button[data-action]');
      if (!button) return;
      switch (button.dataset.action) {
        case 'minus': resize(scale / 1.25); break;
        case 'plus': resize(scale * 1.25); break;
        case 'fit': resize(Math.min(1, Math.max(1, canvas.clientWidth - 24) / width)); break;
        case 'reset': resize(1); break;
        case 'clear': clear(); find.value = ''; break;
        case 'height': {
          const full = canvas.classList.toggle('is-full-height');
          button.setAttribute('aria-pressed', String(full));
          button.textContent = full ? 'Return to scrolling view' : 'Show full height';
          break;
        }
      }
    });
    resize(1);
  }
  revealHash();
})();
