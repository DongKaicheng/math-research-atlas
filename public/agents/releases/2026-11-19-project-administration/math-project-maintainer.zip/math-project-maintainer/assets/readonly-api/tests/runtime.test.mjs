import test from "node:test";
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {spawnSync} from "node:child_process";
import {createReadonlyAPI} from "../runtime.mjs";

function canonical(value) {
  if (Array.isArray(value)) return "["+value.map(canonical).join(",")+"]";
  if (value!==null && typeof value==="object") return "{"+Object.keys(value).sort().map(key=>JSON.stringify(key)+":"+canonical(value[key])).join(",")+"}";
  return JSON.stringify(value);
}
const hash=value=>createHash("sha256").update(typeof value==="string"?value:canonical(value)).digest("hex");
const source={path:"content/main.tex",start_line:1,end_line:4};
function item(id,statement,{deps=[],proof=null,status="reviewed",title="",kind="lemma",label=id.toLowerCase(),contexts=[]}={}) {
  return {id,kind,title,labels:[label],section:["Quotients"],revision:hash(id+" revision"),declaration_revision:hash(id+" declaration"),status,
    admission:status==="admitted"?{kind:"assumption"}:null,statement:{text:statement,hash:hash(statement),source:{...source}},
    proof:proof===null?null:{id:id+":proof:1",revision:hash(id+proof),text:proof,source:{path:"content/main.tex",start_line:5,end_line:8}},
    contexts,dependencies:deps,applications:deps.map((target_id,index)=>({application_key:"app-"+id+index,scope:"proof",target_id,target_revision:hash(target_id+" declaration"),
      relation:"uses",substitution:"Use the same valued field.",hypotheses:[{required:"K is non-Archimedean.",discharge:"The bound ambient context fixes K."}],no_hypotheses:false,conclusion:"The cited premise applies.",target_clause:null})),
    references:deps.map(target_id=>({label:target_id.toLowerCase(),command:"ref",line:6,scope:"proof",target_id,relation:"candidate_reference"})),citations:[]};
}
function sealed(data) { const value=JSON.parse(JSON.stringify(data)); delete value.corpus_id; return {...value,corpus_id:hash(value)}; }
function fixture() {
  const context={key:"valued-field",revision:hash("context"),text:"K is a fixed non-Archimedean valued field; trivial valuation is allowed."};
  const items={
    "T-001":item("T-001","K is a fixed valued field.",{status:"admitted",kind:"assumption",title:"Fixed field"}),
    "T-002":item("T-002",String.raw`The quotient seminorm is $q(v+W)=\inf_{w\in W}p(v+w)$.`,{deps:["T-001"],title:"Quotient seminorm",proof:"For any representative v, taking the infimum proves the assertion.",contexts:[context],label:"lem-quotient"}),
    "T-003":item("T-003",String.raw`If V is complete, then V/W is complete. The symbol \Gamma is uppercase.`,{deps:["T-002"],title:"Complete quotient",proof:"Lift a Cauchy subsequence. The lifts converge; then the full sequence converges.",contexts:[context],label:"prop-complete"}),
    "T-004":item("T-004",String.raw`The symbol \gamma is lowercase; the morphism is bounded.`,{deps:["T-002"],title:"Bounded maps",proof:"The induced map is bounded by the same constant.",contexts:[context]}),
    "T-005":item("T-005","Both conclusions hold.",{deps:["T-003","T-004"],title:"Combined conclusion",proof:"Apply both preceding results."}),
    "T-006":item("T-006","A Cauchy sequence is defined by the following condition.",{kind:"definition",title:"Cauchy sequences"})};
  items["T-003"].citations=[{source_key:"reference",source_revision:hash("source"),title:"Source with exact locator",uri:"https://example.org/paper",version:null,
    content_sha256:hash("source bytes"),citation_id:"cite-001",citation_revision:hash("citation"),locator:{theorem:"4.2",page:"12"},status:"checked",scope:"proof",reference_ids:["citation-occurrence-1"],
    assumptions:[{required:"Source completeness premise.",discharge:"The displayed hypothesis provides it."}],no_assumptions:false,
    substitution:"Identify the quotient objects with the source theorem.",conclusion:"The externally cited conclusion applies."}];
  return sealed({schema_version:1,format:"math-project-public-corpus",project:{title:"Published quotient study",namespace:"T",demo:true},
    release:{id:hash("release"),name:"reviewed-v1",snapshot:hash("snapshot"),created_at:"2026-11-17T00:00:00Z",kind:"reviewed_release",meaning:"Frozen selected support, not formal verification."},
    requested:["T-005"],order:Object.keys(items),items});
}
function harness(corpus=fixture(),options={}) {
  const api=createReadonlyAPI(corpus,options);
  const get=async(path,init)=>{const response=await api.fetch(new Request("https://math.example"+path,init));let body=null; if(response.status!==304&&response.status!==204&&init?.method!=="HEAD") { const raw=await response.text(); body=raw?JSON.parse(raw):null; } return {response,body};};
  const rpc=async(message,headers={})=>get("/mcp",{method:"POST",headers:{"Content-Type":"application/json",...headers},body:JSON.stringify(message)});
  const call=async(name,args={})=>rpc({jsonrpc:"2.0",id:1,method:"tools/call",params:{name,arguments:args}});
  return {api,get,rpc,call,corpus};
}

test("publication reads preserve identities, source lines, admissions and exact source revisions",async()=>{
  const {get,corpus}=harness();
  const info=await get("/api/v1/project");
  assert.equal(info.response.status,200); assert.equal(info.body.corpus_id,corpus.corpus_id);
  assert.deepEqual(info.body.counts,{results:6,reviewed:5,admitted:1,proofs:4,kinds:{assumption:1,lemma:4,definition:1}});
  const result=(await get("/api/v1/results/T-003")).body.item;
  assert.equal(result.statement.text,corpus.items["T-003"].statement.text);
  assert.equal(result.proof.revision,corpus.items["T-003"].proof.revision);
  assert.equal(result.citation.url,`https://math.example/results/T-003?corpus=${corpus.corpus_id}`);
  assert.deepEqual(result.statement.source,source);
  const sources=(await get("/api/v1/results/T-003/sources")).body.sources;
  assert.equal(sources[0].content_sha256,hash("source bytes")); assert.equal(sources[0].version,null);
  assert.equal(sources[0].citation_id,"cite-001"); assert.equal(sources[0].citation_revision,hash("citation"));
  assert.equal(sources[0].assumptions[0].required,"Source completeness premise.");
  assert.equal(sources[0].no_assumptions,false); assert.equal(sources[0].conclusion,"The externally cited conclusion applies.");
  const admitted=(await get("/api/v1/results/T-001/proof")).body;
  assert.equal(admitted.status,"admitted"); assert.equal(admitted.proof,null); assert.equal(admitted.no_proof_reason,"admitted_input");
  assert.equal((await get("/api/v1/results/T-006/proof")).body.no_proof_reason,"reviewed_declaration");
});

test("exact public label resolves to permanent ID and ambiguous labels are not guessed",async()=>{
  const {get}=harness();
  assert.equal((await get("/api/v1/results/prop-complete")).body.item.id,"T-003");
  const corpus=fixture(); corpus.items["T-004"].labels.push("prop-complete");
  const ambiguous=await harness(sealed(corpus)).get("/api/v1/results/prop-complete");
  assert.equal(ambiguous.response.status,409); assert.equal(ambiguous.body.error.code,"ambiguous_label");
});

test("lexical AND queries can span statement and proof but preserve TeX command case",async()=>{
  const {get}=harness();
  assert.deepEqual((await get("/api/v1/search?q="+encodeURIComponent(String.raw`\Gamma`))).body.results.map(row=>row.id),["T-003"]);
  assert.deepEqual((await get("/api/v1/search?q="+encodeURIComponent(String.raw`\gamma`))).body.results.map(row=>row.id),["T-004"]);
  const spanning=(await get("/api/v1/search?q=complete%20subsequence")).body;
  assert.deepEqual(spanning.results.map(row=>row.id),["T-003"]);
  assert.ok(spanning.results[0].matched_fields.includes("proof"));
  assert.equal((await get("/api/v1/search?q=COMPLETE")).body.results[0].id,"T-003");
  assert.equal((await get("/api/v1/search?q=bounded%20unrepresented")).body.total,0);
});

test("exact TeX substring and punctuation use literal matching, not SQL or a query interpreter",async()=>{
  const {get}=harness();
  const exact=(await get("/api/v1/search?mode=exact&q="+encodeURIComponent("q(v+W)="))).body;
  assert.equal(exact.total,1); assert.equal(exact.results[0].id,"T-002");
  assert.equal((await get("/api/v1/search?mode=exact&q="+encodeURIComponent("q(v+w)="))).body.total,0);
  for (const q of ["' OR 1=1 --",'";DROP TABLE results;--',"$(touch /tmp/pwn)","file:///etc/passwd",String.raw`\Gamma OR \gamma`]) {
    const result=await get("/api/v1/search?q="+encodeURIComponent(q));
    assert.equal(result.response.status,200); assert.equal(result.body.total,0);
  }
});

test("search pagination is stable, exhaustive and filtered before pagination",async()=>{
  const {get}=harness();
  const first=(await get("/api/v1/search?limit=2")).body;
  assert.equal(first.total,6); assert.equal(first.next_offset,2);
  const second=(await get("/api/v1/search?limit=2&offset=2")).body;
  const third=(await get("/api/v1/search?limit=2&offset=4")).body;
  assert.equal(third.next_offset,null);
  assert.deepEqual([...first.results,...second.results,...third.results].map(row=>row.id),fixture().order);
  const filtered=(await get("/api/v1/search?kind=definition&limit=1")).body;
  assert.equal(filtered.total,1); assert.equal(filtered.results[0].id,"T-006");
});

test("selected support traversal handles diamonds, reverse edges and explicit frontier omissions",async()=>{
  const {get}=harness();
  const graph=(await get("/api/v1/results/T-005/dependencies?depth=8")).body;
  assert.equal(graph.truncated,false); assert.equal(new Set(graph.nodes.map(row=>row.id)).size,5);
  assert.ok(graph.edges.some(edge=>edge.from==="T-003"&&edge.to==="T-002"));
  assert.equal(graph.nodes.find(row=>row.id==="T-002").distance,2);
  const reverse=(await get("/api/v1/results/T-002/dependencies?direction=dependents&depth=8")).body;
  assert.deepEqual(new Set(reverse.nodes.map(row=>row.id)),new Set(["T-002","T-003","T-004","T-005"]));
  assert.ok(reverse.edges.every(edge=>fixture().items[edge.from].dependencies.includes(edge.to)));
  const short=(await get("/api/v1/results/T-005/dependencies?depth=1")).body;
  assert.equal(short.truncated,true); assert.equal(short.depth_limited,true); assert.deepEqual(short.omitted_ids_sample,["T-002"]);
  const capped=(await get("/api/v1/results/T-005/dependencies?depth=8&limit=2")).body;
  assert.equal(capped.nodes.length,2); assert.equal(capped.node_limit_reached,true); assert.equal(capped.truncated,true);
});

test("evidence packets respect requested roots, mark incomplete text and keep candidates separate",async()=>{
  const {get}=harness();
  const packet=(await get("/api/v1/packet?ids=T-005&depth=8&max_items=10&max_chars=100000")).body;
  assert.equal(packet.truncated,false); assert.equal(packet.items.length,5); assert.ok(packet.items.every(row=>row.text_complete));
  assert.equal(packet.items.find(row=>row.id==="T-005").references[0].relation,"candidate_reference");
  const tiny=(await get("/api/v1/packet?ids=T-003&depth=0&max_chars=1")).body;
  assert.equal(tiny.text_budget.used_chars,1); assert.equal(tiny.items[0].statement.text,"I");
  assert.equal(tiny.items[0].proof.text,""); assert.equal(tiny.items[0].text_complete,false);
  assert.equal(tiny.truncated,true); assert.ok(tiny.omissions.text_fields>0); assert.ok(tiny.omissions.text_characters>0);
  assert.ok(tiny.omissions.text_fields_sample.some(row=>row.field==="proof.text"));
  assert.ok(tiny.omissions.text_fields_sample.some(row=>row.field==="citations[0].assumptions[0].required"));
  const tooFew=await get("/api/v1/packet?ids=T-003,T-004&max_items=1");
  assert.equal(tooFew.response.status,400);
});

test("immutable service state cannot follow later owner or input-object changes",async()=>{
  const corpus=fixture(), {get}=harness(corpus);
  const before=await get("/api/v1/results/T-003");
  corpus.items["T-003"].statement.text="Changed owner draft; do not expose.";
  corpus.project.title="Different owner title";
  const after=await get("/api/v1/results/T-003");
  assert.deepEqual(after.body,before.body); assert.equal(after.response.headers.get("ETag"),before.response.headers.get("ETag"));
  const cached=await get("/api/v1/results/T-003",{headers:{"If-None-Match":before.response.headers.get("ETag")}});
  assert.equal(cached.response.status,304);
  const unrelated=await get("/api/v1/results/T-002",{headers:{"If-None-Match":before.response.headers.get("ETag")}});
  assert.equal(unrelated.response.status,200);
});

test("corpus pinning rejects stale versions through every business route",async()=>{
  const {get,call,corpus}=harness();
  for (const route of ["/api/v1/project","/api/v1/search","/api/v1/results/T-003","/api/v1/results/T-003/proof","/api/v1/results/T-003/context","/api/v1/results/T-003/dependencies","/api/v1/results/T-003/sources","/api/v1/packet?ids=T-003"])
    assert.equal((await get(route+(route.includes("?")?"&":"?")+"corpus="+hash("stale"))).response.status,409);
  assert.equal((await get("/api/v1/results/T-003?corpus="+corpus.corpus_id)).response.status,200);
  const stale=await call("get_result",{id:"T-003",corpus:hash("stale")});
  assert.equal(stale.body.result.isError,true); assert.equal(JSON.parse(stale.body.result.content[0].text).error.code,"corpus_mismatch");
});

test("strict bounds, duplicate parameters and unknown arguments reject without widening scope",async()=>{
  const {get,call}=harness();
  const bad=["/api/v1/search?limit=51","/api/v1/search?limit=0","/api/v1/search?limit=1.5","/api/v1/search?offset=50001","/api/v1/search?limit=-1", "/api/v1/search?mode=semantic", "/api/v1/search?q=x&q=y", "/api/v1/search?q="+"x".repeat(2049),
    "/api/v1/results/T-005/dependencies?depth=9","/api/v1/results/T-005/dependencies?limit=201","/api/v1/results/T-005/dependencies?direction=everything",
    "/api/v1/packet?ids=T-003&max_chars=100001","/api/v1/packet?ids=T-003&max_chars=0","/api/v1/packet?ids=T-003&max_items=51",
    "/api/v1/project?command=recover","/api/v1/search?__proto__=x","/api/v1/results/T-003?id=T-004"];
  for (const route of bad) assert.equal((await get(route)).response.status,400,route);
  const invalid=await call("search_results",{q:"complete",command:"recover"});
  assert.equal(invalid.body.result.isError,true);
  assert.equal((await get("/api/v1/search?q="+"x".repeat(9000))).response.status,414);
});

test("all modification attempts and file/path probes fail; reads remain unchanged",async()=>{
  const {get,call}=harness(); const before=(await get("/api/v1/results/T-003")).body;
  for (const method of ["POST","PUT","PATCH","DELETE"]) for (const route of ["/api/v1/results/T-003","/api/v1/search","/api/v1/recover","/admin"])
    assert.equal((await get(route,{method,headers:{"X-HTTP-Method-Override":"GET"},body:"{}"})).response.status,405);
  for (const route of ["/api/v1/results/%2Fetc%2Fpasswd","/api/v1/results/..%2F..%2Fmathproject.json","/api/v1/results/file%3A%2F%2F%2Fetc%2Fpasswd"])
    assert.equal((await get(route)).response.status,400);
  assert.equal((await get("/mpm/events.jsonl")).response.status,404);
  assert.equal((await get("/public-corpus.json")).response.status,404);
  for (const name of ["edit_result","recover","ingest","review","create_release","execute","constructor","__proto__"]) {
    const result=await call(name,{id:"T-003",text:"modified"});
    assert.equal(result.body.error.code,-32602,name);
  }
  assert.deepEqual((await get("/api/v1/results/T-003")).body,before);
});

test("MCP offers only actual read operations and matches REST mathematics",async()=>{
  const {rpc,call,get}=harness();
  const list=await rpc({jsonrpc:"2.0",id:"list",method:"tools/list"});
  assert.equal(list.body.result.tools.length,8);
  for (const tool of list.body.result.tools) {
    assert.deepEqual(tool.annotations,{readOnlyHint:true,destructiveHint:false,idempotentHint:true,openWorldHint:false});
    assert.equal(tool.inputSchema.additionalProperties,false);
  }
  const pairs=[
    ["project_info",{},"/api/v1/project"],
    ["search_results",{q:"complete",limit:2},"/api/v1/search?q=complete&limit=2"],
    ["get_result",{id:"T-003"},"/api/v1/results/T-003"],
    ["get_proof",{id:"T-003"},"/api/v1/results/T-003/proof"],
    ["get_context",{id:"T-003"},"/api/v1/results/T-003/context"],
    ["get_dependencies",{id:"T-005",depth:8},"/api/v1/results/T-005/dependencies?depth=8"],
    ["get_sources",{id:"T-003"},"/api/v1/results/T-003/sources"],
    ["get_research_packet",{ids:["T-003"],depth:0,max_chars:20},"/api/v1/packet?ids=T-003&depth=0&max_chars=20"]];
  for (const [name,args,path] of pairs) {
    const mcp=await call(name,args), rest=await get(path);
    assert.equal(mcp.body.result.isError,false,name);
    assert.deepEqual(JSON.parse(mcp.body.result.content[0].text),rest.body,name);
  }
});

test("MCP discovery, version negotiation, Origin validation and notifications follow stateless transport",async()=>{
  const {get,rpc}=harness();
  const discover=await rpc({jsonrpc:"2.0",id:1,method:"server/discover"});
  assert.deepEqual(discover.body.result.supportedVersions,["2026-07-28"]);
  for (const version of ["2025-03-26","2025-06-18","2025-11-25"]) {
    const init=await rpc({jsonrpc:"2.0",id:1,method:"initialize",params:{protocolVersion:version,capabilities:{},clientInfo:{name:"test",version:"1"}}});
    assert.equal(init.body.result.protocolVersion,version);
  }
  const fallback=await rpc({jsonrpc:"2.0",id:1,method:"initialize",params:{protocolVersion:"2024-11-05",capabilities:{},clientInfo:{name:"test",version:"1"}}});
  assert.equal(fallback.body.result.protocolVersion,"2025-11-25");
  const message={jsonrpc:"2.0",id:1,method:"ping"};
  assert.equal((await rpc(message,{Origin:"https://math.example"})).response.status,200);
  assert.equal((await rpc(message,{Origin:"https://evil.example"})).response.status,403);
  assert.equal((await rpc(message,{Origin:"null"})).response.status,403);
  assert.equal((await rpc(message,{"MCP-Protocol-Version":"2024-11-05"})).response.status,400);
  assert.equal((await rpc(message,{"MCP-Protocol-Version":"2025-11-25"})).response.status,200);
  const notice=await rpc({jsonrpc:"2.0",method:"notifications/initialized"});
  assert.equal(notice.response.status,202); assert.equal(notice.body,null);
  assert.equal((await get("/mcp")).response.status,405);
  assert.equal((await rpc({jsonrpc:"2.0",id:1,method:"resources/write"})).body.error.code,-32601);
});

test("MCP malformed requests, streaming body limits and media types produce bounded errors",async()=>{
  const {api,rpc}=harness();
  for (const value of [[],null,{jsonrpc:"1.0",id:1,method:"ping"},{jsonrpc:"2.0",id:null,method:"ping"},{jsonrpc:"2.0",id:{bad:true},method:"ping"}]) {
    const result=await rpc(value); assert.equal(result.response.status,400); assert.equal(result.body.error.code,-32600);
  }
  const malformed=await api.fetch(new Request("https://math.example/mcp",{method:"POST",headers:{"Content-Type":"application/json"},body:"{"}));
  assert.equal(malformed.status,400); assert.equal((await malformed.json()).error.code,-32700);
  const media=await api.fetch(new Request("https://math.example/mcp",{method:"POST",body:"{}"}));
  assert.equal(media.status,415);
  const oversized=await api.fetch(new Request("https://math.example/mcp",{method:"POST",headers:{"Content-Type":"application/json"},body:" ".repeat(65537)}));
  assert.equal(oversized.status,413);
  const stream=new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode(" ".repeat(40000)));controller.enqueue(new TextEncoder().encode(" ".repeat(40000)));controller.close();}});
  const chunked=await api.fetch(new Request("https://math.example/mcp",{method:"POST",headers:{"Content-Type":"application/json"},body:stream,duplex:"half"}));
  assert.equal(chunked.status,413);
});

test("response byte caps reject huge records while a bounded evidence packet remains useful",async()=>{
  const corpus=fixture(); corpus.items["T-003"].proof.text="Proof paragraph. ".repeat(40000);
  const {get,call}=harness(sealed(corpus));
  const full=await get("/api/v1/results/T-003");
  assert.equal(full.response.status,413); assert.equal(full.body.error.code,"response_too_large");
  const packet=(await get("/api/v1/packet?ids=T-003&depth=0&max_chars=1000")).body;
  assert.equal(packet.truncated,true); assert.equal(packet.text_budget.used_chars,1000);
  assert.equal(packet.items[0].text_complete,false);
  const oversizedMCP=await call("get_result",{id:"T-003"});
  assert.equal(oversizedMCP.response.status,413);
  assert.equal(oversizedMCP.body.jsonrpc,"2.0"); assert.equal(oversizedMCP.body.id,1);
  assert.equal(oversizedMCP.body.error.data.code,"response_too_large");
});

test("invalid object version pins stay inside the MCP error boundary and standard metadata is accepted",async()=>{
  const {rpc}=harness();
  const invalid=await rpc({jsonrpc:"2.0",id:"bad-pin",method:"tools/call",params:{name:"get_result",arguments:{id:"T-003",corpus:{toString:null}}}});
  assert.equal(invalid.response.status,200); assert.equal(invalid.body.id,"bad-pin"); assert.equal(invalid.body.result.isError,true);
  const metadata=await rpc({jsonrpc:"2.0",id:"meta",method:"tools/call",params:{name:"get_result",arguments:{id:"T-003"},_meta:{progressToken:"read-1","client/custom":true}}});
  assert.equal(metadata.body.result.isError,false); assert.equal(JSON.parse(metadata.body.result.content[0].text).item.id,"T-003");
});

test("MCP validates integer schema types while REST accepts numeric query strings",async()=>{
  const {call,get}=harness();
  for (const [name,args] of [["search_results",{limit:"1"}],["search_results",{offset:"0"}],
    ["get_dependencies",{id:"T-005",depth:"2"}],["get_research_packet",{ids:["T-003"],max_chars:"1000"}]]) {
    const result=await call(name,args);
    assert.equal(result.body.result.isError,true,name); assert.match(JSON.parse(result.body.result.content[0].text).error.message,/integer JSON number/);
  }
  assert.equal((await call("search_results",{limit:1})).body.result.isError,false);
  assert.equal((await get("/api/v1/search?limit=1")).body.results.length,1);
});

test("128 MiB workers reject oversized and token-dense corpora without allocating a word index",()=>{
  const moduleURL=new URL("../runtime.mjs",import.meta.url).href;
  const program=`
    import {createReadonlyAPI} from ${JSON.stringify(moduleURL)};
    import {createHash} from "node:crypto";
    const canonical=${canonical.toString()};
    const hash=value=>createHash("sha256").update(typeof value==="string"?value:canonical(value)).digest("hex");
    const source=${JSON.stringify(source)};
    const item=${item.toString()};
    const sealed=${sealed.toString()};
    function make(mode) {
      const items={};
      if (mode==="oversized") for(let i=0;i<1500;i++) {
        const id="T:"+String(i).padStart(6,"0");
        const words=Array.from({length:800},(_,j)=>"term"+i.toString(36)+"x"+j.toString(36)).join(" ");
        items[id]=item(id,words,{kind:"definition"});
      }
      else items["T-001"]=item("T-001",mode==="dense"?". ".repeat(700000):"x".repeat(7*1024*1024),{kind:"definition"});
      const payload={schema_version:1,format:"math-project-public-corpus",project:{title:"Budget fixture",namespace:"T",demo:true},
        release:{id:hash("release"),name:"budget-v1",snapshot:hash("snapshot"),created_at:"2026-11-17",kind:"reviewed_release",meaning:"Fixture."},
        requested:[Object.keys(items)[0]],order:Object.keys(items),items};
      // Rejected inputs need no extra hash-buffer allocation. Accepted input
      // is sealed so the first query also exercises canonical verification.
      return mode==="near-bytes"?sealed(payload):{...payload,corpus_id:"a".repeat(64)};
    }
    const mode=process.argv[1];
    try {
      const api=createReadonlyAPI(make(mode));
      if(mode!=="near-bytes") throw new Error("Budget was not enforced");
      const project=await api.fetch(new Request("https://math.example/api/v1/project"));
      if(project.status!==200) throw new Error("Accepted corpus could not be read");
      const query=await api.fetch(new Request("https://math.example/api/v1/search?q=absent"));
      if(query.status!==200) throw new Error("Accepted corpus could not be searched");
      console.log(JSON.stringify({mode,accepted:true}));
    } catch(error) {
      const expected=mode==="oversized"?"8 MiB":mode==="dense"?"200,000 searchable-token":null;
      if(!expected||!error.message.includes(expected)) throw error;
      console.log(JSON.stringify({mode,rejected:true,message:error.message}));
    }
  `;
  for (const mode of ["oversized","dense","near-bytes"]) {
    const result=spawnSync(process.execPath,["--max-old-space-size=128","--input-type=module","--eval",program,mode],{encoding:"utf8",timeout:20000});
    assert.equal(result.status,0,`${mode}: ${result.error||result.stderr}`);
    const output=JSON.parse(result.stdout.trim());
    assert.equal(mode==="near-bytes"?output.accepted:output.rejected,true);
  }
});

test("search page cursors remain usable beyond ten thousand results",async()=>{
  const corpus=fixture(); corpus.items={}; corpus.order=[];
  for (let index=0;index<10003;index++) {
    const id="P-"+String(index).padStart(5,"0");
    corpus.items[id]=item(id,"Published definition.",{kind:"definition"}); corpus.order.push(id);
  }
  corpus.requested=[corpus.order[0]];
  const {get}=harness(sealed(corpus));
  const first=(await get("/api/v1/search?offset=10000&limit=1")).body;
  assert.equal(first.total,10003); assert.equal(first.next_offset,10001);
  const next=await get("/api/v1/search?offset="+first.next_offset+"&limit=2");
  assert.equal(next.response.status,200); assert.equal(next.body.results.length,2); assert.equal(next.body.next_offset,null);
});

test("unverified or nonpublic input is refused rather than serving extra internal fields",async()=>{
  for (const mutate of [
    corpus=>{corpus.snapshot_data={private:"whole source"};},
    corpus=>{corpus.items["T-003"].reviews=[{reviewer:"private identity"}];},
    corpus=>{corpus.items["T-003"].statement.source.path="/private/project.tex";},
    corpus=>{corpus.items["T-003"].statement.source.path="../private.tex";},
    corpus=>{corpus.items["T-003"].dependencies.push("UNPUBLISHED");},
    corpus=>{corpus.items["T-003"].citations[0].inspected_text="private quotation";},
    corpus=>{corpus.items["T-003"].citations[0].uri="https://person:password@example.org/paper";},
    corpus=>{corpus.items["T-003"].citations[0].uri="file:///private/paper";}
    ,corpus=>{corpus.items["T-003"].citations[0].assumptions[0].private_note="do not publish";}
    ,corpus=>{corpus.items["T-003"].citations[0].no_assumptions=true;}
  ]) {const corpus=fixture();mutate(corpus);assert.throws(()=>createReadonlyAPI(sealed(corpus)));}
  const corrupt=fixture(); corrupt.items["T-003"].statement.text="Undeclared mutation";
  const result=await harness(corrupt).get("/api/v1/project");
  assert.equal(result.response.status,503); assert.equal(result.body.error.code,"service_unavailable");
});

test("OpenAPI and AI guide describe only available GET operations and current versions",async()=>{
  const {get,api,corpus}=harness(fixture(),{html:"<!doctype html><title>Reader</title>"});
  const spec=(await get("/openapi.json")).body;
  assert.equal(spec.openapi,"3.1.0"); assert.equal(Object.keys(spec.paths).length,8);
  for (const path of Object.values(spec.paths)) {assert.deepEqual(Object.keys(path),["get"]);assert.equal(path.get["x-read-only"],true);}
  assert.deepEqual(spec.servers,[{url:"https://math.example"}]);
  const guide=await (await api.fetch(new Request("https://math.example/llms.txt"))).text();
  assert.ok(guide.includes(corpus.corpus_id)); assert.ok(guide.includes("not formal-kernel verification")); assert.ok(guide.includes("private deployment"));
  const page=await api.fetch(new Request("https://math.example/results/prop-complete"));
  assert.equal(page.status,200); assert.ok((await page.text()).includes("Reader"));
  const head=await api.fetch(new Request("https://math.example/api/v1/project",{method:"HEAD"}));
  assert.equal(head.status,200); assert.equal(await head.text(),"");
  const options=await api.fetch(new Request("https://math.example/mcp",{method:"OPTIONS"}));
  assert.equal(options.status,204); assert.equal(options.headers.get("Access-Control-Allow-Methods"),"POST, OPTIONS");
});
