#!/usr/bin/env node
// Self-contained local read adapter. No owner project, CLI dispatch, or write API.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createReadonlyAPI } from './runtime.mjs';
import { readCorpus } from './build.mjs';

const base=dirname(fileURLToPath(import.meta.url));
const args=process.argv.slice(2), options={host:'127.0.0.1',port:8787};
if(args.includes('--help')){
  console.log('node serve.mjs [--host 127.0.0.1] [--port 8787]\nReads only this export. Defaults to localhost. Put TLS/access control in a reverse proxy for remote use.');
  process.exit(0);
}
try{
  for(let i=0;i<args.length;i+=2){
    const name=args[i],value=args[i+1];
    if(!['--host','--port'].includes(name)||!value)throw new Error('Usage: node serve.mjs [--host HOST] [--port PORT]');
    if(name==='--host'){
      if(!['127.0.0.1','::1','0.0.0.0','::'].includes(value))throw new Error('Host must be an explicit bind address.');
      options.host=value;
    }else{
      if(!/^\d{1,5}$/.test(value)||Number(value)>65535)throw new Error('Port must be 0–65535.');
      options.port=Number(value);
    }
  }
  const corpus=await readCorpus();
  const app=createReadonlyAPI(corpus,{html:await readFile(join(base,'index.html'),'utf8')});
  const server=createServer(async(req,res)=>{
    try{
      const address=server.address(), port=address.port;
      const authority=req.headers.host||'';
      // A local service must not accept DNS-rebinding hostnames. Remote hosting
      // belongs behind a real reverse proxy or the generated Worker.
      const localHosts=new Set(['127.0.0.1:'+port,'localhost:'+port,'[::1]:'+port]);
      if(['127.0.0.1','::1'].includes(options.host)&&!localHosts.has(authority)){
        res.writeHead(403,{'Content-Type':'application/json'});res.end('{"error":{"code":"invalid_host","message":"Invalid local Host header"}}');return;
      }
      const declared=Number(req.headers['content-length']||0);
      if(declared>65536){res.writeHead(413,{'Connection':'close'});res.end();req.resume();return;}
      const chunks=[];let size=0;
      for await(const chunk of req){size+=chunk.length;if(size>65536){res.writeHead(413,{'Connection':'close'});res.end();return;}chunks.push(chunk);}
      const headers=new Headers();
      for(const [name,value]of Object.entries(req.headers)){if(Array.isArray(value))value.forEach(v=>headers.append(name,v));else if(value!==undefined)headers.set(name,value);}
      const input={method:req.method,headers};
      if(!['GET','HEAD'].includes(req.method)&&size)input.body=Buffer.concat(chunks);
      const response=await app.fetch(new Request('http://'+authority+req.url,input));
      res.writeHead(response.status,Object.fromEntries(response.headers));
      res.end(Buffer.from(await response.arrayBuffer()));
    }catch{
      if(!res.headersSent)res.writeHead(400,{'Content-Type':'application/json'});
      if(!res.writableEnded)res.end('{"error":{"code":"bad_request","message":"Invalid request"}}');
    }
  });
  server.requestTimeout=15000;
  server.headersTimeout=10000;
  server.keepAliveTimeout=5000;
  server.maxHeadersCount=64;
  server.on('error',error=>{console.error(error.message);process.exitCode=1;});
  server.listen(options.port,options.host,()=>{
    const address=server.address(),host=address.address.includes(':')?'['+address.address+']':address.address;
    console.log(JSON.stringify({url:'http://'+host+':'+address.port,corpus_id:corpus.corpus_id,items:Object.keys(corpus.items).length,access:'read_only'}));
  });
}catch(error){console.error(error.message);process.exitCode=1;}
