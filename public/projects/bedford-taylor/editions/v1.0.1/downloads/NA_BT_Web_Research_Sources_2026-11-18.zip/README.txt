Non-Archimedean Bedford–Taylor Theory
Public Atlas edition v1.0.1; source reading edition 2026-11-18.

This package contains the unsigned reading sources and public metadata served by this exact Atlas edition. Source and PDF mathematical status is unchanged. Each source-manifest entry distinguishes the reading-copy SHA-256 from its original-source identity. Website URLs are bound to this frozen edition. Older source-download filenames supply this same public reading package, not a byte-exact historical archive.

No private full archive, signed original or private feedback is included. Publication checks establish artifact consistency, not independent proof acceptance.

Frozen edition: https://dongkaicheng.github.io/math-research-atlas/projects/bedford-taylor/editions/v1.0.1/
Feedback: https://dongkaicheng.github.io/math-research-atlas/feedback/?project=bedford-taylor&version=v1.0.1
